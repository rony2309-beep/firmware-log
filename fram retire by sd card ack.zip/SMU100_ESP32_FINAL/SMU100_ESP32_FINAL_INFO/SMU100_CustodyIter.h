#ifndef SMU100_CUSTODY_ITER_H
#define SMU100_CUSTODY_ITER_H

// Arduino IDE generates function prototypes before later .ino struct declarations.
// Keep this type in an included header so custodyIterClose/Next prototypes compile.
#include <dirent.h>

struct CustodyIter {
    DIR* top;
    DIR* sub;
    char subName[4];
};

#endif // SMU100_CUSTODY_ITER_H
