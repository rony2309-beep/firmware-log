/*
 * =============================================================================
 *  SMU-100 Rev-T1  —  ESP32 FINAL FIRMWARE   (ESP32 DevKit / WROOM-32)
 *  FW_REV "2026.10.14-F3"   UART PROTOCOL v4
 * =============================================================================
 *  ESP32 responsibility (PDF Sheet-09): Wi-Fi / MQTT, RFID (RDM6300), SH1106
 *  OLED, microSD durable offline queue, STM32 UART link, NTP time, server
 *  request/response, provisioning (NVS).
 *  F3: ESP32 STATELESS. Operator / location / style / process / SMV / divisor /
 *  maintenance / technician / session id / session table / card-punch flag /
 *  login-maintenance event — sob STM32 FRAM-e. ESP32 NVS-e shudhu provisioning
 *  ("smucfg": WiFi, MQTT, machineId, timeout, bound profile). Session data STM32
 *  CTX frame theke RAM-e ashe; protiti EV frame-e event-er nijer session metadata thake.
 *  RFID card -> STM32 command (LOGIN / MAINT / LOCATION), STM32 FRAM-e save hoy.
 *
 *  ESP32 file-e KONO MACHINE_PROFILE NAI. Profile STM32 theke (BOOT / HB) ashe.
 *  Prothom valid profile NVS-e "bind" hoy; pore STM32 onno profile report korle
 *  ESP32 HOLD-e jay (event NAK -> STM32 FRAM-e thake) jotokkhon na Serial
 *  console-e "PROFILE ACCEPT" deya hoy. Ete bhul machine ID-te publish hoy na.
 * =============================================================================
 *  Arduino IDE:
 *    Board     : ESP32 Dev Module   (Arduino-ESP32 core 2.x or 3.x; tested 3.3.x)
 *    Libraries : PubSubClient 2.8, ArduinoJson 6.x / 7.x, Adafruit GFX, Adafruit SH110X
 *  Serial console (115200, newline): HELP | SHOW | SET <key> <value> | CLEAR <key>
 *                 | PROFILE ACCEPT | QUEUE | REBOOT
 * =============================================================================
 *  DATA FLOW (owner rule)
 *
 *   STM32: event -> FRAM outbox + SATHE SATHE EV,seq,..,epoch -> ESP32
 *   ESP32: (a) microSD LOG /smu/log/YYYYMMDD.jl-e append  (KOKHONO muche na)
 *          (b) Database POST (MQTT request/response)
 *          DB response (status 200 success ba E11000 duplicate) -> "DELIVERED,seq,ep"
 *          -> STM32 FRAM theke oi event muche fele.
 *   STM32 3 s-er moddhe DELIVERED na pele abar pathay; ESP32 duplicate (epoch,seq)
 *   chine: SD-te abar lekhe na, DB-te age pouchale sathe sathe DELIVERED dey.
 *   ACK levels: RX = pouchheche, STORED = SD log-e lekha (info), DELIVERED = DB response.
 *   NOTE: MQTT publish success != database persistence. "DELIVERED" shudhu server-er
 *   application reply-er por. Exactly-once: deterministic uniqueCode + server unique index.
 *   HELD (flag 0x04): operator login chhara event — SD log hoy, DB-te jay na. Login-er por
 *   STM32 operator-er name diye abar pathay (flag 0x08 REASSIGNED) -> SD-te notun line + DB.
 *   DAILY RESET: STM32 nijei kore (03:00 local); login chhara event "UNKNOWN" name-e DB-te
 *   (flag 0x10). Card punch -> ESP restart -> server theke counter (RESTORE).
 * =============================================================================
 */

/*
 * BENCH PATCH 2026-10-16: per-event verified microSD custody spool (/smu/custody)
 * with CRC32, immutable retransmission payload, 64-item RAM work window, and
 * boot replay. No FAT power-loss qualification or identity-bound MongoDB ACK
 * yet. Legacy E11000 is NOT counted as success. Do not deploy as final firmware.
 */
/*
 * SD BAD-FILE GUARD 2026-10-26: nosto (porte na para / atke jaoa) SD file boot ba
 * background loop atkate parbe na. Protiti file sorboccho ekbar 3 s nibe, tarpor
 * /smu/quarantine-e rename (delete na) kore skip. Sudhu ei 4 jaygay poriborton:
 * (1) SD BAD-FILE GUARD helper, (2) custodyRefillUnlocked, (3) sdSeedFile,
 * (4) postEnqueueStm (unreadable .evt). Baki logic unchanged.
 */
/*
 * STORAGE FORMAT COMMANDS 2026-10-26 (Serial console, protiti alada + "YES" confirm):
 *   FORMAT_FRAM YES : STM32-ke "FFMT,<uid>" -> STM32 FRAM 32 KB zero + guard, STM32 reset
 *   FORMAT_SD   YES : microSD notun FAT (f_mkfs, partition soho) -> ESP32 restart
 *   FORMAT_NVS  YES : ESP32 NVS partition puro erase -> ESP32 restart
 *   "YES" chhara shudhu warning dekhay, kichu muche na. Baki logic unchanged.
 */
/*
 * SD-INDEPENDENT DB DELIVERY 2026-10-27 (BUILD_TAG):
 *  Lokkho: SD card fail / offline / corrupt holeo production event DB-te jawa bondho hobe na.
 *  (A) Server 409 / E11000 = "ei uniqueCode age thekei DB-te save ache" -> PUB_OK (idempotent).
 *      Queue-er mathay 409 "poison" loop ar hobe na. (ACCEPT_DUPLICATE_AS_COMMITTED)
 *  (B) Corrupt .ok receipt -> /smu/quarantine-e rename (delete na) -> notun .ok lekha.
 *  (C) DB commit verified, kintu SD receipt lekha gelo na (SD offline / proof journal full):
 *      DBCOMMIT pathiye STM32 FRAM retire kora hoy + "[SD RECEIPT GAP]" log + counter.
 *      Owner rule: DB response -> FRAM delete. Abar POST holeo server 409 dey -> duplicate hoy na.
 *  (D) Proof repair 60 s -> 3 s. .evt nai / porte na parle NVS proof release (SD-e kichu muche na).
 *  (E) MQTT connect / subscribe / publish-er age TWDT reset: blocking TCP write-e 30 s WDT crash bondho.
 *  (F) EV replay: ei boot-e DB-committed (recent st=4) ba NVS proof thakle sathe sathe DBCOMMIT
 *      (SD lagbe na; UART-e harano ACK-er jonno STM32 replay korle-o FRAM khali hoy).
 *  (G) WiFi down hole stale MQTT socket stop (MQTT=1 vul dekhay na). SD remount backoff 30 s -> 5 min.
 *  (H) Default tProdPost 3000 -> 8000 ms (server deri-te reply dile bar bar re-POST na).
 *  FW_REV (payload-er "fwRev") ichchha kore UNCHANGED: SD-te thaka purono .evt-er sathe replay JSON
 *  mile thake (PAYLOAD_CONFLICT na hoy). Build chinte BUILD_TAG boot log-e dekhabe.
 */
/*
 * RESET-DEBUG 2026-11-02 (BUILD_TAG ...-RESETDBG):
 *  (1) [PREV RUN] boot log: ager run crash/WDT-er somoy linkTask + backgroundTask kon stage-e
 *      chilo, sorbonimno free heap / largest block, postQ RAM bytes (RTC_NOINIT memory-te thake,
 *      software/panic/WDT reset-e muche na; power-off-e muche jay).
 *  (2) [RESET HINT] reset reason-er mane (POWER_ON = power cut ba STM32 PB5 EN reset, ...).
 *  (3) [MEM-HEALTH] 30 s por por: heap free/min/largest, postQ items+bytes, task stack free,
 *      verdict OK / LOW / CRITICAL. "Memory full" kina ekhane sorasori dekha jabe.
 *  (4) HEAP GUARD: largest free block < 20 KB hole notun event RAM postQ-e na tule SD custody /
 *      STM32 FRAM-e rekhe dey (deque push_back out-of-memory abort -> PANIC reset bondho).
 *  (5) STM32 "SDIAG" frame decode -> "[STM-DIAG]" (STM32 reset karon IWDG/POR/PIN, kon stage-e
 *      atke chilo, RAM free gap, outbox, UART error, ESP reset count). [STM32 BOOT] reset flag text.
 *  (6) linkTask stack 8 KB -> 12 KB (SD + JSON + 720 B UART buffer ek-i call chain-e). [LINK STALL] warn.
 *  Production data path / payload / ACK logic UNCHANGED.
 *
 * RETIRE-SD-OR-DB 2026-11-02d:
 *  STM32 ekhon CUSTODY (SD .evt CRC-verified) ba DBCOMMIT (DB response) — je kono ekta pelei FRAM
 *  retire kore (STM32 ENABLE_SD_CUSTODY_RECLAIM 1). ESP32 flow:
 *     EV -> SD /smu/custody/<id>.evt (verify) -> CUSTODY ack (FRAM khali)  + RAM postQ (DB POST)
 *        DB OK  -> .ok + /smu/done/YYYYMMDD/-e rename (SD queue theke sore)  + DBCOMMIT
 *        DB fail-> /smu/custody-te thake = SD QUEUE; DB phire ele custodyRefill -> POST
 *        SD fail-> CUSTODY nai -> FRAM-e thake, RAM postQ diye DB -> DBCOMMIT -> retire
 *  HELD (login chhara) event: "STORED" (CUSTODY na) -> FRAM-e-i thake (login-e operator name boshe).
 *  SD refill file-name diye age postQ/recent check kore (file na pore skip).
 */
#include <Arduino.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include <SPI.h>
#include <SD.h>
#include <FS.h>
#include <Preferences.h>
#include <time.h>
#include <sys/time.h>
#include <deque>
#include <stdarg.h>
#include <esp_system.h>
#include <esp_heap_caps.h>
#include <esp_task_wdt.h>
#include <esp_attr.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <string.h>
#include <ctype.h>
#include <esp_sntp.h>
#include <errno.h>          // SD log diagnostics (2026-10-25)
#include <nvs_flash.h>      // FORMAT_NVS (2026-10-26)
#include <esp_idf_version.h>
#include "ff.h"             // FORMAT_SD: FatFs f_mkfs
#include "sd_diskio.h"      // FORMAT_SD: sdcard_init / sdcard_uninit (Arduino SD library)
#include <dirent.h>          // SD-SCAN-FIX: readdir (file open chhara directory scan)
#include "SMU100_CustodyIter.h"  // CustodyIter visible before Arduino-generated function prototypes

// --- OLED Display Libraries (SH1106 1.3 Inch) ---
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>

#define PROTO_VER   4
#define FW_REV "2026.10.16-PHASED-BENCH"              // payload "fwRev" — UNCHANGED (SD replay JSON match)
#define BUILD_TAG "2026.11.02k-QUEUE-FAST-SAFE"     // shudhu boot log-e (payload-e jay na)
#define ACCEPT_DUPLICATE_AS_COMMITTED 1              // 409 / E11000 = age-i DB-te save -> PUB_OK
#define PAYLOAD_CONFLICT_QUARANTINE   1              // SD .evt != FRAM replay -> old .evt rename, FRAM authority

#if ARDUINOJSON_VERSION_MAJOR >= 7
  #define JDOC(name, cap) JsonDocument name
#else
  #define JDOC(name, cap) DynamicJsonDocument name(cap)
#endif

// =============================================================================
// 1) PROFILE TABLE  (legacy per-machine defaults; profile number STM32 theke)
// =============================================================================
#define PROFILE_PLAIN_OPTO        1
#define PROFILE_OVERLOCK_IR       2
#define PROFILE_FLATLOCK_DOUBLE   3
#define PROFILE_BUTTON_ATTACH     4
#define PROFILE_ENCODER_BJ100     5
#define PROFILE_BUTTON_HOLE       6
#define PROFILE_BARTACK           7

struct LegacyDef {
  const char* name;
  const char* machineId;   // legacy hard-coded ID (provisioned ID na thakle fallback)
  const char* ssid;
  const char* host;
  double smv;
  bool needleField;        // legacy payload-e "needleDownTime" chilo
};

const LegacyDef LEGACY[8] = {
  { "UNKNOWN",         "",                            "Knitting_Machine",              "192.168.30.4", 0.6, false },
  { "PLAIN_OPTO",      "SEWING_MAC_NEW_FIRMWARE_11(LEBEL_TS)",     "Knitting_Machine",              "192.168.30.4",  0.0, true  },
  { "OVERLOCK_IR",     "SEWING_MAC_01(SLEEVE_JOIN)",  "Knitting_Machine",              "192.168.30.4", 0.6, false },
  { "FLATLOCK_DOUBLE", "SEWING_MAC_10(BOTTOM_HEM)",   "Knitting_Machine",              "192.168.30.4", 0.6, false },
  { "BUTTON_ATTACH",   "SEWING_MAC_17(BUTTON_ATTACH)","Knitting_Machine",               "192.168.30.4", 0.6, false },
  { "ENCODER_BJ100",   "SEWING_MAC_01(SLEEVE_JOIN)",  "Knitting_Machine",              "192.168.30.4",  0.0, false },
  { "BUTTON_HOLE",     "SEWING_MAC_01(BUTTON_HOLE)",  "Knitting_Machine",               "192.168.30.4", 0.6, false },
  { "BARTACK",         "SEWING_MAC_16(BARTECK)",      "Knitting_Machine",              "192.168.30.4", 0.6, false },
};


// =============================================================================
// 2) USER CONFIGURATION  (compile-time defaults; runtime provisioning NVS-e)
// =============================================================================
#define DEFAULT_WIFI_PASS        "Gms12345"
#define DEFAULT_MQTT_PORT        1883
#define DEFAULT_TZ_OFFSET_SEC    (6 * 3600)        // Bangladesh UTC+6 (display/NTP local only)
#define DEFAULT_NTP_SERVER       "pool.ntp.org"
#define AUTO_BIND_FIRST_PROFILE  1                 // prothom valid STM32 profile auto-bind
#define PAYLOAD_LEGACY_SPARSE    1                 // server-e legacy key set (0 value field bad)
#define PAYLOAD_INCLUDE_FW_FIELDS 1                // 0 = server strict schema hole firmware metadata field bad
                                                   //     (SD record-e sob field thake-i)

#define SD_ENABLED               1
#define SD_RESERVE_BYTES         (8UL * 1024UL * 1024UL)   // er kom free hole SD "FULL" (logging bondho, kichu muche na)
#define SD_RETRY_MIN_MS          30000UL           // SD remount retry shuru (2026-10-27)
#define SD_RETRY_MAX_MS          300000UL          // bar bar fail hole sorboccho 5 min por por
#define ESP_DIAG_PERIODIC        1
#define DIAGNOSTIC_INTERVAL_MS   5000UL           // legacy 5 s -> 30 s (log flood komano)
#define ESP_TASK_WDT_TIMEOUT_S   30
#define QUEUE_ITEM_GAP_MS        200               // legacy: item-er majhe 200 ms
#define QUEUE_MAX_REJECTS        5                 // eki record 5 bar 4xx -> "rejected" (SD-te thake)
#define QUEUE_BACKOFF_MIN_MS     1000UL
#define QUEUE_BACKOFF_MAX_MS     10000UL
#define MQTT_BACKOFF_MIN_MS      5000UL
#define MQTT_BACKOFF_MAX_MS      60000UL
#define CMD_RETRIES              5
#define CMD_REPLY_WAIT_MS        400
#define TIME_PUSH_INTERVAL_MS    3600000UL
#define LINK_BAUD                115200

// Per-operation server timeouts (ms) — legacy call-site values; NVS-e override kora jay
#define T_ASSETS_MS              4000
#define T_PROD_POST_MS           8000              // 2026-10-27: 3000 -> 8000 (server deri-te reply dey)
#define T_PROD_GET_MS            4000
#define T_LOCATION_MS            3000
#define T_LAYOUT_MS              3000

// =============================================================================
// DATA TYPES — Arduino IDE auto-prototype-er age declare thakte hobe
// =============================================================================
enum PubResult { PUB_OK, PUB_RETRY, PUB_REJECTED };
enum FinishResult { FINISH_VERIFIED, FINISH_RECEIPT_PENDING, FINISH_RETAIN };

// DB post queue item (STM32 event: seq/epoch != 0; F2-upgrade NVS ESP event: nvsSlot >= 0)
struct PostItem { String line; uint32_t seq; uint32_t epoch; int8_t nvsSlot; String uc; };

struct SessMeta {
  uint32_t id;
  String op, loc, style, proc;
  double smv;
  int div;
};

// st: 1 SD logged as HELD, 2 SD logged / queued, 3 delivered (legacy / proof), 4 DB commit verified this boot
struct RecentSeq { uint32_t epoch; uint32_t seq; uint8_t st; };

struct NetCfg {
  String machineId, ssid, pass, mqttHost, mqttUser, mqttPass, ntp;
  uint16_t mqttPort;
  long tzSec;
  uint32_t tAssets, tProdPost, tProdGet, tLocation, tLayout;
};

static inline bool profileValid(int p) { return p >= 1 && p <= 7; }

// =============================================================================
// 3) PIN MAP  (PDF Sheet-09 ESP32 pin map)
// =============================================================================
#define PIN_STM_RX     16    // UART2 RX  <- STM32 PA9 TX
#define PIN_STM_TX     17    // UART2 TX  -> STM32 PA10 RX
#define PIN_SD_SCK     18
#define PIN_SD_MISO    19
#define PIN_SD_MOSI    23
#define PIN_SD_CS      13
#define PIN_OLED_SDA   21
#define PIN_OLED_SCL   22
#define PIN_RFID_RX    27    // RDM6300 TX (10k + BAT85 clamp)

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define i2c_Address 0x3c
Adafruit_SH1106G display = Adafruit_SH1106G(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

HardwareSerial StmLink(2);
HardwareSerial RfidSerial(1);

// =============================================================================
// 4) NETWORK CONFIG (resolved at runtime) + MQTT
// =============================================================================
NetCfg cfg;
String MACHINE_ID = "";              // resolved identity (empty = unknown -> HOLD)
const char* ssid = "";
const char* password = "";
const char* MQTT_BROKER_HOST = "";
uint16_t MQTT_BROKER_PORT = DEFAULT_MQTT_PORT;
const char* MQTT_USERNAME = "";
const char* MQTT_PASSWORD = "";

const uint32_t MQTT_TCP_CONNECT_TIMEOUT_MS = 5000; // Recovery: tolerate marginal WiFi/LAN handshake
const uint16_t MQTT_PROTOCOL_TIMEOUT_SEC = 5; // Recovery: do not prematurely time out broker CONNACK

const char* TOPIC_ASSETS_GET = "factory/request/assets/get";
const char* TOPIC_SERVER_TIME_GET = "factory/request/time/get"; // Stage-1 LAN worker addition
const char* TOPIC_PRODUCTION_POST = "factory/request/production/post";
const char* TOPIC_PRODUCTION_GET = "factory/request/production/get";
const char* TOPIC_LAYOUT_SCAN = "factory/request/layout/scan";
const char* TOPIC_MACHINE_LOCATION_GET = "factory/request/machine-location/get";

WiFiClient mqttNetworkClient;
PubSubClient mqttClient(mqttNetworkClient);
SemaphoreHandle_t mqttMutex;
SemaphoreHandle_t qMutex;          // SD/RAM queue
SemaphoreHandle_t qProcMutex;      // processOfflineQueue() single runner
SemaphoreHandle_t dbProofMutex;     // independent NVS proof journal
SemaphoreHandle_t sessionMutex;    // session strings
SemaphoreHandle_t linkTxMutex;     // UART TX
SemaphoreHandle_t cmdMutex;

TaskHandle_t backgroundTaskHandle = NULL;
TaskHandle_t loopTaskHandler = NULL;
TaskHandle_t diagnosticTaskHandle = NULL;
TaskHandle_t linkTaskHandle = NULL;

// RTC Diagnostics Variables (legacy)
RTC_DATA_ATTR uint32_t rtcBootCount = 0;
RTC_DATA_ATTR volatile uint32_t rtcTaskWdtHitCount = 0;
RTC_DATA_ATTR char rtcLastCheckpoint[72] = "NONE";
RTC_DATA_ATTR uint32_t rtcLastCheckpointMillis = 0;
RTC_DATA_ATTR uint32_t rtcLastFreeHeap = 0;
RTC_DATA_ATTR uint32_t rtcLastMinimumHeap = 0;

// RESET-DEBUG 2026-11-02: RTC_NOINIT = software / panic / task-WDT reset-e muche na.
// Power-on-e garbage thake -> magic diye valid check.
#define RD_MAGIC 0x52534431UL               // 'RSD1'
RTC_NOINIT_ATTR uint32_t rdMagic;
RTC_NOINIT_ATTR char     rdLinkStage[24];   // linkTask (STM32 UART) last stage
RTC_NOINIT_ATTR char     rdBgStage[24];     // backgroundTask last stage
RTC_NOINIT_ATTR uint32_t rdMinFreeHeap;     // ei run-er sorbonimno free heap (8-bit)
RTC_NOINIT_ATTR uint32_t rdMinLargest;      // ei run-er sorbonimno largest free block
RTC_NOINIT_ATTR uint32_t rdMaxPostQBytes;   // postQ RAM-e sorbocho bytes
RTC_NOINIT_ATTR uint32_t rdMaxPostQItems;
RTC_NOINIT_ATTR uint32_t rdUptimeS;         // reset-er age koto s chollo
RTC_NOINIT_ATTR uint32_t rdHeapGuardHits;   // heap kom bole RAM queue-e na tola event
static inline void rdCopy(char* dst, const char* s) {
  size_t i = 0;
  for (; s && s[i] && i < 23; i++) dst[i] = s[i];
  dst[i] = 0;
}
volatile unsigned long linkLastStepMs = 0;  // [LINK STALL] detection
static uint32_t evDupSkipped = 0;          // LOG-FIX: 300 s-er moddhe repeat EV, SD kaj skip
// Heap guard: largest block er kom hole notun event RAM postQ-e tola hoy na (SD/FRAM-e safe).
#define HEAP_GUARD_LARGEST_MIN      20000U
#define HEAP_GUARD_FREE_MIN         40000U
// When normal RAM queue refill is blocked below 40 KB, allow ONE bounded
// SD-backed event to make forward progress, provided real heap headroom remains.
// Do not relax the largest-block guard, and never fill multiple slots in rescue mode.
#define HEAP_GUARD_SINGLE_FREE_MIN 32000U
static inline bool heapOkForQueue(bool emptyQueue) {
  const uint32_t freeH = heap_caps_get_free_size(MALLOC_CAP_8BIT);
  const uint32_t largestH = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
  return largestH >= HEAP_GUARD_LARGEST_MIN &&
         freeH >= (emptyQueue ? HEAP_GUARD_SINGLE_FREE_MIN : HEAP_GUARD_FREE_MIN);
}
static bool postQStats(uint32_t& items, uint32_t& bytes);   // section 12-e definition

portMUX_TYPE debugMux = portMUX_INITIALIZER_UNLOCKED;
volatile uint32_t lastMqttConnectDurationMs = 0;
volatile uint32_t lastMqttRequestDurationMs = 0;
volatile bool mqttConnectInProgress = false;

String mqttExpectedReplyTopic = "";
String mqttReceivedResponse = "";
volatile bool mqttResponseReady = false;
unsigned long mqttRequestSequence = 0;
unsigned long productionEventSequence = 0;

// Connectivity states (WiFi / broker / server / internet alada)
volatile bool netWifiUp = false;
volatile bool netBrokerUp = false;
volatile bool netServerUp = false;
volatile bool netInternetUp = false;
volatile unsigned long lastServerReplyMs = 0;
volatile uint32_t serverTimeoutsInRow = 0;
unsigned long mqttBackoffMs = MQTT_BACKOFF_MIN_MS;

// --- Time Sync ---
volatile bool isTimeSynced = false;
bool timeFromStmRtc = false;
unsigned long lastTimePushMs = 0;
bool timePushedOnce = false;
String macAddressStr = "";
bool wifiStarted = false;
volatile bool netReconfigPending = false;
// BENCH DIAG: passive Arduino WiFi event data. No GPIO, identity or payload change.
volatile uint32_t wifiDisconnectEventCount = 0;
volatile uint8_t wifiLastDisconnectReason = 0;
static uint32_t wifiLastAttemptMs = 0;
static const uint32_t WIFI_JOIN_GRACE_MS = 45000UL;


// =============================================================================
// 5) SESSION VIEW (RAM only) — STM32 CTX frame theke (F3: NVS-e kichu na)
// =============================================================================
bool operatorReady = false;
bool isMaintenanceMode = false;
String technicianName = "NONE";

String lastScannedRfid = "";
volatile bool provisionalLoginActive = false;
String provisionalCardId = "";
String stmMachineBinding = "";
unsigned long lastRfidScanTime = 0;
const unsigned long RFID_SCAN_DEBOUNCE = 1500;

String operatorName = "UNKNOWN";
String locationName = "NONE";
String activeStyle = "NONE";
String activeProcess = "NONE";
double activeSmv = 0.6;
int activeDivisor = 1;
uint32_t currentSessionId = 0;

volatile bool ctxSeen = false;      // STM32 CTX ekbar-o peyechi
volatile bool ctxRecPunch = false;  // card punch: server state (RESTORE) baki
volatile bool ctxTodayLogin = false;
volatile bool ctxAssigned = false;
volatile uint32_t ctxHeld = 0;      // login chhara HELD event (STM32 FRAM)
uint32_t lastDaySeen = 0;

volatile bool isStateRecovered = false;
volatile bool needOledUpdate = false;
volatile bool lastMqttStatusState = false;

Preferences prefs;        // "smu100"  F2-upgrade cleanup only (F3 kichu likhe na)
Preferences cfgPrefs;     // "smucfg"  provisioning
Preferences dbProofPrefs; // "smudbproof" DB-ACK proofs only (no existing key changes)

struct SessLock {
  SessLock()  { xSemaphoreTake(sessionMutex, portMAX_DELAY); }
  ~SessLock() { xSemaphoreGive(sessionMutex); }
};

// =============================================================================
// 6) STM32 STATUS (BOOT / HB / EV theke) + PROFILE BINDING
// =============================================================================
struct StmStatus {
  volatile bool seen;
  volatile int proto;
  volatile int profile;
  volatile long tp, ta, ac;
  volatile int perf;
  volatile int light;
  volatile bool maint, opReady;
  volatile uint32_t outbox;
  volatile uint32_t epoch;
  volatile bool rtcOk;
  volatile int framState;
  volatile uint32_t zRpm, seq, sessionId, faults, lastDelivered, lifeP, lifeA;
  volatile bool aggPending, iwdg;
  volatile long smvMilli;
  volatile int div;
  volatile unsigned long lastMs;
  volatile unsigned long lastHbMs; // Updated ONLY on CRC-valid full STM32 HB frame
  volatile uint32_t resetFlags;
  volatile uint32_t seqEpoch;
  volatile uint32_t prodDay;
  char uid[12];
  char fwRev[24];
} stm = {};

// Bench diagnostics: distinguish actual STM32 frames from a reflected ESP32 EHB.
volatile uint32_t rxBootFrames = 0;
volatile uint32_t rxHbFrames = 0;
volatile uint32_t rxDbgFrames = 0;
volatile uint32_t rxEhbEchoFrames = 0;
volatile uint32_t rxUnknownFrames = 0;
volatile uint32_t rxShortHbFrames = 0;
volatile uint32_t linkCrcErrors = 0;
volatile uint32_t cmdReplyId = 0;
volatile uint32_t cmdAwaitId = 0;
volatile int cmdReplyKind = 0;

int boundProfile = 0;          // NVS-e bound profile (0 = none)
volatile int bindRequest = 0;  // linkTask/console -> background: bind this profile
volatile int holdReason = 1;   // (boot: NO_PROFILE) 0 none, 1 no profile yet, 2 unsupported, 3 mismatch, 4 proto, 5 no identity
const char* HOLD_TEXT[] = { "-", "NO_PROFILE", "UNSUPPORTED", "MISMATCH", "PROTO", "NO_ID" };

// Existing stmAlive() is intentionally unchanged: other functional code depends on
// CRC-valid UART traffic freshness. For diagnostics, require a real STM32 HB.
bool stmAlive() { return stm.lastMs != 0 && (millis() - stm.lastMs) < 3500UL; }
bool stmHeartbeatAlive() { return stm.lastHbMs != 0 && (uint32_t)(millis() - stm.lastHbMs) < 3500UL; }
int32_t stmHeartbeatAgeMs() { return stm.lastHbMs ? (int32_t)(uint32_t)(millis() - stm.lastHbMs) : -1; }
int32_t stmFrameAgeMs() { return stm.lastMs ? (int32_t)(uint32_t)(millis() - stm.lastMs) : -1; }
int activeProfile() { return boundProfile; }
const char* activeProfileName() { return LEGACY[profileValid(boundProfile) ? boundProfile : 0].name; }

// =============================================================================
// 7) FUNCTION DECLARATIONS
// =============================================================================
void stmBeep(uint16_t onMs, uint16_t offMs, uint8_t count);
void tripleBeep();
void errorBeep();
void handleIncomingRfid(String newId);
void readRfid();
void identifyAndProcessRfid(String scannedRfid);
void sendLocationEntryToServer(String lineName, String opName);
void fetchMachineLocation(String& loc, String& style, String& proc, double& smv, int& div);
bool recoverLastMachineState();
void processOfflineQueue(uint32_t lockWaitMs = 0, uint32_t budgetMs = 0);
void syncTimeFirstTime();
void updateOledDisplay();
void backgroundTask(void* pvParameters);
void diagnosticTask(void* pvParameters);
void linkTask(void* pvParameters);
void setDebugCheckpoint(const char* checkpoint);
void printBootDiagnostics();
void printMemoryDiagnostics(const char* tag);
const char* resetReasonText(esp_reset_reason_t reason);
const char* mqttStateText(int state);
void linkSend(const char* body);
void linkSendf(const char* fmt, ...);
int stmCommand(const char* body);
uint32_t qPending();
void resolveIdentity();
void buildServerPayload(JsonDocument& d);
PubResult publishSingleProduction(JsonVariantConst payload, const String& uniqueCode);
extern bool sdOk;
extern volatile uint32_t sdQueueCount;   // BACKLOG 2026-11-02g: SD /smu/custody-te DB-te na jaoa .evt
extern volatile bool sdQueueKnown;
extern volatile uint32_t sdParkedCount;   // PARKED: DB-te jabe na (server support nai)
uint32_t evQueueDropsView();              // EVTASK: queue full-e drop (STM32 abar pathay)
extern bool sdFull;
extern uint32_t sdLogLines;
extern uint32_t rejectedCount;
extern uint32_t sdReceiptGap;
extern uint32_t payloadConflictCount;   // PATCH G: SD .evt != FRAM replay, old .evt quarantined          // 2026-10-27: SD receipt chhara DB-committed + retired event
static int dbProofCount();             // 2026-10-27: QUEUE console-e dekhano

// =============================================================================
// 8) CRASH, WATCHDOG, HEAP AND STACK DIAGNOSTICS  (legacy)
// =============================================================================
extern "C" void IRAM_ATTR esp_task_wdt_isr_user_handler(void) {
  rtcTaskWdtHitCount = rtcTaskWdtHitCount + 1;
}

const char* resetReasonText(esp_reset_reason_t reason) {
  switch (reason) {
    case ESP_RST_UNKNOWN:   return "UNKNOWN";
    case ESP_RST_POWERON:   return "POWER_ON";
    case ESP_RST_EXT:       return "EXTERNAL_PIN";
    case ESP_RST_SW:        return "SOFTWARE_RESET";
    case ESP_RST_PANIC:     return "PANIC_EXCEPTION";
    case ESP_RST_INT_WDT:   return "INTERRUPT_WATCHDOG";
    case ESP_RST_TASK_WDT:  return "TASK_WATCHDOG";
    case ESP_RST_WDT:       return "OTHER_WATCHDOG";
    case ESP_RST_DEEPSLEEP: return "DEEP_SLEEP_WAKE";
    case ESP_RST_BROWNOUT:  return "BROWNOUT";
    case ESP_RST_SDIO:      return "SDIO_RESET";
    default:                return "UNMAPPED";
  }
}

const char* mqttStateText(int state) {
  switch (state) {
    case MQTT_CONNECTION_TIMEOUT:     return "CONNECTION_TIMEOUT";
    case MQTT_CONNECTION_LOST:        return "CONNECTION_LOST";
    case MQTT_CONNECT_FAILED:         return "TCP_CONNECT_FAILED";
    case MQTT_DISCONNECTED:           return "DISCONNECTED";
    case MQTT_CONNECTED:              return "CONNECTED";
    case MQTT_CONNECT_BAD_PROTOCOL:   return "BAD_PROTOCOL";
    case MQTT_CONNECT_BAD_CLIENT_ID:  return "BAD_CLIENT_ID";
    case MQTT_CONNECT_UNAVAILABLE:    return "BROKER_UNAVAILABLE";
    case MQTT_CONNECT_BAD_CREDENTIALS:return "BAD_CREDENTIALS";
    case MQTT_CONNECT_UNAUTHORIZED:   return "UNAUTHORIZED";
    default:                          return "UNKNOWN_STATE";
  }
}

void setDebugCheckpoint(const char* checkpoint) {
  uint32_t freeHeap = heap_caps_get_free_size(MALLOC_CAP_8BIT);
  uint32_t minHeap = heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT);
  portENTER_CRITICAL(&debugMux);
  strncpy(rtcLastCheckpoint, checkpoint, sizeof(rtcLastCheckpoint) - 1);
  rtcLastCheckpoint[sizeof(rtcLastCheckpoint) - 1] = '\0';
  rtcLastCheckpointMillis = millis();
  rtcLastFreeHeap = freeHeap;
  rtcLastMinimumHeap = minHeap;
  portEXIT_CRITICAL(&debugMux);
}

void printBootDiagnostics() {
  esp_reset_reason_t reason = esp_reset_reason();
  Serial.println("\n================ BOOT / RESET DEBUG ================");
  Serial.printf("[BOOT] Firmware           : %s | UART proto v%d\n", FW_REV, PROTO_VER);
  Serial.printf("[BOOT] Build tag          : %s\n", BUILD_TAG);
  Serial.printf("[BOOT] Reset reason       : %s (%d)\n", resetReasonText(reason), (int)reason);
  Serial.printf("[BOOT] Previous boot count: %lu\n", (unsigned long)rtcBootCount);
  Serial.printf("[BOOT] WDT ISR hit count  : %lu\n", (unsigned long)rtcTaskWdtHitCount);
  Serial.printf("[BOOT] Last checkpoint    : %s\n", rtcLastCheckpoint);
  Serial.printf("[BOOT] Checkpoint millis  : %lu\n", (unsigned long)rtcLastCheckpointMillis);
  Serial.printf("[BOOT] Heap at checkpoint : free=%lu, minimum=%lu bytes\n",
                (unsigned long)rtcLastFreeHeap, (unsigned long)rtcLastMinimumHeap);
  Serial.printf("[BOOT] ESP-IDF version    : %s\n", esp_get_idf_version());
  Serial.printf("[BOOT] CPU frequency      : %u MHz\n", (unsigned)ESP.getCpuFreqMHz());
  Serial.printf("[BOOT] Flash size         : %lu bytes\n", (unsigned long)ESP.getFlashChipSize());
  Serial.printf("[BOOT] Sketch size/free   : %lu / %lu bytes\n",
                (unsigned long)ESP.getSketchSize(), (unsigned long)ESP.getFreeSketchSpace());
  Serial.printf("[BOOT] Task WDT           : ENABLED %d s (linkTask, backgroundTask subscribed)\n", ESP_TASK_WDT_TIMEOUT_S);

  // ---- RESET-DEBUG 2026-11-02: reset reason-er mane + ager run-er forensics ----
  const char* hint = "";
  switch (reason) {
    case ESP_RST_POWERON:  hint = "Power cut / supply off-on, ATHOBA STM32 PB5 diye ESP32 EN reset "
                                  "(STM32 boot hole ba 30 s EHB na pele). [STM-DIAG] espResetByStm dekhun."; break;
    case ESP_RST_TASK_WDT: hint = "Kono task 30 s atke chilo (SD / MQTT / mutex). Niche [PREV RUN] stage = doshi jayga."; break;
    case ESP_RST_PANIC:    hint = "CRASH: exception / out-of-memory abort / stack overflow. [PREV RUN] heap ar stage dekhun."; break;
    case ESP_RST_BROWNOUT: hint = "3.3V supply dip (WiFi TX current spike). Power supply / bulk capacitor / regulator check."; break;
    case ESP_RST_INT_WDT:  hint = "Interrupt WDT: ISR / critical section beshi lomba (ba flash/SD bus atke)."; break;
    case ESP_RST_SW:       hint = "Software restart (REBOOT / FORMAT command)."; break;
    default:               hint = "-"; break;
  }
  Serial.printf("[RESET HINT] %s\n", hint);
  if (rdMagic == RD_MAGIC) {
    rdLinkStage[23] = 0; rdBgStage[23] = 0;
    Serial.printf("[PREV RUN] uptime=%lu s | linkTask stage=%s | backgroundTask stage=%s\n",
                  (unsigned long)rdUptimeS, rdLinkStage, rdBgStage);
    Serial.printf("[PREV RUN] heap min free=%lu B, min largest block=%lu B | postQ max=%lu items / %lu B | heapGuardHits=%lu\n",
                  (unsigned long)rdMinFreeHeap, (unsigned long)rdMinLargest,
                  (unsigned long)rdMaxPostQItems, (unsigned long)rdMaxPostQBytes, (unsigned long)rdHeapGuardHits);
    if (rdMinLargest && rdMinLargest < 16000UL)
      Serial.println("[PREV RUN] VERDICT: heap fragmented/LOW chilo -> memory jonito crash somvob");
    else
      Serial.println("[PREV RUN] VERDICT: heap OK chilo -> memory full karon NA (onno karon dekhun)");
  } else {
    Serial.println("[PREV RUN] no data (power-on / first boot after flash)");
  }
  rdMagic = RD_MAGIC;
  rdCopy(rdLinkStage, "BOOT");
  rdCopy(rdBgStage, "BOOT");
  rdMinFreeHeap = heap_caps_get_free_size(MALLOC_CAP_8BIT);
  rdMinLargest = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
  rdMaxPostQBytes = 0; rdMaxPostQItems = 0; rdUptimeS = 0; rdHeapGuardHits = 0;

  Serial.println("====================================================\n");
  rtcBootCount++;
}

void printMemoryDiagnostics(const char* tag) {
  const size_t free8 = heap_caps_get_free_size(MALLOC_CAP_8BIT);
  const size_t min8 = heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT);
  const size_t largest8 = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
  const size_t freeInternal = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  const size_t largestInternal = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  const size_t freePsram = heap_caps_get_free_size(MALLOC_CAP_SPIRAM);
  const bool heapIntegrityOk = heap_caps_check_integrity_all(false);
  const uint32_t fragmentationPct = free8 > 0 ? (uint32_t)(100UL - ((largest8 * 100UL) / free8)) : 0;

  UBaseType_t currentStackWords = uxTaskGetStackHighWaterMark(NULL);
  UBaseType_t loopStackWords = loopTaskHandler ? uxTaskGetStackHighWaterMark(loopTaskHandler) : 0;
  UBaseType_t bgStackWords = backgroundTaskHandle ? uxTaskGetStackHighWaterMark(backgroundTaskHandle) : 0;
  UBaseType_t diagStackWords = diagnosticTaskHandle ? uxTaskGetStackHighWaterMark(diagnosticTaskHandle) : 0;
  UBaseType_t linkStackWords = linkTaskHandle ? uxTaskGetStackHighWaterMark(linkTaskHandle) : 0;

  Serial.printf("\n[MEM][%s] task=%s core=%d priority=%u uptime=%lu ms\n",
                tag, pcTaskGetName(NULL), xPortGetCoreID(), (unsigned)uxTaskPriorityGet(NULL), (unsigned long)millis());
  Serial.printf("[MEM] heap8 free=%u min=%u largest=%u fragmentation=%lu%% integrity=%s\n",
                (unsigned)free8, (unsigned)min8, (unsigned)largest8, (unsigned long)fragmentationPct,
                heapIntegrityOk ? "OK" : "CORRUPT");
  Serial.printf("[MEM] internal free=%u largest=%u | psram free=%u\n",
                (unsigned)freeInternal, (unsigned)largestInternal, (unsigned)freePsram);
  Serial.printf("[STACK] current=%u B | loop=%u B | background=%u B | diagnostic=%u B | link=%u B\n",
                (unsigned)(currentStackWords * sizeof(StackType_t)), (unsigned)(loopStackWords * sizeof(StackType_t)),
                (unsigned)(bgStackWords * sizeof(StackType_t)), (unsigned)(diagStackWords * sizeof(StackType_t)),
                (unsigned)(linkStackWords * sizeof(StackType_t)));
  Serial.printf("[NET] WiFi=%d RSSI=%d broker=%s(%d) server=%d internet=%d connectBusy=%s\n",
                (int)WiFi.status(), WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : 0,
                mqttStateText(mqttClient.state()), mqttClient.state(), netServerUp ? 1 : 0,
                netInternetUp ? 1 : 0, mqttConnectInProgress ? "YES" : "NO");
  Serial.printf("[TIME] last MQTT connect=%lu ms | last MQTT request=%lu ms | synced=%d\n",
                (unsigned long)lastMqttConnectDurationMs, (unsigned long)lastMqttRequestDurationMs, isTimeSynced ? 1 : 0);
  Serial.printf("[QUEUE] pending=%lu sdOk=%d sdReceiptGap=%lu\n", (unsigned long)qPending(), sdOk ? 1 : 0,
                (unsigned long)sdReceiptGap);
  // Diagnostic status is heartbeat-qualified; STM32 metadata is cached when HB is lost.
  const bool stmHbUp = stmHeartbeatAlive();
  Serial.printf("[STM32] alive=%d proto=%d profile=%d bound=%d hold=%s tp=%ld ta=%ld ac=%ld outbox=%lu agg=%d fram=%d rtc=%d faults=0x%04lX crcErr=%lu\n",
                stmHbUp ? 1 : 0, stm.proto, stm.profile, boundProfile, HOLD_TEXT[holdReason], stm.tp, stm.ta, stm.ac,
                (unsigned long)stm.outbox, stm.aggPending ? 1 : 0, stmHbUp ? (int)stm.framState : -1, stmHbUp ? (int)stm.rtcOk : -1,
                (unsigned long)stm.faults, (unsigned long)linkCrcErrors);
  Serial.printf("[STM-LINK] HB_LIVE=%u HB_AGE_MS=%ld UART_RX_AGE_MS=%ld (FRAM/RTC=-1 means STALE, not hardware fault)\n",
                stmHbUp ? 1u : 0u, (long)stmHeartbeatAgeMs(), (long)stmFrameAgeMs());
  Serial.printf("[UART RX COUNT] BOOT=%lu HB=%lu DBG=%lu EHB_ECHO=%lu UNKNOWN=%lu SHORT_HB=%lu CRC_BAD=%lu\n",
                (unsigned long)rxBootFrames, (unsigned long)rxHbFrames,
                (unsigned long)rxDbgFrames, (unsigned long)rxEhbEchoFrames,
                (unsigned long)rxUnknownFrames, (unsigned long)rxShortHbFrames,
                (unsigned long)linkCrcErrors);
  Serial.printf("[CHECKPOINT] %s at %lu ms\n", rtcLastCheckpoint, (unsigned long)rtcLastCheckpointMillis);
}

// No filesystem writes: watchdog forensic markers only.
static volatile uint32_t bgLastProgressMs = 0;
static const char* volatile bgStage = "NOT_STARTED";
// RESET-DEBUG: stage RTC_NOINIT-e-o copy (TWDT/panic reset-er por [PREV RUN]-e dekhabe)
static inline void bgSetStage(const char* s) { bgStage = s; rdCopy(rdBgStage, s); }

void diagnosticTask(void* pvParameters) {
  diagnosticTaskHandle = xTaskGetCurrentTaskHandle();
  vTaskDelay(pdMS_TO_TICKS(1000));
  for (;;) {
#if ESP_DIAG_PERIODIC
    static uint32_t lastFull = 0;
    uint32_t nowDiag = millis();
    if (lastFull == 0 || (uint32_t)(nowDiag - lastFull) >= 30000UL) {
      printMemoryDiagnostics("PERIODIC");
      lastFull = nowDiag;
    } else {
      const bool stmHbUp = stmHeartbeatAlive();
      Serial.printf("[LIVE] t=%lus STM=%u HB_AGE_MS=%ld UART_RX_AGE_MS=%ld FRAM=%d RTC=%d faults=0x%04lX UART_CRC=%lu WiFi=%d MQTT=%d\n",
          (unsigned long)(nowDiag/1000UL),stmHbUp?1u:0u, (long)stmHeartbeatAgeMs(), (long)stmFrameAgeMs(),
          stmHbUp ? (int)stm.framState : -1, stmHbUp ? (int)stm.rtcOk : -1, (unsigned long)stm.faults,
          (unsigned long)linkCrcErrors,(int)WiFi.status(),mqttClient.connected()?1:0);
    }
#endif
    const uint32_t bgAgeMs = bgLastProgressMs ? (uint32_t)(millis() - bgLastProgressMs) : 0;
    if (bgLastProgressMs && bgAgeMs >= 10000UL) {
      Serial.printf("[BG STALL SUSPECT] no_stage_transition_ms=%lu stage=%s (DIAG_ONLY)\n",
                    (unsigned long)bgAgeMs, bgStage);
    }

    // ---- RESET-DEBUG 2026-11-02: memory health + RTC forensics update ----
    {
      const uint32_t nowH = millis();
      const uint32_t freeH = heap_caps_get_free_size(MALLOC_CAP_8BIT);
      const uint32_t minH = heap_caps_get_minimum_free_size(MALLOC_CAP_8BIT);
      const uint32_t largH = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT);
      uint32_t qItems = 0, qBytes = 0;
      const bool qOk = postQStats(qItems, qBytes);
      if (freeH < rdMinFreeHeap) rdMinFreeHeap = freeH;
      if (largH < rdMinLargest) rdMinLargest = largH;
      if (qOk && qBytes > rdMaxPostQBytes) rdMaxPostQBytes = qBytes;
      if (qOk && qItems > rdMaxPostQItems) rdMaxPostQItems = qItems;
      rdUptimeS = nowH / 1000UL;

      const uint32_t linkStackB = linkTaskHandle ? uxTaskGetStackHighWaterMark(linkTaskHandle) * sizeof(StackType_t) : 0;
      const uint32_t bgStackB = backgroundTaskHandle ? uxTaskGetStackHighWaterMark(backgroundTaskHandle) * sizeof(StackType_t) : 0;
      const uint32_t diagStackB = uxTaskGetStackHighWaterMark(NULL) * sizeof(StackType_t);
      const char* verdict = (largH < 8000U || freeH < 20000U) ? "CRITICAL" :
                            (largH < HEAP_GUARD_LARGEST_MIN || freeH < HEAP_GUARD_SINGLE_FREE_MIN) ? "LOW" :
                            (freeH < HEAP_GUARD_FREE_MIN && qItems == 0) ? "DRAIN_1" :
                            (freeH < HEAP_GUARD_FREE_MIN) ? "LOW" : "OK";
      static uint32_t lastMemPrint = 0;
      const bool bad = !strcmp(verdict, "CRITICAL") || !strcmp(verdict, "LOW") ||
                       (linkStackB && linkStackB < 1024U) || (bgStackB && bgStackB < 1536U);
      if (lastMemPrint == 0 || (uint32_t)(nowH - lastMemPrint) >= 30000UL || bad) {
        lastMemPrint = nowH;
        Serial.printf("[MEM-HEALTH] %s | heap free=%lu min=%lu largest=%lu | postQ=%lu items %lu B%s | "
                      "stackFree link=%lu bg=%lu diag=%lu | heapGuardHits=%lu evDupSkip=%lu\n",
                      verdict, (unsigned long)freeH, (unsigned long)minH, (unsigned long)largH,
                      (unsigned long)qItems, (unsigned long)qBytes, qOk ? "" : "(busy)",
                      (unsigned long)linkStackB, (unsigned long)bgStackB, (unsigned long)diagStackB,
                      (unsigned long)rdHeapGuardHits, (unsigned long)evDupSkipped);
        Serial.printf("[DB-BACKLOG] DB-te jay ni ~%lu = SD queue %s%lu + STM32 FRAM %lu (HELD %lu) | RAM postQ %lu | PARKED %lu | evQDrop %lu\n",
                      (unsigned long)((sdQueueKnown ? sdQueueCount : 0) + stm.outbox), sdQueueKnown ? "" : "(gona cholche) ",
                      (unsigned long)sdQueueCount, (unsigned long)stm.outbox, (unsigned long)ctxHeld, (unsigned long)qItems,
                      (unsigned long)sdParkedCount, (unsigned long)evQueueDropsView());
        if (linkStackB && linkStackB < 1024U) Serial.println("[MEM-HEALTH] WARN linkTask stack < 1 KB (overflow -> PANIC reset risk)");
        if (bgStackB && bgStackB < 1536U) Serial.println("[MEM-HEALTH] WARN backgroundTask stack < 1.5 KB");
      }
      const unsigned long lls = linkLastStepMs;
      if (lls && (int32_t)(nowH - lls) >= 10000) {     // signed: linkTask nowH-er pore update korle negative
        rdLinkStage[23] = 0;
        Serial.printf("[LINK STALL] linkTask %lu ms atke ache, stage=%s. 30 s holei STM32 ESP32-ke reset korbe "
                      "(EHB jabe na) / Task WDT.\n", (unsigned long)(nowH - lls), rdLinkStage);
      }
    }
    vTaskDelay(pdMS_TO_TICKS(DIAGNOSTIC_INTERVAL_MS));
  }
}

static inline void wdtResetIfSubscribed() {
  if (esp_task_wdt_status(NULL) == ESP_OK) esp_task_wdt_reset();
}

void setupTaskWatchdog() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
  esp_task_wdt_config_t c = {};
  c.timeout_ms = ESP_TASK_WDT_TIMEOUT_S * 1000;
  c.idle_core_mask = 0;
  c.trigger_panic = true;
  if (esp_task_wdt_reconfigure(&c) != ESP_OK) esp_task_wdt_init(&c);
#else
  esp_task_wdt_init(ESP_TASK_WDT_TIMEOUT_S, true);
#endif
}

// =============================================================================
// 9) PROVISIONING (NVS "smucfg") + IDENTITY RESOLUTION
// =============================================================================
void loadNetCfg() {
  cfg.machineId = cfgPrefs.getString("machineId", "");
  cfg.ssid      = cfgPrefs.getString("ssid", "");
  cfg.pass      = cfgPrefs.getString("pass", DEFAULT_WIFI_PASS);
  cfg.mqttHost  = cfgPrefs.getString("mqttHost", "");
  cfg.mqttPort  = (uint16_t)cfgPrefs.getUInt("mqttPort", DEFAULT_MQTT_PORT);
  cfg.mqttUser  = cfgPrefs.getString("mqttUser", "");
  cfg.mqttPass  = cfgPrefs.getString("mqttPass", "");
  cfg.ntp       = cfgPrefs.getString("ntp", DEFAULT_NTP_SERVER);
  cfg.tzSec     = cfgPrefs.getLong("tz", DEFAULT_TZ_OFFSET_SEC);
  cfg.tAssets   = cfgPrefs.getUInt("tAssets", T_ASSETS_MS);
  cfg.tProdPost = cfgPrefs.getUInt("tProdPost", T_PROD_POST_MS);
  cfg.tProdGet  = cfgPrefs.getUInt("tProdGet", T_PROD_GET_MS);
  cfg.tLocation = cfgPrefs.getUInt("tLocation", T_LOCATION_MS);
  cfg.tLayout   = cfgPrefs.getUInt("tLayout", T_LAYOUT_MS);
  boundProfile  = cfgPrefs.getInt("bprof", 0);
  if (!profileValid(boundProfile)) boundProfile = 0;
}

// Provisioned value > bound-profile legacy default. Machine ID kokhono onno
// profile-er default theke ashe na.
String resolvedSsid, resolvedHost, resolvedPass, resolvedUser, resolvedMqttPass;

void resolveIdentity() {
  int p = boundProfile;
  String id = cfg.machineId.length() ? cfg.machineId : String(profileValid(p) ? LEGACY[p].machineId : "");
  String s = cfg.ssid.length() ? cfg.ssid : String(LEGACY[profileValid(p) ? p : 0].ssid);
  String h = cfg.mqttHost.length() ? cfg.mqttHost : String(LEGACY[profileValid(p) ? p : 0].host);
  bool netChanged = (s != resolvedSsid) || (h != resolvedHost);
  {
    SessLock l;
    MACHINE_ID = id;
  }
  resolvedSsid = s;
  resolvedHost = h;
  resolvedPass = cfg.pass;
  resolvedUser = cfg.mqttUser;
  resolvedMqttPass = cfg.mqttPass;
  ssid = resolvedSsid.c_str();
  password = resolvedPass.c_str();
  MQTT_BROKER_HOST = resolvedHost.c_str();
  MQTT_BROKER_PORT = cfg.mqttPort;
  MQTT_USERNAME = resolvedUser.c_str();
  MQTT_PASSWORD = resolvedMqttPass.c_str();
  if (netChanged && wifiStarted) netReconfigPending = true;
  Serial.printf("[IDENTITY] profile=%d(%s) machineId=%s%s ssid=%s broker=%s:%u\n", p, activeProfileName(),
                MACHINE_ID.c_str(), cfg.machineId.length() ? " (provisioned)" : " (legacy default)",
                ssid, MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  if (!cfg.machineId.length() && (p == PROFILE_OVERLOCK_IR || p == PROFILE_ENCODER_BJ100))
    Serial.println("[IDENTITY WARN] Profile 2 and 5 legacy default ID same (SEWING_MAC_01(SLEEVE_JOIN)). Provision machineId!");
}

void evaluateHold();
void serviceBindRequest() {
  int p = bindRequest;
  if (p == 0) return;
  bindRequest = 0;
  if (profileValid(p) && p != boundProfile) bindProfile(p);
  evaluateHold();
}

void bindProfile(int p) {
  boundProfile = p;
  cfgPrefs.putInt("bprof", p);
  Serial.printf("[PROFILE] Bound to STM32 profile %d (%s)\n", p, LEGACY[p].name);
  resolveIdentity();
}

// HOLD evaluation — STM32 profile / proto / identity
void evaluateHold() {
  int r = 0;
  if (!stm.seen) r = 1;
  else if (stm.proto != PROTO_VER) r = 4;
  else if (!profileValid(stm.profile)) r = 2;
  else if (boundProfile == 0) {
#if AUTO_BIND_FIRST_PROFILE
    bindRequest = stm.profile;          // bind backgroundTask/setup-e (identity String ekta task-ei badlay)
    r = 1;
#else
    r = 3;
#endif
  }
  if (r == 0 && boundProfile != stm.profile) r = 3;
  if (r == 0 && MACHINE_ID.length() == 0) r = 5;
  if (r != holdReason) {
    holdReason = r;
    needOledUpdate = true;
    if (r) Serial.printf("[HOLD] Publishing blocked: %s (STM profile=%d proto=%d bound=%d). Events stay in STM32 FRAM.\n",
                         HOLD_TEXT[r], stm.profile, stm.proto, boundProfile);
    else Serial.println("[HOLD] Cleared.");
  }
}

void printCfg() {
  Serial.println("---- SMU-100 ESP32 CONFIG ----");
  Serial.printf("machineId : %s (resolved: %s)\n", cfg.machineId.c_str(), MACHINE_ID.c_str());
  Serial.printf("ssid      : %s (resolved: %s)\n", cfg.ssid.c_str(), ssid);
  Serial.printf("pass      : %s\n", cfg.pass.length() ? "****" : "(empty)");
  Serial.printf("mqttHost  : %s (resolved: %s) port %u\n", cfg.mqttHost.c_str(), MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  Serial.printf("mqttUser  : %s\n", cfg.mqttUser.c_str());
  Serial.printf("ntp / tz  : %s / %ld s\n", cfg.ntp.c_str(), cfg.tzSec);
  Serial.printf("timeouts  : assets=%lu prodPost=%lu prodGet=%lu location=%lu layout=%lu ms\n",
                (unsigned long)cfg.tAssets, (unsigned long)cfg.tProdPost, (unsigned long)cfg.tProdGet,
                (unsigned long)cfg.tLocation, (unsigned long)cfg.tLayout);
  Serial.printf("profile   : bound=%d(%s) stm=%d proto=%d hold=%s\n", boundProfile, activeProfileName(),
                stm.profile, stm.proto, HOLD_TEXT[holdReason]);
  SessLock l;
  Serial.printf("session   : (STM32 FRAM) sid=%lu op=%s ready=%d loc=%s style=%s proc=%s smv=%.3f div=%d maint=%d tech=%s held=%lu recPunch=%d\n",
                (unsigned long)currentSessionId, operatorName.c_str(), operatorReady ? 1 : 0, locationName.c_str(),
                activeStyle.c_str(), activeProcess.c_str(), activeSmv, activeDivisor, isMaintenanceMode ? 1 : 0,
                technicianName.c_str(), (unsigned long)ctxHeld, ctxRecPunch ? 1 : 0);
}

// READ-ONLY SERIAL VIEW: STM32 session snapshot + current ESP32 network state.
// No UART commands, NVS/FRAM/SD writes, or session changes.
static void printQuickInfo() {
  String op, style, machine;
  int divisor;
  bool ready, provisional, seenCtx;
  {
    SessLock l;
    op = operatorName;
    style = activeStyle;
    machine = MACHINE_ID;
    divisor = activeDivisor;
    ready = operatorReady;
    provisional = provisionalLoginActive;
    seenCtx = ctxSeen;
  }

  const bool hbLive = stmHeartbeatAlive();
  const bool wifiUp = (WiFi.status() == WL_CONNECTED);
  const bool mqttUp = netBrokerUp; // Existing connectivity state; no MQTT mutex/blocking call.
  const String activeSsid = wifiUp ? WiFi.SSID() : String(ssid); // Configured SSID when offline.

  Serial.println("--- SMU-100 INFO (READ ONLY) ---");
  Serial.printf("Operator : %s (%s)\n", op.c_str(),
                !seenCtx ? "CTX_NOT_RECEIVED" : !hbLive ? "CTX_STALE" :
                provisional ? "PENDING_VALIDATION" : ready ? "ACTIVE" : "NOT_LOGGED_IN");
  Serial.printf("Style    : %s\n", style.c_str());
  Serial.printf("Machine  : %s (profile=%s)\n", machine.c_str(), activeProfileName());
  Serial.printf("Divisor  : %d\n", divisor);
  Serial.printf("Network  : %s (WiFi)\n", wifiUp ? "ON" : "OFF");
  Serial.printf("SSID     : %s%s\n", activeSsid.c_str(), wifiUp ? "" : " (configured, not connected)");
  if (wifiUp) Serial.printf("RSSI     : %d dBm\n", WiFi.RSSI());
  else Serial.println("RSSI     : N/A (WiFi OFF)");
  Serial.printf("MQTT     : %s\n", mqttUp ? "ON" : "OFF");
  Serial.printf("STM32 HB : %s\n", hbLive ? "LIVE" : "OFFLINE");
  Serial.println("-------------------------------");
}

// SMU RECOVERY V1: /smu only; bounded SD streaming, no in-place mutation.
static bool recoverySafePath(const String& p) {
  if (!(p=="/" || p.startsWith("/")) || p.length()>120 || p.indexOf("..")>=0 || p.indexOf("//")>=0) return false;
  for (unsigned i=0;i<p.length();i++) {
    char c=p[i];
    if (!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='/'||c=='.'||c=='_'||c=='-')) return false;
  }
  return true;
}
static void recoverySdList(const String& dir);
static void recoverySdRead(const String& arg);
static void recoverySdStage(const String& arg);
static void recoverySdCommit(const String& arg);
static void recoverySdQuarantine(const String& arg);
// ADD-ONLY: read individual custody files from Serial without altering production flow.
static void consoleReadCustodyFile(const String& command, const String& argument);
// STORAGE FORMAT (2026-10-26): definition section 22a-te
static void consoleFormatFram(const String& arg);
static void consoleFormatSd(const String& arg);
static void consoleFormatNvs(const String& arg);

void handleConsoleLine(String line) {
  line.trim();
  if (!line.length()) return;
  int sp = line.indexOf(' ');
  String cmd = sp < 0 ? line : line.substring(0, sp);
  String rest = sp < 0 ? "" : line.substring(sp + 1);
  cmd.toUpperCase();
  rest.trim();
  if (cmd == "HELP") {
    Serial.println("HELP | SHOW | INFO | SET <key> <value> | CLEAR <key> | PROFILE ACCEPT | QUEUE | REBOOT");
    Serial.println("READ_EVT <24HEX[.evt] or /smu/custody/...evt> | READ_OK <24HEX[.ok] or /smu/custody/...ok> (read-only CRC verified)");
    Serial.println("FRAM_READ <addr_dec_0..32736_step32> | SD_LIST <dir> | SD_READ <path> <offset_dec>");
    Serial.println("SD_STAGE <id> <offset_dec> <hex_bytes> | SD_COMMIT <id> <path> <size> <crc32hex>");
    Serial.println("SD_QUARANTINE <path> <id> <size> <crc32hex> (no physical delete; bench only)");
    Serial.println("FORMAT_FRAM YES | FORMAT_SD YES | FORMAT_NVS YES  (DESTRUCTIVE; YES chhara shudhu warning)");
    Serial.println("keys: machineId ssid pass mqttHost mqttPort mqttUser mqttPass ntp tz tAssets tProdPost tProdGet tLocation tLayout");
  } else if (cmd == "SHOW") {
    printCfg();
  } else if (cmd == "INFO") {
    printQuickInfo();
  } else if (cmd == "SET" || cmd == "CLEAR") {
    int sp2 = rest.indexOf(' ');
    String key = (cmd == "CLEAR") ? rest : (sp2 < 0 ? rest : rest.substring(0, sp2));
    String val = (cmd == "CLEAR" || sp2 < 0) ? "" : rest.substring(sp2 + 1);
    val.trim();
    const char* strKeys[] = { "machineId", "ssid", "pass", "mqttHost", "mqttUser", "mqttPass", "ntp" };
    const char* numKeys[] = { "mqttPort", "tAssets", "tProdPost", "tProdGet", "tLocation", "tLayout" };
    bool done = false;
    for (const char* k : strKeys) if (key == k) {
      if (cmd == "CLEAR") cfgPrefs.remove(k); else cfgPrefs.putString(k, val);
      done = true;
    }
    for (const char* k : numKeys) if (key == k) {
      if (cmd == "CLEAR") cfgPrefs.remove(k);
      else {
        long v = val.toInt();
        if (v <= 0 || v > 65535L * 4) { Serial.println("[CFG] invalid number"); return; }
        cfgPrefs.putUInt(k, (uint32_t)v);
      }
      done = true;
    }
    if (key == "tz") {
      if (cmd == "CLEAR") cfgPrefs.remove("tz"); else cfgPrefs.putLong("tz", val.toInt());
      done = true;
    }
    if (!done) { Serial.println("[CFG] unknown key"); return; }
    loadNetCfg();
    Serial.println("[CFG] saved. Apply hobe REBOOT-er por (running identity/network change kora hoy na).");
  } else if (cmd == "PROFILE") {
    rest.toUpperCase();
    if (rest == "ACCEPT") {
      if (stm.seen && profileValid(stm.profile)) {
        bindRequest = stm.profile;               // backgroundTask bind korbe
        Serial.printf("[PROFILE] Bind to %d requested\n", stm.profile);
      } else Serial.println("[PROFILE] STM32 profile unknown/unsupported — cannot accept");
    } else printCfg();
  } else if (cmd == "QUEUE") {
    Serial.printf("[DB-BACKLOG] DB-te jay ni MOT ~%lu = SD queue %s%lu + STM32 FRAM %lu (er moddhe HELD/login chhara %lu) | RAM postQ %lu (SD queue-r ongsho) | PARKED %lu (server support nai, /smu/parked)\n",
                  (unsigned long)((sdQueueKnown ? sdQueueCount : 0) + stm.outbox), sdQueueKnown ? "" : "(gona cholche) ",
                  (unsigned long)sdQueueCount, (unsigned long)stm.outbox, (unsigned long)ctxHeld, (unsigned long)qPending(),
                  (unsigned long)sdParkedCount);
    Serial.printf("[QUEUE] dbPending=%lu stmFramOutbox=%lu heldNoLogin=%lu sdOk=%d sdFull=%d sdLogLines=%lu rejected=%lu sdReceiptGap=%lu dbProofs=%d payloadConflict=%lu\n",
                  (unsigned long)qPending(), (unsigned long)stm.outbox, (unsigned long)ctxHeld, sdOk ? 1 : 0, sdFull ? 1 : 0,
                  (unsigned long)sdLogLines, (unsigned long)rejectedCount, (unsigned long)sdReceiptGap, dbProofCount(), (unsigned long)payloadConflictCount);
  } else if (cmd == "FRAM_READ") {
    uint32_t a=(uint32_t)strtoul(rest.c_str(),nullptr,10);
    if (rest.length()==0 || a>32736UL || a%32U) Serial.println("@FRERR,BAD_ADDR");
    else linkSendf("FRD,%lu",(unsigned long)a);
  } else if (cmd == "SD_LIST") {
    recoverySdList(rest);
  } else if (cmd == "SD_READ") {
    recoverySdRead(rest);
  } else if (cmd == "SD_STAGE") {
    recoverySdStage(rest);
  } else if (cmd == "SD_COMMIT") {
    recoverySdCommit(rest);
  } else if (cmd == "SD_QUARANTINE") {
    recoverySdQuarantine(rest);
  } else if (cmd == "READ_EVT" || cmd == "READ_OK") {
    consoleReadCustodyFile(cmd, rest);
  } else if (cmd == "FORMAT_FRAM") {
    consoleFormatFram(rest);
  } else if (cmd == "FORMAT_SD") {
    consoleFormatSd(rest);
  } else if (cmd == "FORMAT_NVS") {
    consoleFormatNvs(rest);
  } else if (cmd == "REBOOT") {
    ESP.restart();
  } else {
    Serial.println("[CFG] unknown command (HELP)");
  }
}

void serviceConsole() {
  static String buf;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') { if (buf.length()) handleConsoleLine(buf); buf = ""; }
    else if (buf.length() < 160) buf += c;
  }
}

// =============================================================================
// 10) UNIQUE CODE / NTP / WIFI  (legacy)
// =============================================================================
// isTimeSynced = SNTP server-e sotti sync hoyeche (STM32 RTC theke set kora time "synced" noy)
void syncTimeFirstTime() {
  if (isTimeSynced || WiFi.status() != WL_CONNECTED) return;
  Serial.println("[RTC] Synchronizing Internal Clock with NTP Server...");
  configTime(cfg.tzSec, 0, cfg.ntp.c_str());
  struct tm timeinfo;
  int retry = 0;
  while (sntp_get_sync_status() != SNTP_SYNC_STATUS_COMPLETED && retry < 20) {
    wdtResetIfSubscribed();
    vTaskDelay(pdMS_TO_TICKS(100));
    retry++;
  }
  if (sntp_get_sync_status() == SNTP_SYNC_STATUS_COMPLETED && getLocalTime(&timeinfo, 100)) {
    isTimeSynced = true;
    netInternetUp = true;
    Serial.printf("[RTC] Time Synced: %04d-%02d-%02d %02d:%02d:%02d (local)\n",
                  timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday,
                  timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
  } else {
    Serial.println("[RTC WARN] NTP Timeout (internet/NTP unreachable). Will retry later.");
  }
}

void pushTimeToStm() {
  // Do not cause a new production day/RTC jump with unresolved FRAM history.
  if (!stmAlive() || stm.outbox != 0 || stm.aggPending || provisionalLoginActive) {
    static uint32_t lastNotice = 0;
    if (lastNotice == 0 || (uint32_t)(millis() - lastNotice) > 60000UL) {
      lastNotice = millis();
      Serial.println("[TIME-SERVER] STM RTC update deferred: pending journal/session; old timestamps untouched");
    }
    return;
  }
  time_t now = time(nullptr);
  if ((unsigned long)now < 1700000000UL) return;
  linkSendf("TIME,%lu", (unsigned long)now);     // epoch = UTC (DS3231 UTC rakhe)
  lastTimePushMs = millis();
  timePushedOnce = true;
}

void connectWiFi(bool forceWait = false) {
  if (WiFi.status() == WL_CONNECTED && !netReconfigPending) return;
  if (!ssid || !*ssid) {
    Serial.println("[WIFI-DIAG] NO_SSID configured; use SHOW/read-only config audit");
    return;
  }
  const bool reconfig = netReconfigPending;
  const uint32_t now = millis();
  // Guard: do not interrupt an in-progress association/auth/DHCP every 10s.
  // In particular, never do disconnect() immediately followed by begin()
  // on routine retries: that caused "sta is connecting, cannot set config".
  if (wifiStarted && !reconfig &&
      (uint32_t)(now - wifiLastAttemptMs) < WIFI_JOIN_GRACE_MS) return;
  if (!wifiStarted) {
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);     // 24 V powered device: avoid Wi-Fi modem-sleep receive latency
    WiFi.setAutoReconnect(true);
    WiFi.begin(ssid, password);
    wifiStarted = true;
    Serial.printf("[WIFI-DIAG] INIT status=%d ssid=%s\n", (int)WiFi.status(), ssid);
  } else if (reconfig) {
    // Explicit user config changes only; preserve existing provisioning semantics.
    WiFi.disconnect();
    vTaskDelay(pdMS_TO_TICKS(250));
    WiFi.begin(ssid, password);
    Serial.printf("[WIFI-DIAG] RECONFIG status=%d ssid=%s\n", (int)WiFi.status(), ssid);
  } else {
    // Core reconnect uses configured credentials instead of reconfiguring STA
    // while ESP-IDF is still trying to associate.
    bool kicked = WiFi.reconnect();
    Serial.printf("[WIFI-DIAG] RETRY after=%lu ms status=%d kicked=%d reason=%u events=%lu ssid=%s\n",
                  (unsigned long)(now - wifiLastAttemptMs), (int)WiFi.status(), kicked?1:0,
                  (unsigned)wifiLastDisconnectReason,
                  (unsigned long)wifiDisconnectEventCount, ssid);
  }
  wifiLastAttemptMs = millis();
  netReconfigPending = false;

  if (forceWait) {
    int retries = 0;
    while (WiFi.status() != WL_CONNECTED && retries < 6) {
      vTaskDelay(pdMS_TO_TICKS(500));
      retries++;
    }
  }
}
// =============================================================================
// 11) MQTT  (legacy request/response; per-op timeout; mutex protected)
// =============================================================================
void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String incomingTopic = String(topic);
  incomingTopic.trim();
  if (mqttExpectedReplyTopic.length() == 0 || !incomingTopic.equals(mqttExpectedReplyTopic)) return;
  mqttReceivedResponse = "";
  mqttReceivedResponse.reserve(length + 1);
  for (unsigned int i = 0; i < length; i++) mqttReceivedResponse += (char)payload[i];
  mqttResponseReady = true;
}

bool ensureMqttConnectedUnlocked() {
  if (WiFi.status() != WL_CONNECTED) return false;
  if (mqttClient.connected()) return true;
  if (MACHINE_ID.length() == 0) return false;

  String clientId = "ESP32-" + MACHINE_ID + "-" + macAddressStr;
  const unsigned long connectStartedAt = millis();
  mqttConnectInProgress = true;

  setDebugCheckpoint("MQTT_TCP_CONNECT_BEGIN");
  mqttClient.setServer(MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  mqttNetworkClient.stop();
  wdtResetIfSubscribed();               // 2026-10-27: TCP connect (<=5 s) nijer WDT budget pay
  int tcpConnected = mqttNetworkClient.connect(MQTT_BROKER_HOST, MQTT_BROKER_PORT, (int32_t)MQTT_TCP_CONNECT_TIMEOUT_MS);

  if (tcpConnected != 1) {
    mqttNetworkClient.stop();
    lastMqttConnectDurationMs = millis() - connectStartedAt;
    mqttConnectInProgress = false;
    setDebugCheckpoint("MQTT_TCP_CONNECT_FAILED");
    Serial.printf("[MQTT] Broker TCP connect failed (%s:%u) after %lu ms, RSSI=%d\n",
                  MQTT_BROKER_HOST, MQTT_BROKER_PORT, (unsigned long)lastMqttConnectDurationMs, WiFi.RSSI());
    Serial.printf("[NET-ROUTE] ip=%s mask=%s gw=%s broker=%s:%u ssid=%s rssi=%d\n",
                  WiFi.localIP().toString().c_str(), WiFi.subnetMask().toString().c_str(),
                  WiFi.gatewayIP().toString().c_str(), MQTT_BROKER_HOST,
                  MQTT_BROKER_PORT, WiFi.SSID().c_str(), WiFi.RSSI());
    return false;
  }

  setDebugCheckpoint("MQTT_PROTOCOL_CONNECT_BEGIN");
  wdtResetIfSubscribed();               // 2026-10-27: CONNECT/CONNACK (<=5 s)
  bool connected = false;
  if (strlen(MQTT_USERNAME) > 0) connected = mqttClient.connect(clientId.c_str(), MQTT_USERNAME, MQTT_PASSWORD);
  else connected = mqttClient.connect(clientId.c_str());

  lastMqttConnectDurationMs = millis() - connectStartedAt;
  mqttConnectInProgress = false;
  if (!connected) {
    mqttNetworkClient.stop();
    setDebugCheckpoint("MQTT_PROTOCOL_CONNECT_FAILED");
    Serial.printf("[MQTT] Handshake failed state=%s(%d)\n", mqttStateText(mqttClient.state()), mqttClient.state());
    return false;
  }

  String responseWildcard = "factory/response/" + MACHINE_ID + "/#";
  wdtResetIfSubscribed();               // 2026-10-27: subscribe TCP write
  bool subscribed = mqttClient.subscribe(responseWildcard.c_str(), 1);
  Serial.printf("[MQTT] Connected in %lu ms, wildcard subscribe=%s\n", (unsigned long)lastMqttConnectDurationMs,
                subscribed ? "OK" : "FAILED");
  setDebugCheckpoint("MQTT_CONNECTED");
  needOledUpdate = true;
  return true;
}

// Server request/response. timeoutMs = per-operation (NO hidden cap).
// true = application reply received (content validation caller kore).
// 2026-10-27: protiti blocking network dhap-er age TWDT reset. Arduino WiFiClient::write()
// socket ready na hole select()+retry-te ~10 s porjonto atkate pare; age connect + subscribe +
// publish milie 30 s WDT par hoye crash (TASK_WATCHDOG) hochchilo.
bool mqttRequest(const char* requestTopic, JsonVariantConst payload, String& response, unsigned long timeoutMs) {
  response = "";
  const unsigned long requestStartedAt = millis();
  if (timeoutMs < 200) timeoutMs = 200;
  if (timeoutMs > 20000) timeoutMs = 20000;     // TWDT (30 s) safety bound only

  if (WiFi.status() != WL_CONNECTED || MACHINE_ID.length() == 0) return false;

  setDebugCheckpoint("MQTT_REQUEST_WAIT_MUTEX");
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(1000)) != pdTRUE) {
    lastMqttRequestDurationMs = millis() - requestStartedAt;
    Serial.printf("[MQTT REQUEST] Mutex busy. Topic=%s\n", requestTopic);
    return false;
  }

  wdtResetIfSubscribed();
  if (!ensureMqttConnectedUnlocked()) {
    lastMqttRequestDurationMs = millis() - requestStartedAt;
    xSemaphoreGive(mqttMutex);
    return false;
  }

  mqttRequestSequence++;
  String requestId = MACHINE_ID + "-" + String(millis()) + "-" + String(mqttRequestSequence);
  String replyTopic = "factory/response/" + MACHINE_ID + "/" + requestId;

  mqttExpectedReplyTopic = replyTopic;
  mqttReceivedResponse = "";
  mqttResponseReady = false;

  wdtResetIfSubscribed();
  mqttClient.subscribe(replyTopic.c_str(), 1);
  vTaskDelay(10 / portTICK_PERIOD_MS);

  JDOC(envelope, 2048);
  envelope["requestId"] = requestId;
  envelope["machineId"] = MACHINE_ID;
  envelope["replyTo"] = replyTopic;
  envelope["payload"].set(payload);

  String outgoingMessage;
  serializeJson(envelope, outgoingMessage);

  wdtResetIfSubscribed();               // publish-er nijer puro WDT budget
  setDebugCheckpoint("MQTT_REQUEST_PUBLISH");
  bool published = outgoingMessage.length() < 2000 && mqttClient.publish(requestTopic, outgoingMessage.c_str(), false);
  wdtResetIfSubscribed();
  if (!published) {
    mqttClient.unsubscribe(replyTopic.c_str());
    mqttExpectedReplyTopic = "";
    lastMqttRequestDurationMs = millis() - requestStartedAt;
    xSemaphoreGive(mqttMutex);
    setDebugCheckpoint("MQTT_REQUEST_PUBLISH_FAILED");
    Serial.printf("[MQTT REQUEST] Publish failed (broker). Topic=%s\n", requestTopic);
    return false;
  }

  unsigned long startedAt = millis();
  setDebugCheckpoint("MQTT_REQUEST_WAIT_RESPONSE");
  while (!mqttResponseReady && (millis() - startedAt < timeoutMs) && mqttClient.connected()) {
    mqttClient.loop();
    wdtResetIfSubscribed();
    vTaskDelay(5 / portTICK_PERIOD_MS);
  }

  bool success = false;
  if (mqttResponseReady) {
    response = mqttReceivedResponse;
    success = true;
  }

  wdtResetIfSubscribed();
  mqttClient.unsubscribe(replyTopic.c_str());
  mqttExpectedReplyTopic = "";
  mqttReceivedResponse = "";
  mqttResponseReady = false;

  lastMqttRequestDurationMs = millis() - requestStartedAt;
  xSemaphoreGive(mqttMutex);

  if (success) { lastServerReplyMs = millis(); serverTimeoutsInRow = 0; netServerUp = true; }
  else { serverTimeoutsInRow = serverTimeoutsInRow + 1; if (serverTimeoutsInRow >= 3) netServerUp = false; }

  setDebugCheckpoint(success ? "MQTT_REQUEST_SUCCESS" : "MQTT_REQUEST_TIMEOUT");
  if (!success) Serial.printf("[MQTT REQUEST] No server reply in %lu ms. Topic=%s\n", timeoutMs, requestTopic);
  return success;
}

// Stage-1 BENCH: Prefer worker UTC when NTP is blocked on factory LAN.
// This is an OPTIONAL new read-only endpoint. A legacy worker will time out;
// production events and old SD records must never be changed as a consequence.
static uint32_t stage1LastServerTimeTryMs = 0;
static const uint32_t STAGE1_SERVER_TIME_RETRY_MS = 60000UL;
static const uint32_t STAGE1_SERVER_TIME_REFRESH_MS = 3600000UL;
static bool stage1ServerTimeOk = false;
static void stage1TryServerTime() {
  if (WiFi.status() != WL_CONNECTED || !mqttClient.connected()) return;
  const uint32_t nowMs = millis();
  const uint32_t interval = stage1ServerTimeOk ? STAGE1_SERVER_TIME_REFRESH_MS : STAGE1_SERVER_TIME_RETRY_MS;
  if (stage1LastServerTimeTryMs && (uint32_t)(nowMs - stage1LastServerTimeTryMs) < interval) return;
  stage1LastServerTimeTryMs = nowMs;
  JDOC(req, 96);
  req["want"] = "utc";
  String response;
  if (!mqttRequest(TOPIC_SERVER_TIME_GET, req.as<JsonVariantConst>(), response, 2000)) {
    Serial.println("[TIME-SERVER] No worker reply; retaining RTC/NTP fallback");
    return;
  }
  JDOC(reply, 320);
  if (deserializeJson(reply, response) || (reply["status"] | 500) != 200 || !(reply["success"] | false)) {
    Serial.println("[TIME-SERVER] Reply invalid; clock unchanged");
    return;
  }
  const uint64_t epoch = reply["epochUtc"].as<uint64_t>();
  // Seconds since Unix epoch only, never milliseconds; 2023..2036 valid bench range.
  if (epoch < 1700000000ULL || epoch > 2100000000ULL) {
    Serial.println("[TIME-SERVER] Invalid epoch; clock unchanged");
    return;
  }
  struct timeval tv = { (time_t)epoch, 0 };
  settimeofday(&tv, nullptr);
  stage1ServerTimeOk = true;
  isTimeSynced = true;
  Serial.printf("[TIME-SERVER] UTC epoch=%lu source=LAN_WORKER; immutable events unchanged\n", (unsigned long)epoch);
  // STM32 RTC TIME write is handled by guarded pushTimeToStm(), not here.
}

// =============================================================================
// 12) microSD PERMANENT LOG + RAM POST QUEUE
//   Owner rule: SD-er data KOKHONO muchbe na. Protiti event (STM32 + ESP32) prothom
//   bar pele /smu/log/YYYYMMDD.jl file-e append hoy; DB response pele "delivered"
//   line append hoy. Kono file delete / rename / truncate kora hoy na.
//   DB-te pathanor queue RAM-e (postQ). Event-er asol nirapod copy STM32 FRAM-e
//   (DB response na asa porjonto STM32 3 s por por abar pathay), tai ESP32 reboot holeo
//   kichu harabe na. F3: login / maintenance event-o STM32 FRAM-e (ESP32 NVS-e kichu na).
// =============================================================================
#define LOG_DIR   "/smu"
#define LOG_SUB   "/smu/log"

bool sdOk = false;
bool sdFull = false;
String tornChecked = "";             // ei log file-er last line check kora hoyeche (remount-e clear)
bool sdSeededWithTime = false;
bool sdEverFailed = false;
uint64_t sdFreeBytes = 0;
uint32_t sdLogLines = 0;
uint32_t sdLogFailures = 0;
uint32_t rejectedCount = 0;
uint32_t payloadConflictCount = 0;
uint32_t sdReceiptGap = 0;           // 2026-10-27: DB committed + FRAM retired, kintu SD receipt nai
volatile bool dbRejectAlarm = false;

#define POSTQ_MAX      16   // LOG-FIX 2026-11-02f: 64 -> 16. SD /smu/custody-i asol queue; RAM-e 23 item-ei heap LOW hocchilo
#define SD_CUSTODY_DIR  "/smu/custody"
// NOT production qualified until actual SD power-cut tests + stable backend identity binding.
#define SD_CUSTODY_DIAGNOSTICS 1
#define SD_CUSTODY_SCAN_PER_STEP 64   // SD-SCAN-FIX: readdir sosta; asol seema 800 ms time budget
#define ESP_PEND_SLOTS 16
std::deque<PostItem> postQ;
volatile uint32_t postQCount = 0;      // postQ.size() copy (onno task lock chhara pore)

// RESET-DEBUG: postQ RAM footprint (diagnosticTask theke; qMutex busy hole skip)
static bool postQStats(uint32_t& items, uint32_t& bytes) {
  items = postQCount; bytes = 0;
  if (!qMutex || xSemaphoreTake(qMutex, pdMS_TO_TICKS(20)) != pdTRUE) return false;
  items = postQ.size();
  for (auto& it : postQ) bytes += it.line.length() + it.uc.length() + 2 + sizeof(PostItem);   // approx
  xSemaphoreGive(qMutex);
  return true;
}
static void heapGuardNote(const char* where) {
  rdHeapGuardHits = rdHeapGuardHits + 1;
  static uint32_t lastNote = 0;
  if (lastNote == 0 || (uint32_t)(millis() - lastNote) > 10000UL) {
    lastNote = millis();
    Serial.printf("[HEAP GUARD] %s: heap low (free=%lu largest=%lu) -> event RAM queue-e tola holo na, "
                  "SD custody / STM32 FRAM-e safe; heap free hole abar ashbe. hits=%lu\n", where,
                  (unsigned long)heap_caps_get_free_size(MALLOC_CAP_8BIT),
                  (unsigned long)heap_caps_get_largest_free_block(MALLOC_CAP_8BIT), (unsigned long)rdHeapGuardHits);
  }
}

// Recently seen STM32 events: (epoch, seq) -> 1 SD logged as HELD, 2 SD logged / queued,
// 3 delivered (legacy log / proof), 4 DB commit verified in this boot (2026-10-27)
#define RECENT_N 1024
RecentSeq recentSeq[RECENT_N];
uint16_t recentHead = 0;
portMUX_TYPE recentMux = portMUX_INITIALIZER_UNLOCKED;

uint8_t recentGet(uint32_t epoch, uint32_t seq) {
  uint8_t st = 0;
  if (seq == 0) return 0;
  portENTER_CRITICAL(&recentMux);
  for (int i = 0; i < RECENT_N; i++) if (recentSeq[i].seq == seq && recentSeq[i].epoch == epoch) { st = recentSeq[i].st; break; }
  portEXIT_CRITICAL(&recentMux);
  return st;
}

void recentSet(uint32_t epoch, uint32_t seq, uint8_t st) {
  if (seq == 0) return;
  portENTER_CRITICAL(&recentMux);
  bool found = false;
  for (int i = 0; i < RECENT_N; i++) if (recentSeq[i].seq == seq && recentSeq[i].epoch == epoch) {
    if (st > recentSeq[i].st) recentSeq[i].st = st;
    found = true;
    break;
  }
  if (!found) {
    recentSeq[recentHead].epoch = epoch;
    recentSeq[recentHead].seq = seq;
    recentSeq[recentHead].st = st;
    recentHead = (uint16_t)((recentHead + 1) % RECENT_N);
  }
  portEXIT_CRITICAL(&recentMux);
}

// JSON value -> String (number id holeo), null -> ""
String jstr(JsonVariantConst v) {
  if (v.isNull()) return "";
  if (v.is<const char*>()) return String(v.as<const char*>());
  String s;
  serializeJson(v, s);
  return s;
}

static bool evAckSentFlag = false;          // LOG-FIX: ei EV-te CUSTODY / RX / STORED gechhe (duplicate suppression)
void stmRetire(const char* kind, uint32_t seq, uint32_t epoch) {
  if (seq == 0) return;
  evAckSentFlag = true;
  linkSendf("%s,%lu,%08lX", kind, (unsigned long)seq, (unsigned long)epoch);
}

uint32_t qPending() { return postQCount; }

static bool postQHas(uint32_t epoch, uint32_t seq);
// A verified DB ACK is not an SD receipt. Journal persistence is confined to
// previously unused ESP32 namespace "smudbproof"; .evt/.ok stay immutable.
static bool dbProofHas(uint32_t epoch, uint32_t seq, const String& uc);
static bool dbProofConflict(uint32_t epoch, uint32_t seq, const String& uc);
static bool dbProofStore(uint32_t epoch, uint32_t seq, const String& uc);
static bool dbProofErase(uint32_t epoch, uint32_t seq, const String& uc);
static void dbProofLoad();
static void dbProofRepairOne();

// -----------------------------------------------------------------------------
// SD BAD-FILE GUARD (2026-10-26)
// Joto gulo file-i nosto hok, boot / background loop atkabe na:
//  - protiti line-read-e somoy-sima + "position egocche kina" check
//  - fail hole file /smu/quarantine-e RENAME (delete na) -> porer bar ar pora hoy na
//  - rename-o fail korle RAM list-e rakha hoy -> ei boot-e skip
// Sob caller qMutex dhore rakhe (sdInit / backgroundStep / postEnqueueStm).
// -----------------------------------------------------------------------------
#define SD_BAD_MAX 16
static String  sdBadFiles[SD_BAD_MAX];
static uint8_t sdBadCount = 0;

static bool sdIsBad(const String& p) {
  for (uint8_t i = 0; i < sdBadCount; i++) if (sdBadFiles[i] == p) return true;
  return false;
}

// caller holds qMutex
static void sdMarkBad(const String& p, const char* why) {
  if (sdIsBad(p)) return;
  int sl = p.lastIndexOf('/');
  String dest = String("/smu/quarantine/") + p.substring(sl + 1) + "." + String(millis()) + ".bad";
  bool moved = SD.rename(p, dest);              // shudhu directory entry bodlay, data muche na
  if (!moved && sdBadCount < SD_BAD_MAX) sdBadFiles[sdBadCount++] = p;   // rename fail: RAM-skip
  Serial.printf("[SD BAD FILE] %s reason=%s -> %s\n", p.c_str(), why,
                moved ? dest.c_str() : "RAM-skip (rename failed)");
}

// 1 = line paoa geche, 0 = file sesh, -1 = nosto / timeout (caller file chere dibe)
static int sdReadLineSafe(File& f, String& out, uint32_t deadline) {
  out = "";
  for (;;) {
    if ((int32_t)(millis() - deadline) > 0) return -1;   // somoy sesh
    if (!f.available()) return out.length() ? 1 : 0;
    int c = f.read();
    if (c < 0) return -1;                                // available bolche ache, kintu pora jay na
    if (c == '\n') return 1;
    if (out.length() > 4096) return -1;                  // newline chhara garbage
    out += (char)c;
  }
}

// -----------------------------------------------------------------------------
// Bench V1: per-event immutable SD custody spool. This is NOT an SD power-cut
// qualification. No .evt is overwritten or removed; .ok files record legacy
// application responses, NOT an independently audited MongoDB transaction.
// Stored payload bytes always come from the first verified .evt for event key.
// Key includes STM32 UID CRC32 and the existing immutable (epoch, seq).
// -----
// IMPORTANT: FILE_WRITE must only be used after exists() check (it truncates).
// A second incomplete file means NO custody. It must be quarantined by service.
// -----
static uint32_t custodyCrc(const uint8_t* p, size_t n) {
  uint32_t c = 0xFFFFFFFFUL;
  while (n--) {
    c ^= *p++;
    for (int i = 0; i < 8; ++i) c = (c >> 1) ^ ((c & 1) ? 0xEDB88320UL : 0);
  }
  return c ^ 0xFFFFFFFFUL;
}
// Forward declarations for the unchanged strict custody APIs.
static bool custodyRead(const String& path, String& data);
static bool custodyMarkCompleted(const PostItem& it);
static void sendVerifiedDbCommitAck(uint32_t seq, uint32_t epoch, uint32_t rawEventCrc);
static void sendDbCommitAckFromStoredEvent(const PostItem& it);
static String custodyBase(uint32_t ep, uint32_t seq);
// ---------- Database-confirmed / SD-receipt-pending proof journal ----------
// Fixed-size independent NVS keyspace. A slot is never overwritten/evicted
// while its corresponding .ok remains unverified. CRC32 guards torn entries;
// identity is full (epoch,seq,uniqueCode), not a hash-only match.
// 2026-10-27: proof ekhon "optimization" (re-POST komano). Server 409-idempotent, tai journal
// full holeo delivery atke na (postFinish PATCH C), ar .evt nai hole proof release hoy.
#define DB_PROOF_SLOTS 64
#define DB_PROOF_RETRY_MS 3000UL              // 2026-10-27: 60000 -> 3000 (64 proof ~3 min-e drain)
struct DbProofSlot { uint32_t epoch; uint32_t seq; String uc; bool valid; };
static DbProofSlot dbProofs[DB_PROOF_SLOTS];
static bool dbProofReady = false;
static uint8_t dbProofRepairCursor = 0;
static unsigned long dbProofRepairMs = 0;
static void dbProofKey(int i, char* key, size_t len) {
  snprintf(key, len, "p%02d", i);
}
static String dbProofPack(uint32_t epoch, uint32_t seq, const String& uc) {
  char head[20];
  snprintf(head, sizeof(head), "%08lX:%08lX:", (unsigned long)epoch, (unsigned long)seq);
  String body = String(head) + uc;
  char tail[12];
  snprintf(tail, sizeof(tail), "|%08lX", (unsigned long)custodyCrc((const uint8_t*)body.c_str(), body.length()));
  return body + tail;
}
static bool dbProofUnpack(const String& stored, uint32_t& epoch, uint32_t& seq, String& uc) {
  if (stored.length() < 28 || stored.length() > 160) return false;
  if (stored[8] != ':' || stored[17] != ':' || stored[stored.length()-9] != '|') return false;
  for (int i=0; i<8; ++i) {
    if (!isxdigit((unsigned char)stored[i]) || !isxdigit((unsigned char)stored[9+i]) ||
        !isxdigit((unsigned char)stored[stored.length()-8+i])) return false;
  }
  String body = stored.substring(0, stored.length()-9);
  uint32_t crc = (uint32_t)strtoul(stored.substring(stored.length()-8).c_str(), nullptr, 16);
  if (crc != custodyCrc((const uint8_t*)body.c_str(), body.length())) return false;
  epoch = (uint32_t)strtoul(body.substring(0,8).c_str(),nullptr,16);
  seq = (uint32_t)strtoul(body.substring(9,17).c_str(),nullptr,16);
  uc = body.substring(18);
  return seq != 0 && uc.length() > 0 && uc.length() <= 120;
}
static int dbProofIndexUnlocked(uint32_t epoch, uint32_t seq, const String& uc) {
  for (int i=0; i<DB_PROOF_SLOTS; ++i)
    if (dbProofs[i].valid && dbProofs[i].epoch == epoch && dbProofs[i].seq == seq && dbProofs[i].uc == uc) return i;
  return -1;
}
static bool dbProofHas(uint32_t epoch, uint32_t seq, const String& uc) {
  if (!dbProofReady || !seq || xSemaphoreTake(dbProofMutex,pdMS_TO_TICKS(100)) != pdTRUE) return false;
  bool found = dbProofIndexUnlocked(epoch,seq,uc) >= 0;
  xSemaphoreGive(dbProofMutex);
  return found;
}
// 2026-10-27: QUEUE console-er jonno (read-only)
static int dbProofCount() {
  if (!dbProofReady || xSemaphoreTake(dbProofMutex,pdMS_TO_TICKS(100)) != pdTRUE) return -1;
  int c = 0;
  for (int i=0; i<DB_PROOF_SLOTS; ++i) if (dbProofs[i].valid) ++c;
  xSemaphoreGive(dbProofMutex);
  return c;
}
static void dbProofLoad() {
  if (!dbProofReady) return;
  int loaded=0, invalid=0;
  for (int i=0; i<DB_PROOF_SLOTS; ++i) {
    char key[8]; dbProofKey(i,key,sizeof(key));
    String entry = dbProofPrefs.getString(key,"");
    if (entry.isEmpty()) continue;
    uint32_t ep=0, sq=0; String uc;
    if (!dbProofUnpack(entry,ep,sq,uc)) {
      ++invalid; // NEVER delete or reinterpret an unreadable proof
      Serial.printf("[DB PROOF INVALID] slot=%d retained; manual audit required\n",i);
      continue;
    }
    dbProofs[i].epoch=ep; dbProofs[i].seq=sq; dbProofs[i].uc=uc; dbProofs[i].valid=true;
    ++loaded;
  }
  Serial.printf("[DB PROOF RECOVERY] confirmed_receipt_pending=%d invalid_retained=%d capacity=%d\n",
                loaded,invalid,DB_PROOF_SLOTS);
}
static bool dbProofConflict(uint32_t epoch, uint32_t seq, const String& uc) {
  if (!dbProofReady || !seq) return false;
  if (xSemaphoreTake(dbProofMutex,pdMS_TO_TICKS(100)) != pdTRUE) return true;
  bool conflict=false;
  for (int i=0; i<DB_PROOF_SLOTS; ++i)
    if (dbProofs[i].valid && dbProofs[i].epoch==epoch && dbProofs[i].seq==seq && dbProofs[i].uc!=uc) { conflict=true; break; }
  xSemaphoreGive(dbProofMutex);
  return conflict;
}
static bool dbProofStore(uint32_t epoch, uint32_t seq, const String& uc) {
  if (!dbProofReady || !seq || uc.isEmpty() || uc.length()>120) return false;
  if (xSemaphoreTake(dbProofMutex,pdMS_TO_TICKS(500)) != pdTRUE) return false;
  int slot = dbProofIndexUnlocked(epoch,seq,uc);
  if (slot >= 0) { xSemaphoreGive(dbProofMutex); return true; }
  // Another uniqueCode for the same immutable epoch/sequence is a conflict.
  int freeSlot=-1;
  for (int i=0; i<DB_PROOF_SLOTS; ++i) {
    if (dbProofs[i].valid && dbProofs[i].epoch==epoch && dbProofs[i].seq==seq) {
      Serial.printf("[DB PROOF CONFLICT] epoch=%08lX seq=%lu; retained\n",
        (unsigned long)epoch,(unsigned long)seq);
      xSemaphoreGive(dbProofMutex); return false;
    }
    if (!dbProofs[i].valid && freeSlot<0) {
      char key[8]; dbProofKey(i,key,sizeof(key));
      // Invalid NVS entries are reserved, not reusable without manual audit.
      if (dbProofPrefs.getString(key,"").isEmpty()) freeSlot=i;
    }
  }
  if (freeSlot < 0) {
    Serial.println("[DB PROOF FULL] journal 64/64 -> SD receipt gap path (delivery atkabe na)");
    xSemaphoreGive(dbProofMutex); return false;
  }
  char key[8]; dbProofKey(freeSlot,key,sizeof(key));
  String packed=dbProofPack(epoch,seq,uc);
  bool durable=(dbProofPrefs.putString(key,packed)==packed.length() &&
                dbProofPrefs.getString(key,"")==packed);
  if (durable) {
    dbProofs[freeSlot].epoch=epoch; dbProofs[freeSlot].seq=seq;
    dbProofs[freeSlot].uc=uc; dbProofs[freeSlot].valid=true;
  }
  xSemaphoreGive(dbProofMutex);
  return durable;
}
static bool dbProofErase(uint32_t epoch, uint32_t seq, const String& uc) {
  if (!dbProofReady || xSemaphoreTake(dbProofMutex,pdMS_TO_TICKS(500)) != pdTRUE) return false;
  int i=dbProofIndexUnlocked(epoch,seq,uc);
  if (i<0) { xSemaphoreGive(dbProofMutex); return true; }
  char key[8]; dbProofKey(i,key,sizeof(key));
  bool erased=dbProofPrefs.remove(key) && dbProofPrefs.getString(key,"").isEmpty();
  if (erased) { dbProofs[i].valid=false; dbProofs[i].uc=""; }
  xSemaphoreGive(dbProofMutex);
  return erased;
}
// One proof / DB_PROOF_RETRY_MS. Never edits old .evt; custodyMarkCompleted is
// write-once (corrupt .ok quarantine-e sore, delete na) and rechecks CRC + uniqueCode.
// 2026-10-27: .evt SD-te nai ba porte na parle receipt kokhono toiri hobe na ->
// NVS proof release (event DB-te committed; server 409-idempotent; SD-e kichu muche na).
static void dbProofRepairOne() {
  if (!dbProofReady || !sdOk || !stm.seen ||
      (dbProofRepairMs && millis()-dbProofRepairMs < DB_PROOF_RETRY_MS)) return;
  dbProofRepairMs=millis();
  DbProofSlot entry; bool found=false;
  if (xSemaphoreTake(dbProofMutex,pdMS_TO_TICKS(50)) != pdTRUE) return;
  for (int k=0;k<DB_PROOF_SLOTS;++k) {
    uint8_t i=(dbProofRepairCursor+k)%DB_PROOF_SLOTS;
    if (dbProofs[i].valid) { entry=dbProofs[i]; dbProofRepairCursor=(i+1)%DB_PROOF_SLOTS; found=true; break; }
  }
  xSemaphoreGive(dbProofMutex);
  if (!found || xSemaphoreTake(qMutex,pdMS_TO_TICKS(50)) != pdTRUE) return;
  // Do not create a new receipt unless the original event body was CRC-valid.
  String original;
  const String evtPath = custodyBase(entry.epoch,entry.seq)+".evt";
  bool evtOk = sdOk && custodyRead(evtPath,original);
  bool verified=false, release=false;
  if (evtOk) {
    JDOC(d,1536);
    if (!deserializeJson(d,original) && String((const char*)(d["uniqueCode"] | ""))==entry.uc) {
      PostItem it={original,entry.seq,entry.epoch,-1,entry.uc};
      verified=custodyMarkCompleted(it);
    }
  } else if (sdOk) {
    release = true;                                      // .evt nai / nosto: receipt asombhob
  }
  xSemaphoreGive(qMutex);
  if (verified) {
    Serial.println("[SD RECEIPT VERIFIED] uniqueCode="+entry.uc+" recovery=1");
    if (!dbProofErase(entry.epoch,entry.seq,entry.uc)) Serial.println("[DB PROOF] erase deferred; proof retained");
  } else if (release) {
    if (dbProofErase(entry.epoch,entry.seq,entry.uc))
      Serial.println("[DB PROOF RELEASED] uniqueCode="+entry.uc+" reason=EVT_MISSING_OR_UNREADABLE (DB committed; 409-idempotent)");
  } else Serial.println("[SD RECEIPT DEFERRED] uniqueCode="+entry.uc+" reason=RECOVERY_READ_OR_VERIFY_FAIL");
}

static String custodyBase(uint32_t ep, uint32_t seq) {
  uint32_t deviceKey = custodyCrc((const uint8_t*)stm.uid, strlen(stm.uid));
  char n[72];
  // BUCKET 2026-11-02i: /smu/custody/<seq%64 hex>/<name>. DB proy sob somoy bondho -> pending hajar
  // hajar hote pare; 64 ta choto folder-e bhag korle protiti folder-e ~1/64 file -> FAT lookup druto.
  snprintf(n, sizeof(n), "%s/%02lX/%08lX%08lX%08lX", SD_CUSTODY_DIR, (unsigned long)(seq & 0x3FUL),
      (unsigned long)deviceKey, (unsigned long)ep, (unsigned long)seq);
  return String(n);
}
static String custodyPack(const String& data) {
  // 7 bytes #CRC32= + 8 hex + 1 LF + 1 NUL = 17 bytes.
  // Previous tag[16] silently truncated the final LF in EVERY written record.
  char tag[17];
  snprintf(tag, sizeof(tag), "#CRC32=%08lX\n", (unsigned long)custodyCrc((const uint8_t*)data.c_str(), data.length()));
  return data + "\n" + tag;
}
// Bench-only read compatibility for immutable files written with the old tag[16]
// off-by-one. The old frame has full JSON and CRC but exactly one absent LF.
// Strict CRC, exact frame length, and caller's JSON equality remain mandatory.
// NO modifications, migrations, overwrites, or FRAM retirements are performed.
#define SMU_CUSTODY_ACCEPT_LEGACY_NO_LF 1
static bool custodyDecode(const String& bytes, String& data) {
  const bool hasFinalLF = bytes.endsWith("\n");
  if (!hasFinalLF && !SMU_CUSTODY_ACCEPT_LEGACY_NO_LF) return false;
  int marker = bytes.lastIndexOf("\n#CRC32=");
  const size_t exactLength = (size_t)(marker + 1 + 7 + 8 + (hasFinalLF ? 1 : 0));
  if (marker < 1 || bytes.length() != exactLength) return false;
  String crcHex = bytes.substring(marker + 8, marker + 16);
  for (int i = 0; i < 8; ++i) if (!isxdigit((unsigned char)crcHex[i])) return false;
  data = bytes.substring(0, marker);
  uint32_t expected = strtoul(crcHex.c_str(), nullptr, 16);
  return expected == custodyCrc((const uint8_t*)data.c_str(), data.length());
}
// Bench diagnostics ONLY. Do not change the stored JSON or .evt framing.
// Serial/flash buffering cannot prove SD controller power-cut durability.
#define SMU_CUSTODY_TRACE 1
static bool custodyRead(const String& path, String& data) {
  if (!sdOk || !SD.exists(path)) return false;
  File f = SD.open(path, FILE_READ);
  if (!f) {
#if SMU_CUSTODY_TRACE
    Serial.printf("[CUSTODY READ FAIL] stage=OPEN path=%s exists=1\n", path.c_str());
#endif
    return false;
  }
  size_t n = f.size();
  if (n < 18 || n > 4096) {
#if SMU_CUSTODY_TRACE
    Serial.printf("[CUSTODY READ FAIL] stage=SIZE path=%s bytes=%u expected=18..4096\n", path.c_str(), (unsigned)n);
#endif
    f.close(); return false;
  }
  // Only the SD reader changes here. Read exactly the size reported by File,
  // check read() results, and NEVER treat an I/O error as a 0xFF payload byte.
  // Binary chunk reads also avoid hundreds of individual SPI/File read calls.
  String raw;
  if (!raw.reserve(n + 1)) {
    f.close();
#if SMU_CUSTODY_TRACE
    Serial.printf("[CUSTODY READ FAIL] stage=ALLOC path=%s bytes=%u\n", path.c_str(), (unsigned)n);
#endif
    return false;
  }
  uint8_t block[128];
  size_t bytesRead = 0;
  bool ioError = false;
  while (bytesRead < n) {
    size_t wanted = n - bytesRead;
    if (wanted > sizeof(block)) wanted = sizeof(block);
    size_t got = f.read(block, wanted);
    if (got == 0 || got > wanted) { ioError = true; break; }
    for (size_t j = 0; j < got; ++j) raw += (char)block[j];
    bytesRead += got;
  }
  f.close();
  if (ioError || bytesRead != n || raw.length() != n) {
#if SMU_CUSTODY_TRACE
    static uint32_t ioFailureCount = 0;
    ++ioFailureCount;
    if (ioFailureCount <= 12U || (ioFailureCount % 128U) == 0U) {
      Serial.printf("[CUSTODY READ FAIL] stage=IO_READ path=%s fileSize=%u readBytes=%u stringBytes=%u count=%lu (NO_REPAIR_NO_ACK)\n",
                    path.c_str(), (unsigned)n, (unsigned)bytesRead,
                    (unsigned)raw.length(), (unsigned long)ioFailureCount);
    }
#endif
    return false;
  }
  bool crcOk = custodyDecode(raw, data);
#if SMU_CUSTODY_TRACE
  if (crcOk && !raw.endsWith("\n")) {
    // Rate limit: replay can try the same immutable event repeatedly.
    static uint8_t legacyPrinted = 0;
    if (legacyPrinted < 24) {
      ++legacyPrinted;
      Serial.printf("[CUSTODY LEGACY VERIFIED] crc32Ok=1 finalLF=0 path=%s (READ_ONLY)\n", path.c_str());
    }
  }
  if (!crcOk) {
    bool trailingNewline = raw.endsWith("\n");
    bool couldPassIfNewline = false;
    if (!trailingNewline) {
      // Diagnose a one-byte torn frame without modifying or accepting the file.
      String diagnosticCopy = raw + "\n";
      String diagnosticJson;
      couldPassIfNewline = custodyDecode(diagnosticCopy, diagnosticJson);
    }
    // Diagnosis only: never auto-accept or rewrite a failed custody file.
    // Rate limit repeated immutable-file failures so serial printing does not
    // consume excessive CPU while the background queue retries.
    static uint32_t evtFailN = 0, okFailN = 0;
    const bool isReceipt = path.endsWith(".ok");
    uint32_t &categoryCount = isReceipt ? okFailN : evtFailN;
    const uint32_t occurrence = ++categoryCount;
    if (occurrence <= 12U || (occurrence % 128U) == 0U) {
      const int marker = raw.lastIndexOf("\n#CRC32=");
      const bool tagPresent = marker >= 1 && (size_t)(marker+16) <= raw.length();
      String tagCrc = tagPresent ? raw.substring(marker+8, marker+16) : String("ABSENT");
      uint32_t bodyCrc = tagPresent ? custodyCrc((const uint8_t*)raw.c_str(), (size_t)marker) : 0;
      String tailHex;
      const size_t tailStart = n > 16U ? n - 16U : 0U;
      tailHex.reserve(50);
      for (size_t k=tailStart; k<raw.length(); ++k) {
        char h[4]; snprintf(h, sizeof(h), "%02X", (unsigned)(uint8_t)raw[k]);
        if (tailHex.length()) tailHex += ':';
        tailHex += h;
      }
      Serial.printf("[CUSTODY READ FAIL] stage=FRAME_OR_CRC path=%s fileSize=%u finalLF=%d LFfix=%d occurrence=%lu (NO_REPAIR_NO_ACK)\n",
                    path.c_str(), (unsigned)n, trailingNewline?1:0, couldPassIfNewline?1:0,
                    (unsigned long)occurrence);
      Serial.printf("[CUSTODY RAW TAIL] marker=%d stored=%s computed=%08lX last16hex=%s (READ_ONLY)\n",
                    marker, tagCrc.c_str(), (unsigned long)bodyCrc, tailHex.c_str());
      // Read-only leading-byte sample separates an all-0xFF SPI read from
      // a valid JSON prefix followed by a bad/truncated CRC trailer.
      String headHex;
      headHex.reserve(50);
      size_t ffCount = 0;
      for (size_t k = 0; k < raw.length(); ++k) {
        if ((uint8_t)raw[k] == 0xFFU) ++ffCount;
        if (k < 16U) {
          char h[4]; snprintf(h, sizeof(h), "%02X", (unsigned)(uint8_t)raw[k]);
          if (headHex.length()) headHex += ':';
          headHex += h;
        }
      }
      Serial.printf("[CUSTODY READ BYTES] path=%s first16hex=%s ffBytes=%u/%u (READ_ONLY)\n",
                    path.c_str(), headHex.c_str(), (unsigned)ffCount, (unsigned)raw.length());
    }
  }
#endif
  return crcOk;
}
// -----------------------------------------------------------------------------
// ADD-ONLY serial diagnostic: strictly read-only. Reuses production custodyRead()
// (FILE_READ, exact size, CRC32, legacy no-final-LF compatibility).
// qMutex serializes with existing SD writer/replay/repair operations.
// No new file open mode, queue mutation, NVS write, ACK or database action.
// Commands: READ_EVT <24hex[.evt] or full path>; READ_OK <24hex[.ok] or full path>
// -----------------------------------------------------------------------------
static void consoleReadCustodyFile(const String& command, const String& argument) {
  const bool evt = command == "READ_EVT";
  const String suffix = evt ? ".evt" : ".ok";
  const String prefix = String(SD_CUSTODY_DIR) + "/";
  String leaf = argument;
  leaf.trim();
  if (leaf.startsWith(prefix)) leaf.remove(0, prefix.length());
  // Reject any path outside the custody directory and any traversal characters.
  if (leaf.indexOf('/') >= 0 || leaf.indexOf('\\') >= 0) {
    Serial.printf("[%s] FAIL INVALID_PATH (custody directory only)\n", command.c_str());
    return;
  }
  if (leaf.endsWith(suffix)) leaf.remove(leaf.length() - suffix.length());
  if (leaf.length() != 24) {
    Serial.printf("[%s] FAIL INVALID_NAME: need 24 hexadecimal characters, optional %s\n", command.c_str(), suffix.c_str());
    return;
  }
  for (size_t i = 0; i < leaf.length(); ++i) {
    if (!isxdigit((unsigned char)leaf[i])) {
      Serial.printf("[%s] FAIL INVALID_NAME: filename must be hexadecimal\n", command.c_str());
      return;
    }
  }
  // BUCKET: notun path /smu/custody/<seq%64>/; purono flat path fallback
  char bk[4]; snprintf(bk, sizeof(bk), "%02lX", (unsigned long)(strtoul(leaf.substring(16).c_str(), nullptr, 16) & 0x3FUL));
  String path = prefix + bk + "/" + leaf + suffix;
  const String legacyPath = prefix + leaf + suffix;
  if (!sdOk || !qMutex) {
    Serial.printf("[%s] FAIL SD_NOT_READY path=%s\n", command.c_str(), path.c_str());
    return;
  }
  if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) != pdTRUE) {
    Serial.printf("[%s] FAIL SD_BUSY_RETRY path=%s\n", command.c_str(), path.c_str());
    return;
  }
  String body;
  // Only the existing firmware's verified reader touches the filesystem here.
  bool crcOk = custodyRead(path, body);
  if (!crcOk) { path = legacyPath; crcOk = custodyRead(path, body); }   // BUCKET: purono flat file
  xSemaphoreGive(qMutex);
  if (!crcOk) {
    Serial.printf("[%s] FAIL FILE_NOT_FOUND_OR_READ_OR_CRC path=%s (no data changed)\n",
                  command.c_str(), path.c_str());
    return;
  }
  const uint32_t crc = custodyCrc((const uint8_t*)body.c_str(), body.length());
  Serial.printf("[%s] PASS path=%s bodyBytes=%u crc32=%08lX (verified by custodyRead)\n",
                command.c_str(), path.c_str(), (unsigned)body.length(), (unsigned long)crc);
  Serial.printf("[%s CONTENT BEGIN]\n", command.c_str());
  Serial.println(body);
  Serial.printf("[%s CONTENT END]\n", command.c_str());
  Serial.printf("[%s] DONE READ_ONLY (no SD write, NVS update, queue/ACK action)\n", command.c_str());
}
// BUCKET: bucket folder prothom lekhar age toiri (cache; SD remount-e reset)
static uint64_t custodyBucketMade = 0;
static void custodyEnsureDirFor(const String& path) {
  const String pre = String(SD_CUSTODY_DIR) + "/";
  if (!path.startsWith(pre)) return;
  int sl = path.lastIndexOf('/');
  String b = path.substring(pre.length(), sl);
  if (b.length() != 2 || !isxdigit((unsigned char)b[0]) || !isxdigit((unsigned char)b[1])) return;
  int idx = (int)(strtol(b.c_str(), nullptr, 16) & 63);
  if (custodyBucketMade & (1ULL << idx)) return;
  String dir = path.substring(0, sl);
  if (!SD.exists(dir)) SD.mkdir(dir);
  custodyBucketMade |= (1ULL << idx);
}
static bool custodyWriteOnce(const String& path, const String& line) {
  if (!sdOk || sdFull || line.length() > 3500 || line.length() == 0) {
#if SMU_CUSTODY_TRACE
    Serial.printf("[CUSTODY WRITE BLOCKED] sdOk=%d sdFull=%d jsonBytes=%u path=%s\n",
                  sdOk?1:0, sdFull?1:0, (unsigned)line.length(), path.c_str());
#endif
    return false;
  }
  String existing;
  bool exists = SD.exists(path);
#if SMU_CUSTODY_TRACE
  Serial.printf("[CUSTODY CHECK] path=%s exists=%d jsonBytes=%u\n", path.c_str(), exists?1:0, (unsigned)line.length());
#endif
  if (exists) {
    bool crcOk = custodyRead(path, existing);
    bool equal = crcOk && existing == line;
#if SMU_CUSTODY_TRACE
    Serial.printf("[CUSTODY VERIFY] mode=EXISTING readCrcOk=%d jsonEqual=%d path=%s\n", crcOk?1:0, equal?1:0, path.c_str());
#endif
    return equal;
  }
  custodyEnsureDirFor(path);                 // BUCKET
  String framed = custodyPack(line);
  File f = SD.open(path, FILE_WRITE);  // only when path did not exist; NEVER truncate existing
  if (!f) {
#if SMU_CUSTODY_TRACE
    Serial.printf("[CUSTODY WRITE FAIL] stage=OPEN path=%s existsNow=%d\n", path.c_str(), SD.exists(path)?1:0);
#endif
    return false;
  }
  size_t n = f.print(framed);
  f.flush(); // void API: invoked, not a power-cut durability guarantee
  size_t sizeAfterFlush = f.size();
  f.close();
#if SMU_CUSTODY_TRACE
  Serial.printf("[CUSTODY WRITE] path=%s expectedBytes=%u writtenBytes=%u flushCalled=1 sizeAfterFlush=%u\n",
                path.c_str(), (unsigned)framed.length(), (unsigned)n, (unsigned)sizeAfterFlush);
#endif
  if (n != framed.length()) return false;
  // Reopen + frame CRC32 + byte-identical JSON. Never ACK on any failure.
  bool crcOk = custodyRead(path, existing);
  bool equal = crcOk && existing == line;
#if SMU_CUSTODY_TRACE
  Serial.printf("[CUSTODY VERIFY] mode=NEW readCrcOk=%d jsonEqual=%d expectedJsonBytes=%u readJsonBytes=%u path=%s\n",
                crcOk?1:0, equal?1:0, (unsigned)line.length(), (unsigned)existing.length(), path.c_str());
#endif
  return equal;
}
static bool custodyStored(uint32_t epoch, uint32_t seq, String* firstPayload = nullptr) {
  String r;
  if (!custodyRead(custodyBase(epoch, seq) + ".evt", r)) return false;
  if (firstPayload) *firstPayload = r;
  return true;
}
static bool custodyCompleted(uint32_t epoch, uint32_t seq, const String& expectedUc) {
  String actual;
  return custodyRead(custodyBase(epoch,seq) + ".ok", actual) && actual == expectedUc;
}
// caller holds qMutex
static bool custodyMarkCompleted(const PostItem& it) {
  if (!it.seq) return true; // legacy NVS upgrade items
  if (!sdOk) return false;  // 2026-10-27: SD offline -> sathe sathe fail (unmounted FS-e access na)
  const String evtPath = custodyBase(it.epoch,it.seq) + ".evt";
  String original;
  if (!custodyRead(evtPath, original)) {
    // A RAM-only item cannot become 'done' before its event body is durable.
    // A corrupted existing .evt must never be overwritten.
    if (SD.exists(evtPath) || !custodyWriteOnce(evtPath,it.line)) return false;
    original = it.line;
  }
  JDOC(doc,1536);
  if (deserializeJson(doc,original)) return false;
  if (String((const char*)(doc["uniqueCode"] | "")) != it.uc) return false;
  // ---- PATCH B (2026-10-27): corrupt / bhul .ok -> quarantine (rename, delete na) -> notun .ok ----
  // Age: corrupt .ok overwrite hoto na, quarantine-o hoto na -> receipt kokhono toiri hoto na ->
  // NVS proof journal 64/64 bhore jeto -> DB-committed event-o queue chharto na.
  const String okPath = custodyBase(it.epoch,it.seq) + ".ok";
  if (SD.exists(okPath)) {
    String actual;
    if (custodyRead(okPath, actual) && actual == it.uc) return true;   // age thekei thik ache
    sdMarkBad(okPath, "OK_UNREADABLE");          // /smu/quarantine-e sore jay
    if (SD.exists(okPath)) return false;         // rename fail -> overwrite NA
  }
  return custodyWriteOnce(okPath, it.uc);
}
// Scan incrementally, keeping no more than POSTQ_MAX active items in RAM.
// Each boot begins from the directory start; completed .ok files are ignored.
// Files remain immutable and retained for manual audit / replay.
// ---- RETIRE-SD-OR-DB 2026-11-02d: SD pressure komano ----
// Age DB-committed .evt + .ok /smu/custody-tei chirokal thakto; protiti refill pass sob file
// abar porto (2 ta SD read / event) ar FAT directory hajar hajar entry-te dhir hoye jeto.
// Ekhon DB commit + .ok verified hole pair-ta /smu/done/YYYYMMDD/-e RENAME (kichu muche na).
// /smu/custody-te shudhu DB-te na jaoa (pending) event thake = SD queue.
#define SD_DONE_DIR "/smu/done"
static String sdDoneDayMade = "";
// DONE-SHARD 2026-11-02h: /smu/done/YYYYMMDD/HH (ghonta proti folder). FAT-e ek folder-e file
// joto beshi, notun file / rename toto dhir (directory linear search). Din-e 2000 event = 4000 file
// ek folder-e hole sondhyay protiti archive ~0.5 s. Ghonta-folder-e ~200-400 file -> sob somoy druto.
// Time jana na thakle: /smu/done/00000000/<seq % 64> (2 hex).
static String custodyDoneDir(uint32_t seq) {
  char day[40], b[48];
  time_t t = time(nullptr);
  if ((unsigned long)t < 1700000000UL) {
    snprintf(day, sizeof(day), "%s/00000000", SD_DONE_DIR);
    snprintf(b, sizeof(b), "%s/%02lX", day, (unsigned long)(seq & 0x3F));
  } else {
    time_t lt = t + cfg.tzSec; struct tm tmv; gmtime_r(&lt, &tmv);
    snprintf(day, sizeof(day), "%s/%04d%02d%02d", SD_DONE_DIR, tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday);
    snprintf(b, sizeof(b), "%s/%02d", day, tmv.tm_hour);
  }
  String d(b);
  if (d != sdDoneDayMade) {
    if (!SD.exists(SD_DONE_DIR)) SD.mkdir(SD_DONE_DIR);
    if (!SD.exists(day)) SD.mkdir(day);
    if (!SD.exists(d) && !SD.mkdir(d)) return "";
    sdDoneDayMade = d;
  }
  return d;
}
static uint32_t sdArchived = 0;
static bool custodyNameIds(const String& name, uint32_t& ep, uint32_t& seq);
// caller holds qMutex. base = custodyBase(ep,seq) (extension chhara). .evt AGE (crash hole .ok ekla
// custody-te thakle refill ignore kore; ulto hole .evt abar DB-te jeto -> 409 -> duplicate noy, tobu).
static void custodyArchiveUnlocked(const String& base) {
  if (!sdOk) return;
  String nm = base.substring(base.lastIndexOf('/') + 1);
  uint32_t aep = 0, aseq = 0;
  (void)custodyNameIds(nm + ".evt", aep, aseq);
  String dir = custodyDoneDir(aseq);
  if (!dir.length()) return;
  String evtTo = dir + "/" + nm + ".evt", okTo = dir + "/" + nm + ".ok";
  if (SD.exists(evtTo) || !SD.rename(base + ".evt", evtTo)) return;
  SD.rename(base + ".ok", okTo);
  sdArchived++;
}
// custody file name = deviceKey(8) epoch(8) seq(8) HEX: file na pore-i postQ/recent check
static bool custodyNameIds(const String& name, uint32_t& ep, uint32_t& seq) {
  if (name.length() != 28 || !name.endsWith(".evt")) return false;
  char h[9]; h[8] = 0;
  for (int i = 0; i < 24; i++) if (!isxdigit((unsigned char)name[i])) return false;
  memcpy(h, name.c_str() + 8, 8);  ep = (uint32_t)strtoul(h, nullptr, 16);
  memcpy(h, name.c_str() + 16, 8); seq = (uint32_t)strtoul(h, nullptr, 16);
  return seq != 0;
}

// SD-SCAN-FIX 2026-11-02e: log-e BackgroundTask "REFILL" stage-e 30 s atke TASK_WATCHDOG.
// Karon: /smu/custody-te hajar hajar .evt/.ok (kokhono sorano hoto na). Arduino openNextFile()
// protiti entry-r jonno full path diye abar open kore -> FAT directory-te linear search (~1 s / entry
// boro folder-e) -> 24 entry = 30 s+. Ekhon POSIX readdir (shudhu nam pore, open na) + time budget
// + protiti entry-te WDT feed. Shudhu dorkari .evt file-i open hoy.
// BUCKET 2026-11-02i: /smu/custody/<00..3F>/ 64 ta sub-folder. Iterator top folder + protiti bucket
// ghore. Top-level-e purono (flat) .evt pele: .ok thakle /smu/done-e archive, na thakle bucket-e move.
#define SD_VFS_MOUNT "/sd"                 // SD.begin() default mount point
// CustodyIter is declared in SMU100_CustodyIter.h (prevents Arduino auto-prototype compile errors)
static void custodyIterClose(CustodyIter& it) {
  if (it.sub) { closedir(it.sub); it.sub = nullptr; }
  if (it.top) { closedir(it.top); it.top = nullptr; }
}
// 1 = entry pawa gelo (dirPath + name), 0 = pass sesh / folder nai. Caller qMutex dhore rakhe.
static int custodyIterNext(CustodyIter& it, String& dirPath, String& name) {
  for (;;) {
    if (it.sub) {
      struct dirent* de = readdir(it.sub);
      if (!de) { closedir(it.sub); it.sub = nullptr; continue; }
      if (de->d_type == DT_DIR) continue;
      dirPath = String(SD_CUSTODY_DIR) + "/" + it.subName;
      name = de->d_name;
      return 1;
    }
    if (!it.top) { it.top = opendir(SD_VFS_MOUNT SD_CUSTODY_DIR); if (!it.top) return 0; }
    struct dirent* de = readdir(it.top);
    if (!de) { closedir(it.top); it.top = nullptr; return 0; }
    if (de->d_type == DT_DIR) {
      if (strlen(de->d_name) == 2 && isxdigit((unsigned char)de->d_name[0]) && isxdigit((unsigned char)de->d_name[1])) {
        strlcpy(it.subName, de->d_name, sizeof(it.subName));
        String full = String(SD_VFS_MOUNT SD_CUSTODY_DIR "/") + it.subName;
        it.sub = opendir(full.c_str());
      }
      continue;
    }
    dirPath = SD_CUSTODY_DIR;                // purono flat file
    name = de->d_name;
    return 1;
  }
}
static CustodyIter refillIt = { nullptr, nullptr, "" };
unsigned long custodyScanRestUntil = 0;
// ---- BACKLOG 2026-11-02g: SD queue-e koto event DB-te jay ni (shudhu nam gona, file open na) ----
// DB commit hole .evt /smu/done-e sore jay, tai /smu/custody-r .evt sonkha = DB-te na jaoa event.
volatile uint32_t sdQueueCount = 0;
volatile bool sdQueueKnown = false;
static CustodyIter countIt = { nullptr, nullptr, "" };
static bool sdCountActive = false;
static uint32_t sdCountRun = 0;
static unsigned long sdCountNextMs = 0;
static uint32_t custodyLegacyMoved = 0;
static void custodyCloseScan() {
  custodyIterClose(refillIt);
  custodyIterClose(countIt);
  sdCountActive = false;
}
static void custodyMigrateLegacyUnlocked(const String& name);
// PARKED: server-e pathano jabe na emon event (WORK_START / CURRENT_LOOKUP / provisional login)
#define SD_PARKED_DIR "/smu/parked"
volatile uint32_t sdParkedCount = 0;
static void custodyParkUnlocked(const String& path, const char* why, uint32_t seq, const char* type) {
  if (!SD.exists(SD_PARKED_DIR)) SD.mkdir(SD_PARKED_DIR);
  String nm = path.substring(path.lastIndexOf('/') + 1);
  String to = String(SD_PARKED_DIR) + "/" + nm;
  if (SD.exists(to) || !SD.rename(path, to)) return;
  sdParkedCount++;
  Serial.printf("[PARKED] seq=%lu type=%s reason=%s -> %s (DB-te pathano hoy na; SD-te safe, muche na)\n",
                (unsigned long)seq, type, why, to.c_str());
}
static uint32_t sdCountEvtIn(const char* dir) {   // choto folder-e .evt gona (boot-e)
  String full = String(SD_VFS_MOUNT) + dir;
  DIR* d = opendir(full.c_str());
  if (!d) return 0;
  uint32_t c = 0;
  struct dirent* de;
  while ((de = readdir(d)) != nullptr) {
    size_t L = strlen(de->d_name);
    if (de->d_type != DT_DIR && L > 4 && !strcmp(de->d_name + L - 4, ".evt")) c++;
  }
  closedir(d);
  return c;
}
// caller holds qMutex. Protibar max 300 ms; puro gona sesh hole 30 s por abar.
// BUCKET: gonar somoy top-level purono flat .evt pele migrate kore (DB bondho thakleo cholbe).
static void sdQueueCountStepUnlocked() {
  if (!sdOk) { sdQueueKnown = false; return; }
  if (!sdCountActive) {
    if (sdCountNextMs && (int32_t)(millis() - sdCountNextMs) < 0) return;
    sdCountActive = true;
    sdCountRun = 0;
  }
  const uint32_t t0 = millis();
  String dp, nm;
  while ((uint32_t)(millis() - t0) < 300UL) {
    if (!custodyIterNext(countIt, dp, nm)) {
      sdCountActive = false;
      sdQueueCount = sdCountRun; sdQueueKnown = true;
      sdCountNextMs = millis() + 30000UL;
      return;
    }
    if (!nm.endsWith(".evt")) continue;
    sdCountRun++;
    if (dp == SD_CUSTODY_DIR) custodyMigrateLegacyUnlocked(nm);   // BUCKET migration
  }
}
// caller holds qMutex. Purono flat /smu/custody/<name>.evt -> done (.ok thakle) ba bucket-e.
static void custodyMigrateLegacyUnlocked(const String& name) {
  uint32_t ep = 0, sq = 0;
  String stem = name.substring(0, name.length() - 4);
  String legacyBase = String(SD_CUSTODY_DIR) + "/" + stem;
  if (!custodyNameIds(name, ep, sq)) return;            // ajana nam: chhuin na
  if (SD.exists(legacyBase + ".ok")) { custodyArchiveUnlocked(legacyBase); return; }
  String dest = custodyBase(ep, sq) + ".evt";
  custodyEnsureDirFor(dest);
  if (SD.exists(dest)) { sdMarkBad(legacyBase + ".evt", "LEGACY_DUP"); return; }   // quarantine, delete na
  if (SD.rename(legacyBase + ".evt", dest)) custodyLegacyMoved++;
}
static int custodyRefillUnlocked(int scanBudget = SD_CUSTODY_SCAN_PER_STEP) {
  if (!sdOk || !SD.exists(SD_CUSTODY_DIR)) return 0;
  if (custodyScanRestUntil && (int32_t)(millis() - custodyScanRestUntil) < 0) return 0;
  const uint32_t scanT0 = millis();
  int loaded=0;
  if (!heapOkForQueue(postQ.empty())) return 0;  // Single-slot recovery, never remove SD proof
  while (scanBudget-- > 0 && postQ.size() < POSTQ_MAX && heapOkForQueue(postQ.empty()) &&
         (uint32_t)(millis() - scanT0) < 800UL) {                // SD-SCAN-FIX: time budget
    wdtResetIfSubscribed();
    String dirPath, itemName;
    if (!custodyIterNext(refillIt, dirPath, itemName)) { custodyScanRestUntil = millis() + 10000UL; break; }
    if (!itemName.endsWith(".evt")) continue;
    if (dirPath == SD_CUSTODY_DIR) { custodyMigrateLegacyUnlocked(itemName); continue; }   // BUCKET migration
    String path = dirPath + "/" + itemName;
    if (sdIsBad(path)) continue;                               // SD BAD-FILE GUARD: age-i nosto chinhito
    {                                                           // RETIRE-SD-OR-DB: file na pore fast skip
      uint32_t nep = 0, nsq = 0;
      if (custodyNameIds(itemName, nep, nsq) && (postQHas(nep, nsq) || recentGet(nep, nsq) >= 4)) continue;
    }
    String line;
    if (!custodyRead(path, line)) { sdLogFailures++; sdMarkBad(path, "REFILL_READ"); continue; }
    JDOC(doc,1536);
    if (deserializeJson(doc,line)) { sdLogFailures++; continue; }
    uint32_t sq = doc["eventSequence"] | 0;
    uint32_t ep = (uint32_t)strtoul(doc["stmEpoch"] | "0", nullptr, 16);
    String uc = doc["uniqueCode"] | "";
    if (!sq || !uc.length() || postQHas(ep,sq)) continue;
    if (path != custodyBase(ep,sq) + ".evt") { sdLogFailures++; continue; }
    if (dbProofHas(ep,sq,uc)) { recentSet(ep,sq,3); continue; } // committed, receipt pending in NVS
    if (recentGet(ep,sq) >= 4) continue;                         // ei boot-e DB committed (receipt gap)
    // Legacy .ok may predate strict DB_COMMIT_ACK: keep it, but never cache it as a DB proof.
    if (custodyCompleted(ep,sq,uc)) { custodyArchiveUnlocked(custodyBase(ep,sq)); continue; }   // purono done pair sorano
    if ((doc["pendingValidation"] | false) || (doc["serverSchemaPending"] | false)) {   // no unsafe legacy DB publication
      // PARKED 2026-11-02j: egulo server-e jabe na (schema / validation adapter nai). Age queue-tei
      // chirokal thakto -> backlog "27" kokhono 0 hoto na. Ekhon /smu/parked-e sorano (muche na).
      custodyParkUnlocked(path, (doc["pendingValidation"] | false) ? "PENDING_VALIDATION" : "SERVER_SCHEMA_PENDING",
                          sq, doc["eventType"] | "?");
      continue;
    }
    postQ.push_back({line,sq,ep,-1,uc});
    recentSet(ep,sq,2);
    loaded++;
  }
  postQCount = postQ.size();
  if (loaded && SD_CUSTODY_DIAGNOSTICS) Serial.printf("[CUSTODY] SD backlog loaded=%d RAM=%u\n", loaded, (unsigned)postQ.size());
  return loaded;
}

// ---------------- SD permanent log ----------------
static String logPathFor(time_t t) {
  char b[40];
  if ((unsigned long)t < 1700000000UL) {
    snprintf(b, sizeof(b), "%s/00000000.jl", LOG_SUB);         // time unknown
  } else {
    time_t lt = t + cfg.tzSec;
    struct tm tmv;
    gmtime_r(&lt, &tmv);
    snprintf(b, sizeof(b), "%s/%04d%02d%02d.jl", LOG_SUB, tmv.tm_year + 1900, tmv.tm_mon + 1, tmv.tm_mday);
  }
  return String(b);
}

static void sdRefreshFree() {
#if SD_ENABLED
  if (!sdOk) return;
  uint64_t total = SD.totalBytes(), used = SD.usedBytes();
  sdFreeBytes = total > used ? total - used : 0;
  bool full = sdFreeBytes < SD_RESERVE_BYTES;
  if (full != sdFull) {
    sdFull = full;
    Serial.printf("[SD] %s (free=%llu bytes)\n", full ? "FULL -> logging stopped (kono data muchbo na; card badlan)" : "space OK", sdFreeBytes);
    needOledUpdate = true;
  }
#endif
}

// caller holds qMutex
// FIX 2026-10-25: legacy log FILE append fail holeo pura CARD offline (sdOk=0) ghoshona kora hoy na.
// Age: ekta log-append fail -> sdOk=0 -> 30 s custody write BLOCKED -> remount -> abar fail (loop).
// Ekhon: card offline shudhu jodi lightweight probe (/smu ba /smu/custody exists) fail kore.
// Custody (.evt/.ok), queue, ACK, payload — kono logic badlano hoy ni.
static bool sdLogProbeCardUnlocked(const char* stage) {
  if (SD.exists(LOG_DIR) && SD.exists(SD_CUSTODY_DIR)) return true;
  sdOk = false; sdEverFailed = true;
  Serial.printf("[SD] Card probe failed after log %s -> SD offline (remount retry)\n", stage);
  return false;
}
static bool sdLogAppendUnlocked(const String& line) {
#if SD_ENABLED
  if (!sdOk || sdFull) return false;
  String p = logPathFor(time(nullptr));
  if (p != tornChecked) {                       // power-loss-e adha lekha line: newline diye bondho (kichu muche na)
    File r = SD.open(p, FILE_READ);
    if (r) {
      size_t sz = r.size();
      int last = '\n';
      if (sz > 0) { r.seek(sz - 1); last = r.read(); }
      r.close();
      if (last != '\n') {
        File a = SD.open(p, FILE_APPEND);
        if (a) { a.print('\n'); a.close(); Serial.println("[SD] Torn last log line closed with newline (kept, not deleted)"); }
      }
    }
    tornChecked = p;
  }
  static uint32_t logFailPrinted = 0;           // rate limit: prothom 20 ta, tarpor proti 50 tomo
  errno = 0;
  File f = SD.open(p, FILE_APPEND);
  if (!f) {
    sdLogFailures++;
    ++logFailPrinted;
    if (logFailPrinted <= 20U || (logFailPrinted % 50U) == 0U)
      Serial.printf("[SD LOG FAIL] stage=OPEN path=%s errno=%d count=%lu\n", p.c_str(), errno, (unsigned long)logFailPrinted);
    sdLogProbeCardUnlocked("OPEN");
    needOledUpdate = true;
    return false;
  }
  size_t before = f.size();
  size_t w1 = f.print(line);
  size_t w2 = f.print('\n');
  f.flush();
  size_t after = f.size();
  int errAfter = errno;
  f.close();
  const size_t expect = line.length() + 1;
  bool ok = (w1 + w2 == expect) && (after == before + expect);
  if (!ok) {
    sdLogFailures++;
    ++logFailPrinted;
    if (logFailPrinted <= 20U || (logFailPrinted % 50U) == 0U)
      Serial.printf("[SD LOG FAIL] stage=VERIFY path=%s before=%u after=%u written=%u expected=%u errno=%d count=%lu\n",
                    p.c_str(), (unsigned)before, (unsigned)after, (unsigned)(w1 + w2), (unsigned)expect,
                    errAfter, (unsigned long)logFailPrinted);
    sdLogProbeCardUnlocked("VERIFY");           // log FILE-er somossya != CARD-er somossya
  } else {
    sdLogLines++;
  }
  needOledUpdate = true;
  return ok;
#else
  (void)line;
  return false;
#endif
}

bool sdLogAppend(const String& line) {
  if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(2000)) != pdTRUE) return false;
  bool ok = sdLogAppendUnlocked(line);
  xSemaphoreGive(qMutex);
  return ok;
}

void sdLogMarker(const char* type, const String& uc, uint32_t seq, uint32_t epoch, const char* result) {
  JDOC(d, 384);
  d["logType"] = type;
  d["uniqueCode"] = uc;
  if (seq) { d["eventSequence"] = seq; char e[12]; snprintf(e, sizeof(e), "%08lX", (unsigned long)epoch); d["stmEpoch"] = e; }
  d["result"] = result;
  d["at"] = (unsigned long)time(nullptr);
  String s;
  serializeJson(d, s);
  sdLogAppend(s);
}

// Boot: ajker + gotokaler log-er tail theke duplicate table bhora (ESP reboot-er por abar log na kore)
static void sdSeedFile(const String& path);
static void sdSeedRecentFromLog() {
  time_t now = time(nullptr);
  sdSeedFile(logPathFor(now));
  if ((unsigned long)now > 1700000000UL) {
    sdSeedFile(logPathFor(now - 86400));
    sdSeededWithTime = true;
  }
}

// SD BAD-FILE GUARD: protiti file sorboccho 3 s; read atke gele / timeout hole
// file quarantine-e sore jay, boot ar atke na. (Seed shudhu RAM duplicate cache;
// bad porle data-r kono khoti nei — custody .evt check alada.)
static void sdSeedFile(const String& path) {
  if (sdIsBad(path)) return;
  File f = SD.open(path, FILE_READ);
  if (!f) return;
  size_t sz = f.size();
  size_t start = sz > 131072 ? sz - 131072 : 0;
  const uint32_t deadline = millis() + 3000;          // proti file sorboccho 3 s
  String s;
  if (start > 0 && (!f.seek(start) || sdReadLineSafe(f, s, deadline) < 0)) {
    f.close(); sdMarkBad(path, "SEEK"); return;
  }
  int n = 0, r;
  while ((r = sdReadLineSafe(f, s, deadline)) == 1) {
    JDOC(d, 1536);
    if (deserializeJson(d, s)) continue;
    uint32_t seq = d["eventSequence"] | 0;
    uint32_t ep = (uint32_t)strtoul(d["stmEpoch"] | "0", NULL, 16);
    if (!seq || !d["stmEpoch"].is<const char*>()) continue;
    const char* lt = d["logType"] | "";
    recentSet(ep, seq, strcmp(lt, "delivered") == 0 ? 3 : ((d["held"] | false) ? 1 : 2));
    if ((++n & 31) == 0) wdtResetIfSubscribed();
  }
  f.close();
  if (r < 0) sdMarkBad(path, "READ_STALL_OR_TIMEOUT");
}

bool sdInit() {
#if SD_ENABLED
  SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
  // Read-only mount attempts; never reformat or erase existing files.
  // At 10 MHz some microSD breakout boards intermittently fail initialization.
  if (!SD.begin(PIN_SD_CS, SPI, 10000000)) {
    Serial.println("[SD] 10MHz mount failed; retrying slower SPI 1MHz (no format)");
    SD.end();
    SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
    if (!SD.begin(PIN_SD_CS, SPI, 1000000)) {
      Serial.println("[SD] Both 10MHz and 1MHz mount failed -> SD offline; DB delivery continues (FRAM + DB)");
      return false;
    }
    Serial.println("[SD] 1MHz mount PASS; preserve all existing files");
  } else {
    Serial.println("[SD] 10MHz mount PASS");
  }
  if (!SD.exists(LOG_DIR)) SD.mkdir(LOG_DIR);
  if (!SD.exists(LOG_SUB)) SD.mkdir(LOG_SUB);
  if (!SD.exists(SD_CUSTODY_DIR)) SD.mkdir(SD_CUSTODY_DIR);
  SD.mkdir("/smu/recovery"); SD.mkdir("/smu/quarantine");
  SD.mkdir(SD_DONE_DIR);                       // RETIRE-SD-OR-DB: DB-committed .evt/.ok archive (delete na)
  custodyCloseScan();
  custodyScanRestUntil = 0;
  custodyBucketMade = 0;                       // BUCKET: notun/abar mount -> folder abar check
  sdParkedCount = sdCountEvtIn(SD_PARKED_DIR); // PARKED: boot / remount-e gona
  tornChecked = "";
  sdOk = true;
  sdRefreshFree();
  sdSeedRecentFromLog();
  lqInit();
  Serial.printf("[SD] Log ready (%s), free=%llu bytes\n", logPathFor(time(nullptr)).c_str(), sdFreeBytes);
  return true;
#else
  return false;
#endif
}

// ---------------- Upgrade: purono firmware-er /smuq queue drain (read-only, kichu delete na) ----
// Ager version STORED-e STM32 FRAM theke muche dito; tai /smuq-e baki record gulo DB-te
// pathano dorkar. Shudhu read pointer (ptrA/ptrB) agay; segment file kokhono delete na.
#define LQ_DIR    "/smuq"
#define LQ_PTR_A  "/smuq/ptrA.txt"
#define LQ_PTR_B  "/smuq/ptrB.txt"
bool lqActive = false;
uint32_t lqSeg = 1, lqOff = 0, lqMaxSeg = 0, lqGen = 0, lqDone = 0;
unsigned long lqNextMs = 0;
int lqRejects = 0;

static String lqSegPath(uint32_t n) { char b[32]; snprintf(b, sizeof(b), "%s/S%08lu.jl", LQ_DIR, (unsigned long)n); return String(b); }

static bool lqLoadPtr(const char* path, uint32_t& g, uint32_t& sg, uint32_t& of) {
  File f = SD.open(path, FILE_READ);
  if (!f) return false;
  String t = f.readStringUntil('\n');
  f.close();
  unsigned long a, b, c, k;
  if (sscanf(t.c_str(), "%lu %lu %lu %lu", &a, &b, &c, &k) != 4) return false;
  if ((uint32_t)(a ^ b ^ c ^ 0xA5A5A5A5UL) != (uint32_t)k) return false;
  g = a; sg = b; of = c;
  return true;
}

static void lqSavePtr() {
  lqGen++;
  char b[80];
  snprintf(b, sizeof(b), "%lu %lu %lu %lu\n", (unsigned long)lqGen, (unsigned long)lqSeg, (unsigned long)lqOff,
           (unsigned long)(lqGen ^ lqSeg ^ lqOff ^ 0xA5A5A5A5UL));
  File f = SD.open((lqGen & 1) ? LQ_PTR_A : LQ_PTR_B, FILE_WRITE);   // pointer metadata only
  if (f) { f.print(b); f.flush(); f.close(); }
}

// caller holds qMutex (sdInit)
static void lqInit() {
  lqActive = false;
  if (!SD.exists(LQ_DIR)) return;
  uint32_t minSeg = 0, maxSeg = 0;
  File dir = SD.open(LQ_DIR);
  if (dir) {
    File e = dir.openNextFile();
    while (e) {
      String nm = String(e.name());
      int sl = nm.lastIndexOf('/');
      if (sl >= 0) nm = nm.substring(sl + 1);
      if (!e.isDirectory() && nm.startsWith("S") && nm.endsWith(".jl")) {
        uint32_t n = (uint32_t)strtoul(nm.substring(1, nm.length() - 3).c_str(), NULL, 10);
        if (n) { if (!minSeg || n < minSeg) minSeg = n; if (n > maxSeg) maxSeg = n; }
      }
      e.close();
      e = dir.openNextFile();
    }
    dir.close();
  }
  if (!maxSeg) return;
  uint32_t ga = 0, sa = 0, oa = 0, gb = 0, sb = 0, ob = 0;
  bool va = lqLoadPtr(LQ_PTR_A, ga, sa, oa), vb = lqLoadPtr(LQ_PTR_B, gb, sb, ob);
  if (va || vb) { bool useA = va && (!vb || ga > gb); lqGen = useA ? ga : gb; lqSeg = useA ? sa : sb; lqOff = useA ? oa : ob; }
  else { lqGen = 0; lqSeg = minSeg; lqOff = 0; }
  if (lqSeg < minSeg) { lqSeg = minSeg; lqOff = 0; }
  lqMaxSeg = maxSeg;
  lqActive = true;
  Serial.printf("[UPGRADE] Old /smuq queue found: draining from seg %lu off %lu (files are NOT deleted)\n",
                (unsigned long)lqSeg, (unsigned long)lqOff);
}

// background: ek line kore post
void legacyQueueDrainStep() {
  if (!lqActive || !sdOk || holdReason || WiFi.status() != WL_CONNECTED || !mqttClient.connected()) return;
  if (lqNextMs && (long)(millis() - lqNextMs) < 0) return;
  String line; uint32_t next = 0;
  bool have = false;
  if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) != pdTRUE) return;
  for (int guard = 0; guard < 8 && !have; guard++) {
    File f = SD.open(lqSegPath(lqSeg), FILE_READ);
    size_t sz = f ? f.size() : 0;
    if (!f || lqOff >= sz) {
      if (f) f.close();
      if (lqSeg < lqMaxSeg) { lqSeg++; lqOff = 0; lqSavePtr(); continue; }
      lqActive = false;
      lqSavePtr();
      Serial.printf("[UPGRADE] Old /smuq queue drained (%lu records sent)\n", (unsigned long)lqDone);
      break;
    }
    f.seek(lqOff);
    line = f.readStringUntil('\n');
    next = (uint32_t)f.position();
    f.close();
    line.trim();
    if (line.length() == 0) { lqOff = next; lqSavePtr(); continue; }
    have = true;
  }
  xSemaphoreGive(qMutex);
  if (!have) return;
  JDOC(d, 1536);
  if (deserializeJson(d, line) || strlen(d["uniqueCode"] | "") == 0) {
    Serial.println("[UPGRADE] Unparsable old queue line skipped (stays in /smuq file): " + line.substring(0, 80));
    lqOff = next; lqSavePtr();
    return;
  }
  String uc = d["uniqueCode"] | "";
  buildServerPayload(d);
  PubResult r = publishSingleProduction(d.as<JsonVariantConst>(), uc);
  if (r == PUB_OK) {
    lqOff = next; lqSavePtr(); lqDone++; lqRejects = 0; lqNextMs = millis() + QUEUE_ITEM_GAP_MS;
    sdLogMarker("delivered", uc, 0, 0, "OK_OLD_QUEUE");
  } else if (r == PUB_REJECTED && ++lqRejects >= QUEUE_MAX_REJECTS) {
    Serial.println("[UPGRADE] Old record rejected 5x by DB (kept in /smuq file): " + uc);
    sdLogMarker("dbRejected", uc, 0, 0, "OLD_QUEUE_4XX_SKIPPED");
    lqOff = next; lqSavePtr(); lqRejects = 0;
  } else {
    lqNextMs = millis() + QUEUE_BACKOFF_MAX_MS;
  }
}

// ---------------- F2-upgrade: ager ESP32 NVS pending event drain (F3 notun kichu likhe na) ----
static void espPendClear(int slot) {
  if (slot < 0) return;
  char k[8]; snprintf(k, sizeof(k), "pe%d", slot);
  prefs.remove(k);
}
void espPendLoad() {
  for (int i = 0; i < ESP_PEND_SLOTS; i++) {
    char k[8]; snprintf(k, sizeof(k), "pe%d", i);
    if (!prefs.isKey(k)) continue;
    String line = prefs.getString(k, "");
    JDOC(d, 1536);
    if (line.length() == 0 || deserializeJson(d, line)) { prefs.remove(k); continue; }
    postQ.push_back({ line, 0, 0, (int8_t)i, String((const char*)(d["uniqueCode"] | "")) });
  }
  postQCount = postQ.size();
  if (!postQ.empty()) Serial.printf("[UPGRADE] %u old ESP32 NVS event(s) queued for DB (slot cleared after DB response)\n", (unsigned)postQ.size());
}

// STM event post queue-e ache?
static bool postQHas(uint32_t epoch, uint32_t seq) {
  for (auto& it : postQ) if (it.seq == seq && it.epoch == epoch && it.nvsSlot < 0) return true;
  return false;
}

// return: 2 = SD logged + queued, 1 = queued (SD log nai), 0 = queue full (logged-o hote pare: *loggedOut),
//         -1 = busy. queueIt=false (HELD): shudhu SD log -> 2 logged / 1 not logged
int postEnqueueStm(const String& line, const String& uc, uint32_t seq, uint32_t epoch, bool logIt, bool* loggedOut,
                   bool queueIt, bool deferServer = false) {
  if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(2000)) != pdTRUE) return -1;
  bool legacyLog = false;
  // HELD may later gain operator attribution. Do not give custody of a mutable HELD payload.
  bool custody = false;
  String frozen = line;
  if (queueIt && sdOk && !sdFull && stm.uid[0]) {
    String path = custodyBase(epoch,seq) + ".evt";
    String old;
    if (custodyRead(path,old)) {
      // A repeated event identity MUST have byte-identical canonical JSON.
      // Never ACK a changed payload as custody of the new version.
      if (old != line) {
#if PAYLOAD_CONFLICT_QUARANTINE
        // PATCH G: purono .evt quarantine (rename), STM32 FRAM version-e notun custody.
        Serial.printf("[CUSTODY CONFLICT] Same epoch/seq, DIFFERENT payload: seq=%lu -> old .evt quarantine\n",
                      (unsigned long)seq);
        sdMarkBad(path, "PAYLOAD_CONFLICT");
        payloadConflictCount++;
        if (!SD.exists(path)) custody = custodyWriteOnce(path, line);
#else
        Serial.printf("[CUSTODY FAULT] Same epoch/seq, DIFFERENT payload: seq=%lu. No ACK.\n", (unsigned long)seq);
        xSemaphoreGive(qMutex);
        return -2; // immutable identity conflict; requires reconciliation
#endif
      } else {
        frozen = old;
        custody = true;
      }
    } else if (!SD.exists(path)) custody = custodyWriteOnce(path,line);
    else {
      // SD BAD-FILE GUARD: existing-but-unreadable .evt overwrite kora hoy na.
      // Quarantine-e sorano hoy (delete na), tarpor STM32 FRAM-er original event theke notun .evt.
      sdMarkBad(path, "EVT_UNREADABLE");
      if (!SD.exists(path)) custody = custodyWriteOnce(path, line);
#if SMU_CUSTODY_TRACE
      else Serial.printf("[CUSTODY BLOCKED] Existing unreadable event; quarantine failed, NOT overwriting path=%s\n", path.c_str());
#endif
    }
  }
  if (logIt) legacyLog = sdLogAppendUnlocked(line);
  if (loggedOut) *loggedOut = queueIt ? custody : legacyLog;
  bool have = postQHas(epoch,seq);
  int res;
  if (!queueIt) res = legacyLog ? 2 : 1;
  else if (have || deferServer || dbProofHas(epoch,seq,uc)) res = custody ? 2 : 1;
  else if (postQ.size() < POSTQ_MAX && heapOkForQueue(postQ.empty())) {
    postQ.push_back({frozen,seq,epoch,-1,uc});
    postQCount = postQ.size();
    res = custody ? 2 : 1;
  } else {
    if (postQ.size() < POSTQ_MAX) heapGuardNote("EV enqueue");   // RESET-DEBUG: heap low, queue full na
    res = custody ? 2 : 0;  // SD owns queue even if 64 RAM slots occupied (SD nai -> NAK FULL -> STM32 retry)
  }
  xSemaphoreGive(qMutex);
  needOledUpdate = true;
  return res;
}

// =============================================================================
// 13) TEXT FIELD DECODE (STM32 EV / CTX name field: %XX, "~" = empty)
//     F3: session table STM32 FRAM-e; ESP32-e kono session store nai.
// =============================================================================
static int hexNib(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

String decText(const char* s) {
  if (!s || !strcmp(s, "~")) return String("");
  String o;
  o.reserve(strlen(s));
  for (const char* r = s; *r; r++) {
    int h, l;
    if (*r == '%' && (h = hexNib(r[1])) >= 0 && (l = hexNib(r[2])) >= 0) { o += (char)((h << 4) | l); r += 2; }
    else o += *r;
  }
  return o;
}

// String -> STM32 text field
String encText(const String& in) {
  static const char hx[] = "0123456789ABCDEF";
  if (in.length() == 0) return String("~");
  String o;
  o.reserve(in.length() + 8);
  for (size_t i = 0; i < in.length(); i++) {
    uint8_t c = (uint8_t)in[i];
    if (c < 0x20 || c >= 0x7F || c == ',' || c == '%' || c == '$' || c == '*' || c == '~') {
      o += '%'; o += hx[c >> 4]; o += hx[c & 15];
    } else {
      o += (char)c;
    }
  }
  return o;
}

// 2026-10-27: EV frame theke uniqueCode — queueStmEvent()-er formula-r HUBOHU eki
// (UID + epoch token + seq + RTC ts + millis). EV handler-e NVS proof lookup-e lage.
static String evUniqueCode(char** tok) {
  return String(stm.uid) + "_" + String(tok[15]) + "_" + String((unsigned long)strtoul(tok[1], NULL, 10)) + "_" +
         String((unsigned long)strtoul(tok[3], NULL, 10)) + "_" + String((unsigned long)strtoul(tok[4], NULL, 10));
}

// =============================================================================
// 14) PAYLOAD BUILD  (legacy key order same + required record fields)
// =============================================================================
static void putMeta(JsonDocument& d, const String& uniqueCode, unsigned long ts, const SessMeta& m) {
  d["uniqueCode"] = uniqueCode;
  d["machineId"] = MACHINE_ID;
  d["operator"] = m.op;
  d["location"] = m.loc;
  d["style"] = m.style;
  d["process"] = m.proc;
  d["smv"] = m.smv;
  d["divisor"] = m.div;
  d["machine"] = MACHINE_ID;
  d["timestamp"] = ts;
}

void addProductionFields(JsonDocument& d, int prodCount, int altCount, unsigned long irActiveDur,
                         unsigned long cycTime, const String& reasonCode) {
  d["productionCount"] = prodCount;
  d["irActiveDuration"] = (float)irActiveDur / 1000.0;
  if (profileValid(boundProfile) && LEGACY[boundProfile].needleField) d["needleDownTime"] = (float)irActiveDur / 1000.0;
  d["cycleTime"] = (float)cycTime / 1000.0;
  d["alterCount"] = altCount;
  d["reason"] = reasonCode;
}

static void addFirmwareFields(JsonDocument& d, uint32_t evSeq, const char* evType, const char* source) {
  d["firmwareProfile"] = activeProfileName();
  d["profileId"] = boundProfile;
  d["eventSequence"] = evSeq;
  d["eventType"] = evType;
  d["source"] = source;
  d["fwRev"] = FW_REV;
}

static const char* stmTypeText(int t) {
  switch (t) {
    case 1: return "PRODUCTION";
    case 2: return "ALTER";
    case 3: return "REASON";
    case 4: return "OVERFLOW_AGGREGATE";
    case 5: return "LOGIN";
    case 6: return "MAINTENANCE_ON";
    case 7: return "PRODUCTION_MODE_ON";
    case 8: return "WORK_START";
    case 9: return "CURRENT_LOOKUP";
    default: return "UNKNOWN";
  }
}

// STM32 EV -> record. uniqueCode deterministic (STM uid + epoch + seq + STM ts/ms) =>
// resend hole hubohu eki code -> server unique index (E11000) duplicate dhore.
// F3: metadata (operator/location/style/process/smv/divisor/technician) EV frame-e — STM32
// FRAM session table theke; ESP32-e kono session lookup nai.
// logIt = SD log-e lekha hobe. HELD (flag 0x04) = shudhu SD log, DB queue na.
// return: 2 logged(+queued), 1 queued / not logged, 0 full, -1 busy
int queueStmEvent(char** tok, int n, bool logIt, bool* logged, bool validateOnly = false) {
  if (logged) *logged = false;
  if (n < 24) return 0;
  uint32_t seq = strtoul(tok[1], NULL, 10);
  int type = atoi(tok[2]);
  unsigned long ts = strtoul(tok[3], NULL, 10);
  unsigned long ms = strtoul(tok[4], NULL, 10);
  int prod = atoi(tok[5]);
  int alt = atoi(tok[6]);
  unsigned long irDur = strtoul(tok[7], NULL, 10);
  unsigned long cyc = strtoul(tok[8], NULL, 10);
  String reason = (strcmp(tok[9], "-") == 0) ? String("") : String(tok[9]);
  uint32_t sid = strtoul(tok[13], NULL, 10);
  int flags = atoi(tok[14]);
  uint32_t recEpoch = (uint32_t)strtoul(tok[15], NULL, 16);
  bool held = (flags & 0x04) != 0;
  bool provisional = (flags & 0x40) != 0;
  bool schemaDeferred = (type == 8 || type == 9);

  // uniqueCode: shudhu STM32 record theke (UID + boot epoch + seq + RTC ts + millis) —
  // ESP board badlaleo / resend holeo eki code -> server unique index duplicate dhore.
  String uc = String(stm.uid) + "_" + String(tok[15]) + "_" + String(seq) + "_" + String(ts) + "_" + String(ms);
  if (ts < 1700000000UL) {
    // NEVER replace an immutable event timestamp with a later ESP clock!
    // A retry could generate a DIFFERENT payload under the same event ID.
    ts = 0;
  }

  SessMeta m;
  m.id = sid;
  m.op = decText(tok[16]);
  m.loc = decText(tok[17]);
  m.style = decText(tok[18]);
  m.proc = decText(tok[19]);
  m.smv = atol(tok[20]) / 1000.0;
  m.div = atoi(tok[21]);
  String mech = decText(tok[22]);
  const char* metaSource = held ? "held(operator-unknown)" :
                           (flags & 0x08) ? "session(assigned-at-login)" :
                           (flags & 0x10) ? "unknown(no-login-by-day-end)" :
                           (flags & 0x20) ? "missing(unknown)" : "session";

  JDOC(d, 1536);
  putMeta(d, uc, ts, m);
  if (mech.length()) d["mechanicId"] = mech;
  if (type == 4) {
    addProductionFields(d, prod, alt, 0, 0, "OVERFLOW_AGGREGATE");
    d["aggregatedReasonEvents"] = irDur;
    d["aggregatedFirstSeq"] = cyc;
  } else if (type == 5) {
    addProductionFields(d, 0, 0, 0, 0, "");                       // legacy operator login marker
  } else if (type == 6) {
    addProductionFields(d, 0, 0, 0, 0, "maintenance mode on");
  } else if (type == 7) {
    addProductionFields(d, 0, 0, 0, 0, "production mode on");
  } else {
    addProductionFields(d, prod, alt, irDur, cyc, reason);
  }
  addFirmwareFields(d, seq, stmTypeText(type), "STM32");
  d["stmUid"] = stm.uid;
  d["stmEpoch"] = tok[15];
  d["stmRecordCRC32"] = tok[23]; // immutable record fingerprint from STM FRAM
  d["sessionId"] = sid;
  d["metaSource"] = metaSource;
  d["irDurationFinal"] = (flags & 0x01) ? false : true;
  if (flags & 0x02) d["recoveredAfterPowerLoss"] = true;
  if (held) d["held"] = true;                                       // SD only (DB-te jay na)
  if (provisional) {
    d["pendingValidation"] = true;
    d["validationStatus"] = "PENDING_VALIDATION";
    if (type == 8) d["rawCardId"] = m.op; // raw RFID token is operator reference at punch
    d["metadataQuality"] = type == 9 ? "SERVER_LOOKUP_NOW_NOT_HISTORICAL" : "OFFLINE_UNVERIFIED";
    if (type == 9) d["validationOfSessionId"] = cyc; // immutable original session id
    // No server value exists; 0/UNKNOWN are sentinels, not assignment claims.
  }
  if (flags & 0x08) d["operatorAssignedLater"] = true;
  if (flags & 0x10) d["operatorUnknownAtDayEnd"] = true;
  if (ts == 0) d["timestampSource"] = "INVALID_RTC";
  if (schemaDeferred) d["serverSchemaPending"] = true; // no unapproved POST event type
  d["stmTotals"] = String(tok[10]) + "/" + tok[11] + "/" + tok[12];
  d["logType"] = "event";

  String line;
  serializeJson(d, line);
  if (validateOnly) {
    // The same event-id must never silently change when sessions are enriched,
    // time is resynchronised, or an EV is replayed after either MCU resets.
    if (!sdOk || !stm.uid[0]) return -1;
    String path = custodyBase(recEpoch,seq) + ".evt";
    if (!SD.exists(path)) return 0;  // no custody record yet
    String canonical;
    if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) != pdTRUE) return -1;
    bool valid = custodyRead(path, canonical);
    xSemaphoreGive(qMutex);
    if (!valid) return -3;          // existing record corrupt / partial
    return canonical == line ? 2 : -2;
  }
  int r = postEnqueueStm(line, uc, seq, recEpoch, logIt, logged, !held, provisional || schemaDeferred);
  if (r > 0 && logIt) Serial.printf("[STM EVENT] seq=%lu type=%s prod=%d alt=%d reason=%s op=%s%s -> SD log %s%s\n",
                                    (unsigned long)seq, stmTypeText(type), prod, alt, reason.c_str(), m.op.c_str(),
                                    held ? " (HELD: login-er opekkha)" : "", r == 2 ? "OK" : "NO",
                                    held ? "" : ", DB queue");
  return r;
}

// Server payload: legacy key-set (0/"" field bad) + firmware metadata
void buildServerPayload(JsonDocument& d) {
#if PAYLOAD_LEGACY_SPARSE
  if ((d["productionCount"] | 0) == 0) {
    d.remove("productionCount");
    d.remove("irActiveDuration");
    d.remove("needleDownTime");
    d.remove("cycleTime");
  }
  if ((d["alterCount"] | 0) == 0) d.remove("alterCount");
  if (strlen(d["reason"] | "") == 0) d.remove("reason");
#endif
  d.remove("logType");
  d.remove("held");
#if !PAYLOAD_INCLUDE_FW_FIELDS
  const char* extra[] = { "firmwareProfile", "profileId", "eventSequence", "eventType", "source", "fwRev",
                          "stmUid", "stmEpoch", "sessionId", "metaSource", "irDurationFinal", "recoveredAfterPowerLoss",
                          "timestampSource", "stmTotals", "aggregatedReasonEvents", "aggregatedFirstSeq",
                          "operatorAssignedLater", "operatorUnknownAtDayEnd" };
  for (const char* k : extra) d.remove(k);
#endif
}

// =============================================================================
// 15) PUBLISH + QUEUE PROCESS  (legacy semantics: E11000 = already saved)
// =============================================================================
// PUB_OK       : server status 200 + DB_COMMIT_ACK, ba (2026-10-27) 409 / E11000 duplicate = age-i saved
// PUB_RETRY    : reply nai / invalid JSON / 5xx — data rakha hoy
// PUB_REJECTED : server 4xx permanent reject
PubResult publishSingleProduction(JsonVariantConst payload, const String& uniqueCode) {
  String response;
  bool received = mqttRequest(TOPIC_PRODUCTION_POST, payload, response, cfg.tProdPost);
  if (!received) {
    Serial.println("[SAVE ERROR] No server response for: " + uniqueCode);
    return PUB_RETRY;
  }

  JDOC(responseDoc, 768);
  DeserializationError jsonError = deserializeJson(responseDoc, response);
  if (jsonError) {
    Serial.println("[SAVE ERROR] Invalid JSON response for: " + uniqueCode);
    return PUB_RETRY;
  }

  int status = responseDoc["status"] | 500;
  bool success = responseDoc["success"] | false;

  if (status != 200 || !success) {
    String details = responseDoc["details"] | "";
    String errorMsg = responseDoc["error"] | "";
    const bool duplicate = (status == 409) || details.indexOf("E11000") != -1 || errorMsg.indexOf("E11000") != -1;
#if ACCEPT_DUPLICATE_AS_COMMITTED
    // ---- PATCH A (2026-10-27): 409 / E11000 = ei uniqueCode DB-te AGE THEKEI ache ----
    // uniqueCode deterministic + server unique index -> duplicate mane event age-i committed.
    // Reply topic requestId-bound, tai reply ei request-eri. Server uniqueCode echo korle milai.
    if (duplicate) {
      String echoed409 = responseDoc["eventId"] | "";
      if (!echoed409.length()) echoed409 = responseDoc["uniqueCode"] | "";
      if (echoed409.length() && echoed409 != uniqueCode) {
        Serial.println("[DUPLICATE MISMATCH] echoed=" + echoed409 + " expected=" + uniqueCode + " -> not accepted");
        return PUB_REJECTED;
      }
      Serial.println("[DB ACK DUPLICATE] status=" + String(status) + " already committed: " + uniqueCode);
      return PUB_OK;
    }
#else
    if (duplicate) {
      Serial.println("[ACK UNVERIFIED] E11000/409 alone does NOT confirm this eventId: " + uniqueCode);
      return PUB_REJECTED; // keep record, rotate after repeated rejection to avoid starving others
    }
#endif
    Serial.println("[SAVE ERROR] Server rejected (" + String(status) + "): " + uniqueCode);
    return (status >= 400 && status < 500) ? PUB_REJECTED : PUB_RETRY;
  }

  // REQUIRE explicit application-level *durable database* ACK for this event.
  // A legacy HTTP/MQTT success=true (or a broker PUBACK) does not prove that
  // MongoDB durably committed the identical immutable business event.
  // Without the backend contract, retain the .evt file and retry safely.
  String echoed = responseDoc["eventId"] | "";
  if (!echoed.length()) echoed = responseDoc["uniqueCode"] | "";
  const char* ackType = responseDoc["ackType"] | "";
  bool dbCommitted = responseDoc["dbCommitted"] | false;
  if (echoed != uniqueCode || strcmp(ackType, "DB_COMMIT_ACK") != 0 || !dbCommitted) {
    Serial.println("[ACK UNVERIFIED] Missing matching eventId + DB_COMMIT_ACK + dbCommitted; retaining SD event: " + uniqueCode);
    return PUB_RETRY;
  }
  // This verifies only the RESPONSE SHAPE. Backend code must prove this ACK
  // is generated AFTER durable unique-index insert/idempotent DB transaction.
  Serial.println("[DB ACK] Identity-matched explicit database commit response: " + uniqueCode);
  return PUB_OK;
}

unsigned long qBackoffMs = QUEUE_BACKOFF_MIN_MS;
unsigned long qNextAttemptMs = 0;

// DB response pele: SD-te "delivered" line, STM32-ke DBCOMMIT (FRAM clear), NVS pending clear
// PUB_OK is already a strict DB ACK (ba 409 duplicate); SD receipt is an independent state.
// ---- PATCH C (2026-10-27): SD receipt lekha na gele-o delivery CHOLBE ----
//  (1) SD online + receipt fail -> NVS proof try (pore repair .ok likhbe)
//  (2) SD offline ba proof journal full -> "[SD RECEIPT GAP]" + counter, kintu tobuo DBCOMMIT.
//  Owner rule: DB response -> FRAM delete. Abar POST holeo server 409 dey (PATCH A) -> duplicate na.
//  Tradeoff: SD down thaka somoyer event SD permanent log-e thakbe na (DB-te thakbe).
static FinishResult postFinish(const PostItem& it, const char* result) {
  bool marked=true;
  if (it.seq) {
    marked=false;
    if (sdOk && xSemaphoreTake(qMutex,pdMS_TO_TICKS(1500))==pdTRUE) {   // 200 -> 1500 ms: EvTask SD lekhar somoy receipt DEFERRED kom
      marked=custodyMarkCompleted(it);
      if (marked) custodyArchiveUnlocked(custodyBase(it.epoch,it.seq));   // RETIRE-SD-OR-DB: SD queue theke sorano
      xSemaphoreGive(qMutex);
    }
    if (!marked) {
      const bool proofOk = sdOk && dbProofStore(it.epoch,it.seq,it.uc);
      recentSet(it.epoch,it.seq,4);       // ei boot-e DB commit verified (EV replay-e DBCOMMIT abar jabe)
      if (proofOk) {
        Serial.println("[SD RECEIPT DEFERRED] uniqueCode="+it.uc+" reason=SD_READ_OR_VERIFY_FAILED proof=NVS_VERIFIED");
      } else {
        sdReceiptGap++;
        Serial.printf("[SD RECEIPT GAP] uniqueCode=%s sdOk=%d gaps=%lu (DB is authority; FRAM retired)\n",
                      it.uc.c_str(), sdOk ? 1 : 0, (unsigned long)sdReceiptGap);
      }
      // Backend DB commit verified. This must NOT block further production / MQTT events.
      sendDbCommitAckFromStoredEvent(it);
      espPendClear(it.nvsSlot);
      return FINISH_RECEIPT_PENDING;
    }
    // .ok was CRC+identity verified. An older proof may now be released.
    if (dbProofHas(it.epoch,it.seq,it.uc) && !dbProofErase(it.epoch,it.seq,it.uc))
      Serial.println("[DB PROOF] prior proof retained; cleanup will retry");
    recentSet(it.epoch,it.seq,4);
    // Backend DB commit and immutable .evt/.ok verified; send proof-bound DB ACK.
    sendDbCommitAckFromStoredEvent(it);
    Serial.println("[SD RECEIPT VERIFIED] uniqueCode="+it.uc);
  }
  espPendClear(it.nvsSlot);
  sdLogMarker("deliveredLegacy",it.uc,it.seq,it.epoch,result);
  return FINISH_VERIFIED;
}

// DB queue process (FIFO). lockWaitMs: queue runner lock; budgetMs: max somoy (0 = no limit)
void processOfflineQueue(uint32_t lockWaitMs, uint32_t budgetMs) {
  unsigned long startMs = millis();
  if (WiFi.status() != WL_CONNECTED) return;
  if (qPending() == 0) return;
  if (holdReason) return;                                   // bhul identity-te publish na
  if (xSemaphoreTake(qProcMutex, pdMS_TO_TICKS(lockWaitMs)) != pdTRUE) return;

  setDebugCheckpoint("QUEUE_PROCESS_BEGIN");
  bool failed = false;
  static String lastRejectedUc = "";
  static int rejectCount = 0;

  while (WiFi.status() == WL_CONNECTED && !holdReason) {
    wdtResetIfSubscribed();
    if (budgetMs && millis() - startMs > budgetMs) break;
    PostItem it;
    if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(2000)) != pdTRUE) break;
    bool have = !postQ.empty();
    if (have) it = postQ.front();
    xSemaphoreGive(qMutex);
    if (!have) break;

    JDOC(d, 1536);
    if (deserializeJson(d, it.line) || strlen(d["uniqueCode"] | "") == 0) {   // RAM-e toiri, hobar kotha na
      Serial.println("[QUEUE ERROR] Unparsable record dropped from DB queue (copy is in SD log / STM32 FRAM)");
      xSemaphoreTake(qMutex, portMAX_DELAY); postQ.pop_front(); postQCount = postQ.size(); xSemaphoreGive(qMutex);
      continue;
    }
    String uc = d["uniqueCode"] | "";
    if ((d["pendingValidation"] | false) || (d["serverSchemaPending"] | false)) {
      // Safeguard: this old backend cannot validate historical operator assignment.
      // Keep event on SD and rotate RAM only. Reconciliation adapter is pending.
      xSemaphoreTake(qMutex, portMAX_DELAY);
      if (!postQ.empty() && postQ.front().uc == it.uc) postQ.pop_front();
      postQCount = postQ.size();
      xSemaphoreGive(qMutex);
      continue;
    }
    if (it.seq && dbProofConflict(it.epoch,it.seq,uc)) {
      Serial.println("[DB PROOF CONFLICT] uniqueCode="+uc+" action=RETAIN_WITHOUT_POST");
      failed=true; break;
    }
    // Reboot / SD backlog recovery: a CRC-checked NVS proof suppresses re-POST.
    if (it.seq && dbProofHas(it.epoch,it.seq,uc)) {
      Serial.println("[RECOVERY REPLAY] uniqueCode="+uc+" status=DB_COMMITTED_RECEIPT_PENDING");
      String nextUc = "NONE";
      if (xSemaphoreTake(qMutex,pdMS_TO_TICKS(200)) == pdTRUE) {
        if (!postQ.empty() && postQ.front().uc==it.uc) postQ.pop_front();
        postQCount=postQ.size();
        if (!postQ.empty()) nextUc=postQ.front().uc;
        xSemaphoreGive(qMutex);
      } else { failed=true; break; }
      recentSet(it.epoch,it.seq,4);
      sendDbCommitAckFromStoredEvent(it);     // 2026-10-27: STM32 FRAM-o retire (age DBCOMMIT harale)
      Serial.println("[DB QUEUE ADVANCE] nextEvent="+nextUc+" receipt=NVS_PENDING");
      continue;
    }
    buildServerPayload(d);
    PubResult r = publishSingleProduction(d.as<JsonVariantConst>(), uc);
    if (r == PUB_REJECTED) {
      if (uc == lastRejectedUc) rejectCount++;
      else { lastRejectedUc = uc; rejectCount = 1; }
      if (QUEUE_MAX_REJECTS > 0 && rejectCount >= QUEUE_MAX_REJECTS) {
        // 4xx = DB save HOY NI. FRAM theke muchbe na (owner rule). Record queue-er pichone
        // pathano hoy (onno event atke na thake), alarm + SD-te ekbar note.
        rejectedCount++;
        dbRejectAlarm = true;
        Serial.println("[DB REJECT ALARM] DB refused 5x (4xx) - kept in FRAM/queue, check server: " + it.line);
        sdLogMarker("dbRejected", it.uc, it.seq, it.epoch, "HTTP_4XX_KEPT");
        xSemaphoreTake(qMutex, portMAX_DELAY);
        if (!postQ.empty() && postQ.front().uc == it.uc) { postQ.pop_front(); postQ.push_back(it); }
        xSemaphoreGive(qMutex);
        rejectCount = 0;
        lastRejectedUc = "";
        failed = true;
        break;
      }
      failed = true;
      break;
    }
    if (r == PUB_RETRY) {
      // LOG-FIX 2026-11-02f: head-of-line blocking. Log-e eki event (…_2948_…) protibar 8 s timeout,
      // puro DB queue atke chilo. Eki uniqueCode 3 bar por por reply na pele queue-er pichone (kichu muche na).
      static String lastRetryUc = "";
      static int retryCount = 0;
      if (uc == lastRetryUc) retryCount++; else { lastRetryUc = uc; retryCount = 1; }
      if (retryCount >= 3 && mqttClient.connected()) {
        xSemaphoreTake(qMutex, portMAX_DELAY);
        if (postQ.size() > 1 && postQ.front().uc == it.uc) { postQ.pop_front(); postQ.push_back(it); }
        xSemaphoreGive(qMutex);
        Serial.println("[DB QUEUE ROTATE] 3x no reply, pichone pathano holo (SD/FRAM-e safe): " + uc);
        retryCount = 0; lastRetryUc = "";
      }
      failed = true; break;
    }
    Serial.println("[DB ACK VERIFIED] uniqueCode="+uc);
    FinishResult finish = postFinish(it, "DB_COMMIT_ACK");
    if (finish == FINISH_RETAIN) {
      // No durable proof: keep original event, but rotate it so newer work
      // can proceed. Reboot will resend immutable uniqueCode (no false ACK).
      if (xSemaphoreTake(qMutex,pdMS_TO_TICKS(200)) == pdTRUE) {
        if (!postQ.empty() && postQ.front().uc==it.uc) { postQ.pop_front(); postQ.push_back(it); }
        postQCount=postQ.size(); xSemaphoreGive(qMutex);
      }
      failed=true; break;
    }
    String nextUc="NONE";
    xSemaphoreTake(qMutex, portMAX_DELAY);
    postQ.pop_front(); postQCount = postQ.size();
    if (!postQ.empty()) nextUc=postQ.front().uc;
    xSemaphoreGive(qMutex);
    dbRejectAlarm = false;
    Serial.println("[DB QUEUE ADVANCE] nextEvent="+nextUc+" receipt="+
                   (finish==FINISH_VERIFIED ? "VERIFIED" : (sdOk ? "PENDING" : "SD_GAP")));
    Serial.println("[LEGACY APP ACK + SD retained] " + uc + " | Remaining RAM: " + String(qPending()));
    vTaskDelay(QUEUE_ITEM_GAP_MS / portTICK_PERIOD_MS);
  }
  if (failed) {
    qNextAttemptMs = millis() + qBackoffMs;
    qBackoffMs = qBackoffMs * 2 > QUEUE_BACKOFF_MAX_MS ? QUEUE_BACKOFF_MAX_MS : qBackoffMs * 2;
  } else {
    qBackoffMs = QUEUE_BACKOFF_MIN_MS;
    qNextAttemptMs = 0;
  }
  needOledUpdate = true;
  xSemaphoreGive(qProcMutex);
}

// =============================================================================
// 16) F2 -> F3 UPGRADE: ager ESP32 NVS session key muche fela (F3-e session STM32 FRAM-e).
//     Pending ESP event (pe0..pe15) DB-te na gele thake; DB response-e slot clear hoy.
// =============================================================================
void upgradeCleanupNvs() {
  const char* oldKeys[] = { "v", "opReady", "opRfid", "opName", "loc", "locRfid", "style", "proc", "smv", "div",
                            "maint", "techRfid", "tech", "sid", "sidMax", "locRst", "sday", "recPunch", "espSeq" };
  int removed = 0;
  for (const char* k : oldKeys) if (prefs.isKey(k)) { prefs.remove(k); removed++; }
  for (int i = 0; i < 16; i++) {
    char k[8]; snprintf(k, sizeof(k), "ss%d", i);
    if (prefs.isKey(k)) { prefs.remove(k); removed++; }
  }
  if (removed) Serial.printf("[UPGRADE] %d old ESP32 NVS session key removed (session data now in STM32 FRAM)\n", removed);
}

// =============================================================================
// 17) STM32 UART LINK  ($BODY*CRC16\n)
// =============================================================================
uint16_t crc16(const uint8_t* d, size_t n) {
  uint16_t c = 0xFFFF;
  for (size_t i = 0; i < n; i++) {
    c ^= (uint16_t)d[i] << 8;
    for (uint8_t b = 0; b < 8; b++) c = (c & 0x8000) ? (uint16_t)((c << 1) ^ 0x1021) : (uint16_t)(c << 1);
  }
  return c;
}

void linkSend(const char* body) {
  char tail[8];
  snprintf(tail, sizeof(tail), "*%04X\n", crc16((const uint8_t*)body, strlen(body)));
  xSemaphoreTake(linkTxMutex, portMAX_DELAY);
  StmLink.write('$');
  StmLink.print(body);
  StmLink.print(tail);
  xSemaphoreGive(linkTxMutex);
}

void linkSendf(const char* fmt, ...) {
  char b[720];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(b, sizeof(b), fmt, ap);
  va_end(ap);
  linkSend(b);
}

// ---- LOG-FIX 2026-11-02b: duplicate EV suppression ----
// Log proof: STM32 outbox 256/256 (WiFi/MQTT nai -> DB commit nai -> FRAM retire nai). STM32 tokhon
// protiti 250 ms-e ekta purono EV abar pathay (256 record ~64 s-e ek chokkor) — chirokal. ESP32 protibar
// SD-te .evt pore / verify / log kore (CPU-busy SPI). LinkTask (prio 2, core 1) tai CPU dhore rakhto ->
// BackgroundTask (prio 1, core 1) 30 s cholte pay ni -> TASK_WATCHDOG reset (log: "CPU 1: LinkTask").
// Fix: eki (epoch, seq, held) EV 300 s-er moddhe abar ashle ar SD kaj kora hoy na (CUSTODY/RX/STORED
// age-i deya hoyeche; STM32 CUSTODY-te retire kore na). DB-committed EV (DBCOMMIT fast path) ei check-er
// AGE, tai DB ACK kokhono atkay na. DB online hole SD backlog custodyRefill diye age-r motoi postQ-e ashe.
#define EV_SEEN_N        384
#define EV_SEEN_WINDOW_MS 300000UL
struct EvSeen { uint32_t ep; uint32_t seq; uint32_t ms; uint8_t held; };
static EvSeen evSeen[EV_SEEN_N];
static uint16_t evSeenHead = 0;
static bool evSeenRecent(uint32_t ep, uint32_t seq, bool held) {
  const uint32_t now = millis();
  for (int i = 0; i < EV_SEEN_N; i++) {
    const EvSeen& e = evSeen[i];
    if (e.seq == seq && e.ep == ep && e.held == (held ? 1 : 0) && e.ms && (uint32_t)(now - e.ms) < EV_SEEN_WINDOW_MS) return true;
  }
  return false;
}
static void evSeenMark(uint32_t ep, uint32_t seq, bool held) {
  if (!seq) return;
  const uint32_t now = millis() | 1u;
  for (int i = 0; i < EV_SEEN_N; i++)
    if (evSeen[i].seq == seq && evSeen[i].ep == ep && evSeen[i].held == (held ? 1 : 0)) { evSeen[i].ms = now; return; }
  evSeen[evSeenHead] = { ep, seq, now, (uint8_t)(held ? 1 : 0) };
  evSeenHead = (uint16_t)((evSeenHead + 1) % EV_SEEN_N);
}
struct EvSeenGuard {                        // EV handler-er je kono return-e mark kore
  uint32_t ep, seq; bool held;
  EvSeenGuard(uint32_t e, uint32_t s, bool h) : ep(e), seq(s), held(h) { evAckSentFlag = false; }
  ~EvSeenGuard() { if (evAckSentFlag) evSeenMark(ep, seq, held); }
};

static void sendVerifiedCustodyAck(uint32_t seq, uint32_t epoch, uint32_t rawEventCrc) {
  evAckSentFlag = true;                     // LOG-FIX: duplicate suppression mark
#if SMU_CUSTODY_TRACE
  Serial.printf("[CUSTODY ACK TX] seq=%lu epoch=%08lX recordCRC32=%08lX\n",
                (unsigned long)seq,(unsigned long)epoch,(unsigned long)rawEventCrc);
#endif
  // UART payload is EXACTLY the original protocol v4 format.
  linkSendf("CUSTODY,%lu,%08lX,%08lX",(unsigned long)seq,(unsigned long)epoch,(unsigned long)rawEventCrc);
}

// Separate local receipt for a server-confirmed DB commit. Identical UART CRC16
// envelope and identity-bound raw EventRec CRC32 as CUSTODY, but NOT interchangeable.
static void sendVerifiedDbCommitAck(uint32_t seq, uint32_t epoch, uint32_t rawEventCrc) {
  if (!seq || !rawEventCrc) return;
  Serial.printf("[DB RETIRE ACK TX] seq=%lu epoch=%08lX recordCRC32=%08lX\n",
                (unsigned long)seq,(unsigned long)epoch,(unsigned long)rawEventCrc);
  linkSendf("DBCOMMIT,%lu,%08lX,%08lX",(unsigned long)seq,(unsigned long)epoch,(unsigned long)rawEventCrc);
}

// Called only AFTER strict backend commit verification (200 DB_COMMIT_ACK ba 409 duplicate).
// Never guess a proof when processing legacy events without stmRecordCRC32.
static void sendDbCommitAckFromStoredEvent(const PostItem& it) {
  if (!it.seq) return;
  JDOC(d,1536);
  if (deserializeJson(d,it.line)) return;
  const char* raw = d["stmRecordCRC32"] | "";
  const char* id = d["uniqueCode"] | "";
  const char* rawEpoch = d["stmEpoch"] | "";
  if (strcmp(id,it.uc.c_str()) || strlen(raw)!=8 || strlen(rawEpoch)!=8 ||
      (uint32_t)(d["eventSequence"] | 0UL)!=it.seq) return;
  for (uint8_t i=0;i<8;++i) if (!isxdigit((unsigned char)rawEpoch[i])) return;
  if ((uint32_t)strtoul(rawEpoch,nullptr,16)!=it.epoch) return;
  for (uint8_t i=0;i<8;++i) if (!isxdigit((unsigned char)raw[i])) return;
  uint32_t proof=(uint32_t)strtoul(raw,nullptr,16);
  sendVerifiedDbCommitAck(it.seq,it.epoch,proof);
}

void stmBeep(uint16_t onMs, uint16_t offMs, uint8_t count) { linkSendf("BEEP,%u,%u,%u", onMs, offMs, count); }
void tripleBeep() { stmBeep(150, 100, 3); }
void errorBeep()  { stmBeep(500, 0, 1); }

uint32_t nextCmdId = 0;
portMUX_TYPE cmdIdMux = portMUX_INITIALIZER_UNLOCKED;
static uint32_t newCmdId() {
  portENTER_CRITICAL(&cmdIdMux);
  uint32_t id = ++nextCmdId;
  if (id == 0) id = ++nextCmdId;
  portEXIT_CRITICAL(&cmdIdMux);
  return id;
}

// ---- RESET-DEBUG 2026-11-02: STM32 reset flag + SDIAG decode ----
// STM32 RCC_CSR >> 26: bit0 PIN, bit1 POR, bit2 SFT, bit3 IWDG, bit4 WWDG, bit5 LPWR
static void stmResetText(uint32_t f, char* out, size_t n) {
  static const char* nm[6] = { "PIN", "POR", "SFT", "IWDG", "WWDG", "LPWR" };
  out[0] = 0;
  for (int i = 0; i < 6; i++) if (f & (1u << i)) {
    if (out[0]) strlcat(out, "|", n);
    strlcat(out, nm[i], n);
  }
  if (!out[0]) strlcpy(out, "NONE", n);
}
static const char* stmResetMeaning(uint32_t f) {
  if (f & 0x08) return "STM32 IWDG watchdog: loop 2 s-er beshi atke chilo (prevStage = doshi jayga)";
  if (f & 0x02) return "Power-on / brownout: STM32 supply cut ba dip (Andon/buzzer/motor noise, 5V->3.3V regulator)";
  if (f & 0x04) return "Software reset: HardFault capture (hf>0 hole) ba NVIC reset";
  if (f & 0x20) return "Low-power reset";
  if (f & 0x10) return "Window watchdog";
  if (f & 0x01) return "Shudhu NRST pin: reset button / NRST line-e noise (100nF NRST-GND check)";
  return "-";
}
static const char* stmStageName(unsigned s) {
  static const char* nm[] = { "IDLE", "LINK_POLL(ESP cmd)", "LINK_TX", "DBG_SVC", "I2C_PROBE", "I2C_HEALTH(FRAM/RTC)",
                              "HOUSEKEEP(HB/RTC/CTX)", "OUTBOX(FRAM)", "REPLAY(FRAM)", "BUTTONS", "BEEP", "SENSE(profile)",
                              "OP_INPUTS", "PERF_LIGHT", "OUTPUTS", "ACK_SCAN(FRAM)" };
  if (s < sizeof(nm) / sizeof(nm[0])) return nm[s];
  if (s == 20) return "SETUP";
  return "?";
}
static void handleStmDiag(char** tok, int n) {
  if (n < 26) return;
  uint32_t rf = strtoul(tok[1], NULL, 16);
  bool prevValid = atoi(tok[2]) != 0;
  unsigned prevStage = atoi(tok[3]), prevSlowStage = atoi(tok[4]), prevSlowMs = atoi(tok[5]);
  unsigned hfCount = atoi(tok[6]);
  uint32_t hfPc = strtoul(tok[7], NULL, 16), hfLr = strtoul(tok[8], NULL, 16), hfCfsr = strtoul(tok[9], NULL, 16);
  unsigned long up = strtoul(tok[10], NULL, 10), loopMax = strtoul(tok[11], NULL, 10);
  unsigned slowStage = atoi(tok[12]), slowMs = atoi(tok[13]);
  unsigned long slowCount = strtoul(tok[14], NULL, 10), ramGap = strtoul(tok[15], NULL, 10), heapUsed = strtoul(tok[16], NULL, 10);
  unsigned obx = atoi(tok[17]), ram = atoi(tok[18]);
  unsigned long txDrop = strtoul(tok[19], NULL, 10), rxCrc = strtoul(tok[20], NULL, 10), espRst = strtoul(tok[21], NULL, 10);
  unsigned long hbAge = strtoul(tok[22], NULL, 10), swErr = strtoul(tok[23], NULL, 10);
  uint32_t faults = strtoul(tok[24], NULL, 16);
  unsigned long boots = strtoul(tok[25], NULL, 10);

  // Reset karon: STM32 boot-er por / ESP32 boot-er por prothom bar + bootCount bodlale
  static unsigned long lastBootShown = 0xFFFFFFFFUL;
  static unsigned long lastUp = 0;
  bool newRun = (boots != lastBootShown) || (up < lastUp);
  lastUp = up;
  if (newRun) {
    lastBootShown = boots;
    char rs[40];
    stmResetText(rf, rs, sizeof(rs));
    Serial.printf("[STM-DIAG] ===== STM32 boot #%lu reset=%s -> %s\n", boots, rs, stmResetMeaning(rf));
    if (prevValid)
      Serial.printf("[STM-DIAG] ager run: last stage=%s | slowest stage=%s %u ms (2000 ms = IWDG reset)\n",
                    stmStageName(prevStage), stmStageName(prevSlowStage), prevSlowMs);
    else
      Serial.println("[STM-DIAG] ager run data nai (backup domain clear = sotti power cut / prothom boot)");
    if (hfCount)
      Serial.printf("[STM-DIAG] HARDFAULT x%u: PC=0x%08lX LR=0x%08lX CFSR=0x%08lX "
                    "(arm-none-eabi-addr2line -e sketch.elf 0x%08lX diye line ber korun)\n",
                    hfCount, (unsigned long)hfPc, (unsigned long)hfLr, (unsigned long)hfCfsr, (unsigned long)hfPc);
  }
  Serial.printf("[STM-DIAG] up=%lus loopMax=%lums slowest=%s %ums slow>500ms=%lu | RAM freeGap=%luB heap=%luB | "
                "outbox=%u/256 ramObx=%u | uartTxDrop=%lu rxCrcErr=%lu | espResetByStm=%lu espHbAge=%lums | "
                "framSwErr=%lu faults=0x%04lX\n",
                up, loopMax, stmStageName(slowStage), slowMs, slowCount, ramGap, heapUsed, obx, ram,
                txDrop, rxCrc, espRst, hbAge, swErr, (unsigned long)faults);
  static uint32_t lastWarn = 0;
  if (lastWarn == 0 || (uint32_t)(millis() - lastWarn) > 60000UL) {
    bool w = false;
    if (ramGap && ramGap < 1024UL) { Serial.println("[STM-DIAG] WARN STM32 RAM free gap < 1 KB: stack/heap prai full (HardFault risk)"); w = true; }
    if (obx >= 200) { Serial.println("[STM-DIAG] WARN FRAM outbox >= 200/256: event DB-te jacche na (server/HELD/login) -> FULL hole notun event aggregate"); w = true; }
    if (slowMs >= 1500) { Serial.printf("[STM-DIAG] WARN %s stage %u ms: IWDG (2 s) seemar kache!\n", stmStageName(slowStage), slowMs); w = true; }
    if (rxCrc > 50) { Serial.println("[STM-DIAG] WARN STM32 UART RX CRC error beshi: ESP->STM wiring/GND/noise check"); w = true; }
    if (w) lastWarn = millis();
  }
}

void handleStmLine(char** tok, int n) {
  // Recovery read-only FRAM hex payload; CRC16 already checked by UART parser.
  if (n >= 3 && !strcmp(tok[0],"FR")) {
    Serial.printf("@FR,%s,%s\n",tok[1],tok[2]); return;
  }
  if (n >= 2 && !strcmp(tok[0],"FRERR")) {
    Serial.printf("@FRERR,%s\n",tok[1]); return;
  }
  const char* cmd = tok[0];
  // ESP sends its own EHB once per second.  Seeing EHB on STM RX means
  // reflected/looped-back UART traffic, NOT STM32 liveness.
  if (!strcmp(cmd, "EHB")) {
    ++rxEhbEchoFrames;
    if (rxEhbEchoFrames <= 3) {
      Serial.printf("[UART LOOPBACK SUSPECT] RX received ESP-origin EHB (%lu). Check GPIO17/16 wiring.\n",
                    (unsigned long)rxEhbEchoFrames);
    }
    return;
  }
  const bool knownStmFrame = !strcmp(cmd, "DBG") || !strcmp(cmd, "EV") ||
                             !strcmp(cmd, "CMDOK") || !strcmp(cmd, "CMDNAK") ||
                             !strcmp(cmd, "HB") || !strcmp(cmd, "CTX") || !strcmp(cmd, "BOOT") ||
                             !strcmp(cmd, "SDIAG");
  if (!knownStmFrame) {
    ++rxUnknownFrames;
    if (rxUnknownFrames <= 3) Serial.printf("[UART RX UNKNOWN] cmd=%s\n", cmd);
    return;
  }
  stm.lastMs = millis(); // only recognized STM32-side frame types

  if (!strcmp(cmd, "SDIAG")) {                 // RESET-DEBUG 2026-11-02
    ++rxDbgFrames;
    handleStmDiag(tok, n);
    return;
  }

  if (!strcmp(cmd, "DBG")) {
    ++rxDbgFrames;
    // Source debug is CRC verified like all other STM32 messages.
    if (n >= 2) Serial.printf("[STM-DEBUG] %s\n", tok[1]);
    return;
  }
  if (!strcmp(cmd, "EV")) {
    if (n < 24) return; // phase C requires immutable STM EventRec CRC32 token
    uint32_t rawEventCrc=(uint32_t)strtoul(tok[23],nullptr,16);
    if (strlen(tok[23])!=8 || rawEventCrc==0) return;
    uint32_t seq = strtoul(tok[1], NULL, 10);
    if (!stm.seen) return;                          // BOOT/HB (uid, profile) age dorkar; STM retry korbe
    uint32_t recEpoch = (uint32_t)strtoul(tok[15], NULL, 16);
    if (holdReason) { linkSendf("NAK,%lu,%s,%08lX", (unsigned long)seq, HOLD_TEXT[holdReason], (unsigned long)recEpoch); return; }
    // EV tok[10..12] are historical snapshots, NOT live STM32 counters.
    // Leave the EV frame/payload intact; live TP/TA/AC come from HB.
    needOledUpdate = true;

    bool held = (atoi(tok[14]) & 0x04) != 0;
    uint8_t known = recentGet(recEpoch, seq);
    // ---- PATCH F (2026-10-27): SD-INDEPENDENT DBCOMMIT re-send ----
    // Ei event ei boot-e DB-committed (known>=4) ba NVS proof ache -> SD lagbe na, sathe sathe
    // DBCOMMIT. UART-e DBCOMMIT harale STM32 replay kore; age SD offline thakle ei replay-er
    // kono uttor jeto na, FRAM outbox shudhu barto. rawEventCrc STM32 FRAM-er nijer record theke,
    // STM32 seq+epoch+CRC milie tobei retire kore.
    if (!held && (known >= 4 || dbProofHas(recEpoch, seq, evUniqueCode(tok)))) {
      recentSet(recEpoch, seq, 4);
      sendVerifiedDbCommitAck(seq, recEpoch, rawEventCrc);
      return;
    }
    // LOG-FIX 2026-11-02b: eki EV 300 s-er moddhe age-i handle (ACK deya) hoye thakle SD kaj abar na.
    if (evSeenRecent(recEpoch, seq, held)) { evDupSkipped++; return; }
    EvSeenGuard evGuard(recEpoch, seq, held);
    // Recent RAM cache is bounded; disk .ok status is authoritative for this spool.
    String existingPayload;
    bool existingValid = false;
    if (sdOk && xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
      existingValid = custodyStored(recEpoch, seq, &existingPayload);
      xSemaphoreGive(qMutex);
    }
    if (existingValid && !held) {
      // Check canonical payload BEFORE even the fast-path/repeated CUSTODY ACK.
      int eq = queueStmEvent(tok, n, false, nullptr, true);
#if SMU_CUSTODY_TRACE
      if (eq != 2) Serial.printf("[CUSTODY REPLAY CHECK] seq=%lu readbackExists=1 jsonEqual=0 validation=%d\n",
                                  (unsigned long)seq, eq);
#endif
#if PAYLOAD_CONFLICT_QUARANTINE
      // ---- PATCH G (2026-10-27): PAYLOAD_CONFLICT deadlock bhanga ----
      // Age: SD .evt != STM32 replay -> NAK PAYLOAD_CONFLICT -> STM32 FRAM-e chirokal thakto
      // (outbox kokhono 0 hoto na; log-e seq 118/121/125 protibar). STM32 FRAM record (CRC32
      // soho) holo authority. Purono .evt /smu/quarantine-e RENAME (delete na), tarpor
      // normal path-e FRAM theke notun .evt + DB POST. uniqueCode eki -> server 409 = committed.
      if (eq == -2) {
        Serial.printf("[CUSTODY CONFLICT] seq=%lu epoch=%08lX: SD .evt != STM32 FRAM replay -> "
                      "old .evt quarantine (rename), FRAM version authority\n",
                      (unsigned long)seq, (unsigned long)recEpoch);
        if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
          sdMarkBad(custodyBase(recEpoch, seq) + ".evt", "PAYLOAD_CONFLICT");
          xSemaphoreGive(qMutex);
        }
        payloadConflictCount++;
        existingValid = false;
        eq = 2;                                     // niche normal (notun event) path-e cholo
      }
#endif
      if (eq == -1) {                          // SD-SCAN-FIX: -1 = qMutex busy / SD na, CONFLICT noy
        linkSendf("NAK,%lu,BUSY,%08lX", (unsigned long)seq, (unsigned long)recEpoch);
        return;
      }
      if (eq != 2) {
        Serial.printf("[CUSTODY FAULT] Replay differs from committed SD event seq=%lu (validation=%d)\n",
                      (unsigned long)seq, eq);
        linkSendf("NAK,%lu,PAYLOAD_CONFLICT,%08lX", (unsigned long)seq, (unsigned long)recEpoch);
        return;
      }
    }
    if (existingValid) {
      JDOC(storedDoc, 1536);
      if (!deserializeJson(storedDoc, existingPayload)) {
        String oldUc = storedDoc["uniqueCode"] | "";
        bool terminalVerified = false;
        if (oldUc.length() && xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
          // This disk read was previously outside qMutex; SD/FAT operations
          // could overlap the BackgroundTask spool scan / terminal write.
          terminalVerified = custodyCompleted(recEpoch, seq, oldUc);
          xSemaphoreGive(qMutex);
        }
        if (terminalVerified) {
          sendVerifiedCustodyAck(seq, recEpoch, rawEventCrc);
          // An existing .ok can predate strict DB_COMMIT_ACK firmware. Its
          // CRC+identity proves receipt integrity, NOT a historical DB commit.
          // Only a verified runtime/NVS DB proof permits FRAM retirement.
          if (known >= 3 || dbProofHas(recEpoch,seq,oldUc)) {
            recentSet(recEpoch,seq,3);
            sendVerifiedDbCommitAck(seq, recEpoch, rawEventCrc);
          } else {
            // Re-POST with the same immutable uniqueCode. The backend must
            // return a NEW strict DB_COMMIT_ACK (ba 409 duplicate) before we send DBCOMMIT.
            int q = queueStmEvent(tok, n, false, nullptr);
            if (q < 1) Serial.printf("[DB REVERIFY] seq=%lu queue=%d; FRAM retained\n",
                                     (unsigned long)seq,q);
          }
          return;
        }
        // A DB-confirmed event may have an unreadable .ok, but a verified NVS
        // DB proof. Re-send only the DB commit receipt after immutable .evt
        // equality checking above, never from a RAM cache alone.
        if (oldUc.length() && dbProofHas(recEpoch,seq,oldUc)) {
          recentSet(recEpoch,seq,3);
          sendVerifiedDbCommitAck(seq, recEpoch, rawEventCrc);
          return;
        }
      }
    }
    if (known >= 3) {
      // Never promote an unverified legacy DB reply into a new DB_COMMIT_ACK.
      // If the immutable .evt is still present, custody can be reasserted.
      if (existingValid) sendVerifiedCustodyAck(seq, recEpoch, rawEventCrc);
      else {
        // 2026-10-27: legacy "delivered" (st=3) kintu SD/.evt nai -> abar queue; server 409 dile
        // PATCH A PUB_OK -> DBCOMMIT. Age eta chirokal STM32 FRAM-e atke thakto.
        queueStmEvent(tok, n, false, nullptr);
      }
      return;
    }
    if (held) {                                                        // F3 HELD: shudhu SD log (DB na)
      if (known >= 1) { stmRetire("STORED", seq, recEpoch); return; }
      bool lg = false;
      int res = queueStmEvent(tok, n, true, &lg);
      if (lg) recentSet(recEpoch, seq, 1);
      if (res == 2) stmRetire("STORED", seq, recEpoch);
      else if (res == 1) stmRetire("RX", seq, recEpoch);
      else linkSendf("NAK,%lu,BUSY,%08lX", (unsigned long)seq, (unsigned long)recEpoch);
      return;
    }
    if (known == 2) {                                                  // SD-te ache; DB queue-e na thakle abar queue
      bool inQ = false;
      if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) == pdTRUE) { inQ = postQHas(recEpoch, seq); xSemaphoreGive(qMutex); }
      if (inQ && existingValid) { sendVerifiedCustodyAck(seq, recEpoch, rawEventCrc); return; }
      int res = queueStmEvent(tok, n, false, nullptr);
      if (res == 2) sendVerifiedCustodyAck(seq, recEpoch, rawEventCrc);
      else if (res == 1) stmRetire("RX", seq, recEpoch);
      else linkSendf("NAK,%lu,%s,%08lX", (unsigned long)seq, res < 0 ? "BUSY" : "FULL", (unsigned long)recEpoch);
      return;
    }
    bool logged = false;
    int res = queueStmEvent(tok, n, true, &logged);                    // prothom bar (ba HELD -> operator): SD log + DB queue
    if (logged) recentSet(recEpoch, seq, 2);                           // SD-te lekha hoyeche: abar lekhbe na
    if (res == 2) sendVerifiedCustodyAck(seq, recEpoch, rawEventCrc);
    else if (res == 1) stmRetire("RX", seq, recEpoch);
    else linkSendf("NAK,%lu,%s,%08lX", (unsigned long)seq, res < 0 ? "BUSY" : "FULL", (unsigned long)recEpoch);
  } else if (!strcmp(cmd, "CMDOK")) {
    if (n >= 2 && cmdAwaitId != 0 && strtoul(tok[1], NULL, 10) == cmdAwaitId) { cmdReplyKind = 1; cmdReplyId = cmdAwaitId; }
  } else if (!strcmp(cmd, "CMDNAK")) {
    if (n >= 2 && cmdAwaitId != 0 && strtoul(tok[1], NULL, 10) == cmdAwaitId) { cmdReplyKind = 2; cmdReplyId = cmdAwaitId; }
    Serial.printf("[LINK] STM32 NAK for %s (%s)\n", n >= 3 ? tok[2] : "?", n >= 4 ? tok[3] : "-");
  } else if (!strcmp(cmd, "HB")) {
    if (n < 28) { ++rxShortHbFrames; return; }
    // This path is reached only after linkProcessFrame() verified UART CRC16.
    // Never extend HB freshness from DBG, CTX, EV or an incomplete HB.
    ++rxHbFrames;
    stm.lastHbMs = millis();
    stm.seen = true;
    stm.proto = atoi(tok[1]);
    stm.profile = atoi(tok[2]);
    long tp = atol(tok[3]), ta = atol(tok[4]), ac = atol(tok[5]);
    int perf = atoi(tok[6]);
    if (tp != stm.tp || ta != stm.ta || ac != stm.ac || perf != stm.perf) needOledUpdate = true;
    stm.tp = tp; stm.ta = ta; stm.ac = ac; stm.perf = perf;
    stm.light = atoi(tok[7]);
    stm.maint = atoi(tok[8]) != 0;
    stm.opReady = atoi(tok[9]) != 0;
    stm.outbox = strtoul(tok[10], NULL, 10);
    stm.epoch = strtoul(tok[11], NULL, 10);
    stm.rtcOk = atoi(tok[12]) != 0;
    stm.framState = atoi(tok[13]);
    stm.zRpm = strtoul(tok[14], NULL, 10);
    stm.aggPending = atoi(tok[15]) != 0;
    stm.seq = strtoul(tok[16], NULL, 10);
    strncpy(stm.uid, tok[17], sizeof(stm.uid) - 1);
    stm.smvMilli = atol(tok[18]);
    stm.div = atoi(tok[19]);
    stm.sessionId = strtoul(tok[20], NULL, 10);
    stm.lifeP = strtoul(tok[21], NULL, 10);
    stm.lifeA = strtoul(tok[22], NULL, 10);
    stm.faults = strtoul(tok[23], NULL, 16);
    stm.lastDelivered = strtoul(tok[24], NULL, 10);
    stm.iwdg = atoi(tok[25]) != 0;
    stm.seqEpoch = (uint32_t)strtoul(tok[26], NULL, 16);
    stm.prodDay = strtoul(tok[27], NULL, 10);
    evaluateHold();

    // DAILY RESET (03:00 local) STM32 nijei kore (FRAM session); ESP32 shudhu SD-te note rakhe
    if (stm.prodDay != 0 && stm.prodDay != lastDaySeen) {
      if (lastDaySeen != 0 && stm.prodDay > lastDaySeen)
        sdLogMarker("dayReset", String("DAY_") + String((unsigned long)stm.prodDay), 0, 0, "STM32_DAILY_RESET");
      lastDaySeen = stm.prodDay;
      needOledUpdate = true;
    }

    // NTP nai kintu STM32 DS3231 valid -> ESP32 system time set (PDF: RTC fallback)
    if (!isTimeSynced && !timeFromStmRtc && stm.rtcOk && stm.epoch > 1700000000UL) {
      struct timeval tv = { (time_t)stm.epoch, 0 };
      settimeofday(&tv, NULL);
      timeFromStmRtc = true;
      Serial.println("[RTC] ESP32 time set from STM32 DS3231");
    }
  } else if (!strcmp(cmd, "CTX")) {
    // F3: current session STM32 FRAM theke (ESP32 RAM-e shudhu dekhano / recovery decision)
    if (n < 16) return;
    {
      SessLock l;
      currentSessionId = strtoul(tok[1], NULL, 10);
      operatorReady = atoi(tok[2]) != 0;
      isMaintenanceMode = atoi(tok[3]) != 0;
      ctxAssigned = atoi(tok[4]) != 0;
      ctxRecPunch = atoi(tok[5]) != 0;
      ctxTodayLogin = atoi(tok[6]) != 0;
      ctxHeld = strtoul(tok[7], NULL, 10);
      activeSmv = atol(tok[9]) / 1000.0;
      activeDivisor = atoi(tok[10]);
      operatorName = decText(tok[11]);
      if (!operatorReady || operatorName.length() == 0) operatorName = "UNKNOWN";
      locationName = decText(tok[12]);
      activeStyle = decText(tok[13]);
      activeProcess = decText(tok[14]);
      technicianName = decText(tok[15]);
      provisionalLoginActive = (n >= 17 && atoi(tok[16]) != 0);
      provisionalCardId = n >= 18 ? decText(tok[17]) : "";
      stmMachineBinding = n >= 19 ? decText(tok[18]) : "";
    }
    ctxSeen = true;
    needOledUpdate = true;
  } else if (!strcmp(cmd, "BOOT")) {
    if (n < 10) return;
    ++rxBootFrames;
    stm.seen = true;
    stm.proto = atoi(tok[1]);
    stm.profile = atoi(tok[2]);
    String newUid = tok[4];
    stm.resetFlags = strtoul(tok[5], NULL, 16);
    stm.framState = atoi(tok[6]);
    stm.rtcOk = atoi(tok[7]) == 1;
    strncpy(stm.fwRev, tok[8], sizeof(stm.fwRev) - 1);
    // FRAM nai (seq reboot-e restart hoy) ba onno STM32 -> duplicate table clear
    stm.seqEpoch = (uint32_t)strtoul(tok[9], NULL, 16);
    strncpy(stm.uid, newUid.c_str(), sizeof(stm.uid) - 1);   // duplicate key (epoch,seq): clear dorkar nai
    char rstTxt[40];
    stmResetText(stm.resetFlags, rstTxt, sizeof(rstTxt));
    Serial.printf("[STM32 BOOT] proto=%d profile=%d(%s) uid=%s resetFlags=0x%02lX(%s) FRAM=%d RTC=%s fw=%s epoch=%08lX\n",
                  stm.proto, stm.profile, tok[3], stm.uid, (unsigned long)stm.resetFlags, rstTxt, stm.framState, tok[7], stm.fwRev,
                  (unsigned long)stm.seqEpoch);
    Serial.printf("[STM32 BOOT] reset karon: %s\n", stmResetMeaning(stm.resetFlags));
    evaluateHold();
    if (isTimeSynced) pushTimeToStm();
    needOledUpdate = true;
  }
}

// Reliable command: "<body>,<id>" pathiye reply-er jonno wait, na pele retry (same id).
// Return: 1 = OK, 2 = NAK, 0 = kono reply nai. linkTask theke call kora jabe na.
int stmCommand(const char* body) {
  xSemaphoreTake(cmdMutex, portMAX_DELAY);
  uint32_t id = newCmdId();
  int result = 0;
  cmdReplyId = 0;
  cmdReplyKind = 0;
  cmdAwaitId = id;
  for (int attempt = 0; attempt < CMD_RETRIES && result == 0; attempt++) {
    linkSendf("%s,%lu", body, (unsigned long)id);
    unsigned long t0 = millis();
    while (millis() - t0 < CMD_REPLY_WAIT_MS) {
      if (cmdReplyId == id) { result = cmdReplyKind; break; }
      vTaskDelay(pdMS_TO_TICKS(5));
    }
  }
  cmdAwaitId = 0;
  xSemaphoreGive(cmdMutex);
  if (result == 0) Serial.printf("[LINK] No STM32 reply for: %s\n", body);
  return result;
}

// ---- link task (step function: bounded work per call) ----
char linkRxBuf[900];                 // F3: EV/CTX frame-e name field
size_t linkRxLen = 0;
unsigned long linkLastEhb = 0;

// ---- EVTASK 2026-11-02j ----
// Log proof: notun event (SD custody write/verify ~5 s) linkTask-e process hoto; oi somoy HB / CTX /
// CMDOK UART buffer-e pore thakto -> HB_AGE 5-20 s -> "STM LINK LOST", display TP/AC deri-te update,
// ar LOGIN-er CMDOK 2 s-e na pore "[LINK] No STM32 reply ... STM32 did not accept login" (STM32 asole
// login niyechilo). Ekhon EV frame alada EvTask-er queue-e jay; linkTask shudhu UART pore + HB/CTX/
// CMD reply sathe sathe handle kore. EV order thik thake (FIFO). Queue full hole frame drop ->
// STM32 FRAM-e thake, nijei abar pathabe.
#define EVQ_DEPTH 12
struct EvFrame { char body[900]; };
static QueueHandle_t evQueue = nullptr;
TaskHandle_t evTaskHandle = NULL;
static volatile uint32_t evQueueDrops = 0;
uint32_t evQueueDropsView() { return evQueueDrops; }

void linkProcessFrame(char* buf) {
  char* star = strrchr(buf, '*');
  if (!star || strlen(star) != 5) { linkCrcErrors = linkCrcErrors + 1; return; }
  *star = 0;
  uint16_t rxCrc = (uint16_t)strtoul(star + 1, NULL, 16);
  char* body = buf + 1;
  if (crc16((const uint8_t*)body, strlen(body)) != rxCrc) { linkCrcErrors = linkCrcErrors + 1; return; }
  if (evQueue && strncmp(body, "EV,", 3) == 0) {   // EVTASK: SD kaj alada task-e
    stm.lastMs = millis();
    static EvFrame f;                               // linkTask-only (stack bachay)
    strlcpy(f.body, body, sizeof(f.body));
    if (xQueueSend(evQueue, &f, 0) != pdTRUE) evQueueDrops = evQueueDrops + 1;
    return;
  }
  char* tok[32];
  int n = 0;
  char* save = NULL;
  char* p = strtok_r(body, ",", &save);
  while (p && n < 32) { tok[n++] = p; p = strtok_r(NULL, ",", &save); }
  if (n > 0) {
    rdCopy(rdLinkStage, tok[0]);               // RESET-DEBUG: kon frame process korte giye atkalo
    handleStmLine(tok, n);
    rdCopy(rdLinkStage, "RX");
  }
}

// RESET-DEBUG: EHB ekhon RX burst-er majhe-o jay. Age 1024-byte budget-e 4-5 ta EV frame,
// protita SD/qMutex-e 2.5 s porjonto wait korte parto -> EHB 10+ s deri -> STM32 ESP-reset jhuki.
static void linkMaybeEhb() {
  if (millis() - linkLastEhb >= 1000) {
    linkLastEhb = millis();
    netWifiUp = WiFi.status() == WL_CONNECTED;
    linkSendf("EHB,%d,%d,%d,%d,%lu,%d", PROTO_VER, netWifiUp ? 1 : 0, lastMqttStatusState ? 1 : 0,
              netServerUp ? 1 : 0, (unsigned long)qPending(), holdReason ? 1 : 0);
  }
}

void linkTaskStep() {
  int budget = 1024;
  while (budget-- > 0 && StmLink.available()) {
    char c = (char)StmLink.read();
    if (c == '$') {
      linkRxLen = 0;
      linkRxBuf[linkRxLen++] = c;
    } else if (c == '\n' || c == '\r') {
      if (linkRxLen > 1) {
        linkRxBuf[linkRxLen] = 0;
        linkProcessFrame(linkRxBuf);
        esp_task_wdt_reset();                  // RESET-DEBUG: protiti frame bounded (mutex timeout) -> WDT feed
        linkLastStepMs = millis();
        linkMaybeEhb();
        taskYIELD();                           // LOG-FIX: same-priority Background/loop task-ke CPU dao
      }
      linkRxLen = 0;
    } else if (linkRxLen > 0 && linkRxLen < sizeof(linkRxBuf) - 1) {
      linkRxBuf[linkRxLen++] = c;
    } else if (linkRxLen >= sizeof(linkRxBuf) - 1) {
      linkRxLen = 0;
      linkCrcErrors = linkCrcErrors + 1;
    }
  }
  rdCopy(rdLinkStage, "EHB");
  linkMaybeEhb();
  rdCopy(rdLinkStage, "IDLE");
}

void evTask(void* pvParameters) {
  evTaskHandle = xTaskGetCurrentTaskHandle();
  esp_task_wdt_add(NULL);
  EvFrame* f = (EvFrame*)malloc(sizeof(EvFrame));
  for (;;) {
    esp_task_wdt_reset();
    if (!f) { vTaskDelay(pdMS_TO_TICKS(1000)); f = (EvFrame*)malloc(sizeof(EvFrame)); continue; }
    if (xQueueReceive(evQueue, f, pdMS_TO_TICKS(1000)) != pdTRUE) continue;
    char* tok[32];
    int n = 0;
    char* save = NULL;
    char* p = strtok_r(f->body, ",", &save);
    while (p && n < 32) { tok[n++] = p; p = strtok_r(NULL, ",", &save); }
    if (n > 0) handleStmLine(tok, n);             // EV path: SD custody + DB queue (age linkTask-e chilo)
    esp_task_wdt_reset();
    taskYIELD();
  }
}

void linkTask(void* pvParameters) {
  linkTaskHandle = xTaskGetCurrentTaskHandle();
  esp_task_wdt_add(NULL);
  linkSendf("HELLO,%d", PROTO_VER);            // STM32 BOOT info abar pathabe
  for (;;) {
    esp_task_wdt_reset();
    linkLastStepMs = millis();                 // RESET-DEBUG: [LINK STALL] detection
    linkTaskStep();
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

// =============================================================================
// 18) OLED  (legacy layout + queue / link / hold status)
// =============================================================================
void updateOledDisplay() {
  String op, lo, tech;
  bool maint;
  {
    SessLock l;
    op = operatorName; lo = locationName; tech = technicianName; maint = isMaintenanceMode;
  }
  bool online = lastMqttStatusState;

  display.clearDisplay();
  display.setTextColor(SH110X_WHITE);
  display.setTextSize(1);

  if (maint) {
    display.setCursor(10, 5);  display.println("=== SYSTEM ===");
    display.setCursor(0, 22);  display.println("MAINTENANCE MODE");
    display.setCursor(0, 42);  display.print("TECH: "); display.println(tech);
    display.setCursor(0, 54);  display.print("STATUS: "); display.print(online ? "ONLINE" : "OFFLINE");
    display.display();
    return;
  }

  display.setCursor(0, 0);   display.print("OP: "); display.println(op);
  display.setCursor(0, 14);  display.print("LO: "); display.println(lo);
  display.setCursor(0, 28);  display.print("TP: "); display.print(stm.tp);
  display.setCursor(68, 28); display.print("AP: "); display.print(stm.ta);
  display.setCursor(0, 42);  display.print("AC: "); display.print(stm.ac);
  display.setCursor(85, 42); display.print(online ? "ON" : "OFF");
  if (SD_ENABLED && (!sdOk || sdFull)) { display.setCursor(104, 42); display.print(sdFull ? "SDF" : "SD!"); }

  display.setCursor(0, 55);
  if (!stmAlive()) {
    display.print("STM LINK LOST");
  } else if (holdReason) {
    display.print("HOLD:"); display.print(HOLD_TEXT[holdReason]);
  } else if (dbRejectAlarm) {
    display.print("DB REJECT! CHECK");
  } else {
    display.print("PERF: ");
    if (stm.perf >= 0) { display.print(stm.perf); display.print("%"); }
    else display.print("--%");
    // BACKLOG: Q = SD queue (DB-te na jaoa) + STM32 FRAM (HELD + SD-te ekhono na lekha). RAM postQ SD-r-i ongsho.
    uint32_t q = (sdQueueKnown ? sdQueueCount : qPending()) + stm.outbox;
    if (q > 0) { display.setCursor(80, 55); display.print("Q:"); display.print(q); }
  }
  display.display();
}

// =============================================================================
// 19) RFID  (single RDM6300 on GPIO27 — operator / location / technician card)
// =============================================================================
void handleIncomingRfid(String newId) {
  newId.trim();
  newId.toUpperCase();
  if (newId == "") return;
  if (newId == lastScannedRfid && (millis() - lastRfidScanTime < RFID_SCAN_DEBOUNCE)) return;

  Serial.println("\n[RFID SCAN] Scanned Code: " + newId);
  lastScannedRfid = newId;
  lastRfidScanTime = millis();
  stmBeep(100, 0, 1);
  identifyAndProcessRfid(newId);
}

void readRfid() {
  while (RfidSerial.available() > 0 && RfidSerial.peek() != 0x02) RfidSerial.read();   // frame resync
  if (RfidSerial.available() >= 14) {
    byte buffer[14];
    for (int i = 0; i < 14; i++) buffer[i] = RfidSerial.read();
    if (buffer[0] == 0x02 && buffer[13] == 0x03) {
      // RDM6300: STX + 10 uppercase hex ID + 2 hex XOR checksum + ETX.
      // Invalid frames must NOT generate provisional WORK_START events.
      uint8_t xorByte = 0; bool good = true;
      auto nibble = [](byte c) -> int {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        return -1;
      };
      for (int i = 1; i <= 9 && good; i += 2) {
        int a=nibble(buffer[i]), b=nibble(buffer[i+1]);
        if (a < 0 || b < 0) good = false;
        else xorByte ^= (uint8_t)((a << 4) | b);
      }
      int hi=nibble(buffer[11]), lo=nibble(buffer[12]);
      if (hi < 0 || lo < 0 || !good || xorByte != (uint8_t)((hi << 4) | lo)) {
        Serial.println("[RFID] BAD CHECKSUM: ignored");
      } else {
        String tempCode;
        for (int i=1;i<=10;i++) tempCode += (char)toupper(buffer[i]);
        handleIncomingRfid(tempCode);
      }
    }
  }
}

static void provisionalCardPunch(const String& card, const char* why) {
  // No server identity/role could be established. Per approved policy any
  // checksum-valid scanned card is treated as a provisional OPERATOR punch.
  // NEVER claim it to be an authorised operator/location/technician card.
  if (!stmAlive() || !ctxSeen) {
    Serial.println("[RFID OFFLINE] No STM32 durable link; scan not accepted. Retry card.");
    errorBeep();
    return;
  }
  // Same offline card already has an acknowledged provisional session in STM32.
  // Repeated physical scans must not be presented as new WORK_START events.
  { SessLock l;
    if (provisionalLoginActive && provisionalCardId == card && stmMachineBinding == MACHINE_ID) {
      Serial.println("[RFID OFFLINE] SAME_CARD_ALREADY_PENDING; no new WORK_START");
      return;
    }
  }
  String body = "PLOGIN," + encText(card) + "," + encText(MACHINE_ID);
  if (stmCommand(body.c_str()) != 1) {
    Serial.println("[RFID OFFLINE] STM32 FRAM commit not acknowledged; scan NOT confirmed.");
    errorBeep();
    return;
  }
  { SessLock l;
    provisionalLoginActive = true;
    provisionalCardId = card;
    operatorReady = true;
    operatorName = card;
    activeStyle = "UNKNOWN";
    activeProcess = "UNKNOWN";
    activeSmv = 0.0;
    activeDivisor = 1; // computation default; assignment still UNKNOWN
  }
  needOledUpdate = true;
  Serial.printf("[RFID OFFLINE] WORK_START PENDING_VALIDATION | card=%s reason=%s\n", card.c_str(), why);
  tripleBeep();
}

void identifyAndProcessRfid(String scannedRfid) {
  if (holdReason) {
    Serial.printf("[RFID ERROR] Device on HOLD (%s) — identity not confirmed.\n", HOLD_TEXT[holdReason]);
    errorBeep();
    return;
  }
  if (WiFi.status() != WL_CONNECTED || !mqttClient.connected()) {
    provisionalCardPunch(scannedRfid, "NETWORK_OR_BROKER_DOWN");
    return;
  }
  if (!stmAlive() || !ctxSeen) {                 // F3: session STM32 FRAM-e save hoy -> link dorkar
    Serial.println("[RFID ERROR] STM32 link down: card data save kora jabe na. Abar punch korun.");
    errorBeep();
    return;
  }

  JDOC(requestDoc, 128);
  requestDoc["rfid"] = scannedRfid;
  String response;
  Serial.println("[RFID PROCESS] Checking Tag: " + scannedRfid);
  bool received = mqttRequest(TOPIC_ASSETS_GET, requestDoc.as<JsonVariantConst>(), response, cfg.tAssets);
  if (!received) {
    Serial.println("[RFID] Asset lookup unavailable; provisional card login.");
    provisionalCardPunch(scannedRfid, "ASSET_LOOKUP_TIMEOUT");
    return;
  }

  JDOC(doc, 1024);
  DeserializationError error = deserializeJson(doc, response);
  if (error || (doc["status"] | 500) != 200) {
    provisionalCardPunch(scannedRfid, "ASSET_RESPONSE_UNAVAILABLE");
    return;
  }

  JsonArray dataArray = doc["data"].as<JsonArray>();
  if (dataArray.isNull() || dataArray.size() == 0) {
    provisionalCardPunch(scannedRfid, "UNKNOWN_CARD_NO_MATCH");
    return;
  }

  JsonObject item = dataArray[0];
  String assetType = item["assetType"] | "";
  assetType.trim();
  assetType.toLowerCase();

  // UNIVERSAL MAINTENANCE / MECHANIC LOGIC  (F3: STM32 FRAM-e save + event STM32 outbox-e)
  if (assetType == "technician" || assetType == "mechanic") {
    String tech = jstr(item["id"]);
    if (tech == "") tech = jstr(item["name"]);
    if (tech == "") tech = "UNKNOWN_TECH";
    String body = "MAINT,1," + encText(tech) + "," + encText(scannedRfid);
    if (stmCommand(body.c_str()) != 1) { Serial.println("[MAINTENANCE] STM32 did not accept"); errorBeep(); return; }
    { SessLock l; isMaintenanceMode = true; technicianName = tech; }
    needOledUpdate = true;
    updateOledDisplay();
    tripleBeep();
    Serial.println("[MAINTENANCE] Mode ON | Technician: " + tech);
    return;
  }

  // OPERATOR CARD: maintenance active thakle first operator scan maintenance exit kore
  if (assetType == "operator") {
    bool inMaint;
    { SessLock l; inMaint = isMaintenanceMode; }

    if (inMaint) {
      if (stmCommand("MAINT,0") != 1) { Serial.println("[MAINTENANCE] STM32 did not accept"); errorBeep(); return; }
      { SessLock l; isMaintenanceMode = false; technicianName = "NONE"; }
      needOledUpdate = true;
      updateOledDisplay();
      tripleBeep();
      Serial.println("[MAINTENANCE] Mode OFF -> Production mode restored.");
      return;
    }

    String opName = jstr(item["id"]);
    if (opName == "") opName = "UNKNOWN";
    String loc, style, proc;
    double smv;
    int div;
    { SessLock l; loc = locationName; style = activeStyle; proc = activeProcess; smv = activeSmv; div = activeDivisor; }
    fetchMachineLocation(loc, style, proc, smv, div);          // server value (fail hole current)
    char num[32];
    snprintf(num, sizeof(num), "%ld,%d", (long)(smv * 1000.0 + 0.5), div);
    String body = "LOGIN," + encText(scannedRfid) + "," + encText(opName) + "," + encText(loc) + "," +
                  encText(style) + "," + encText(proc) + "," + num;
    if (stmCommand(body.c_str()) != 1) { Serial.println("[LOGIN] STM32 did not accept login"); errorBeep(); return; }
    uint32_t heldBefore = ctxHeld;
    {
      SessLock l;
      operatorReady = true;
      provisionalLoginActive = false; provisionalCardId = "";
      operatorName = opName;
      locationName = loc; activeStyle = style; activeProcess = proc; activeSmv = smv; activeDivisor = div;
    }
    Serial.printf("[LOGIN] Operator %s logged in; %lu UNKNOWN event(s) now under this operator\n",
                  opName.c_str(), (unsigned long)heldBefore);
    sendLocationEntryToServer(loc, opName);
    needOledUpdate = true;
    updateOledDisplay();
    tripleBeep();

    processOfflineQueue(5000, 15000);              // max 15 s (RFID/OLED freeze bounded)
    // Do not reboot after a successful login: this used to re-trigger backlog
    // replay, WiFi association and stale operator recovery on every punch.
    // STM32 session authority and durable journal remain unchanged.
    Serial.println("[LOGIN] Session accepted; ESP stays online (no forced reboot)");
    return;
  }

  if (assetType == "location") {
    String loc = jstr(item["line"]);
    if (loc == "") loc = jstr(item["name"]);
    loc.trim();
    if (loc == "") loc = "UNKNOWN";
    // STM32: SESSION counters 0, operator logout, smv 0, divisor 1, notun location session.
    // STM32 pending event finalize kore; outbox/SD-er record muche na.
    String body = "LOCATION," + encText(scannedRfid) + "," + encText(loc);
    if (stmCommand(body.c_str()) != 1) { Serial.println("[LOCATION] STM32 did not accept"); errorBeep(); return; }
    {
      SessLock l;
      operatorReady = false;
      operatorName = "UNKNOWN";
      activeStyle = "NONE";
      activeProcess = "NONE";
      activeSmv = 0.0;
      activeDivisor = 1;
      locationName = loc;
    }
    stm.tp = 0; stm.ta = 0; stm.ac = 0;
    needOledUpdate = true;
    sendLocationEntryToServer(loc, "NONE");        // legacy: operator NONE
    return;
  }

  provisionalCardPunch(scannedRfid, "ASSET_TYPE_UNKNOWN");
}

// Server machine-location (legacy). Fail hole caller-er value same thake.
void fetchMachineLocation(String& loc, String& style, String& proc, double& smv, int& div) {
  if (WiFi.status() != WL_CONNECTED) return;
  JDOC(requestDoc, 128);
  requestDoc["machine"] = MACHINE_ID;
  String response;
  bool received = mqttRequest(TOPIC_MACHINE_LOCATION_GET, requestDoc.as<JsonVariantConst>(), response, cfg.tLocation);
  if (received) {
    JDOC(doc, 1024);
    DeserializationError error = deserializeJson(doc, response);
    if (!error && (doc["status"] | 500) == 200) {
      loc = doc["location"] | "UNKNOWN";
      style = doc["style"] | "UNKNOWN";
      proc = doc["process"] | "UNKNOWN";
      smv = doc["smv"] | 0.0;
      div = doc["divisor"] | 1;
    }
  }
  needOledUpdate = true;
}

void sendLocationEntryToServer(String lineName, String opName) {
  if (WiFi.status() != WL_CONNECTED) return;
  lineName.trim();
  JDOC(requestDoc, 256);
  requestDoc["line"] = lineName;
  requestDoc["machine"] = MACHINE_ID;
  requestDoc["operator"] = opName;
  String response;
  mqttRequest(TOPIC_LAYOUT_SCAN, requestDoc.as<JsonVariantConst>(), response, cfg.tLayout);
}

// =============================================================================
// 20) STATE RECOVERY (legacy) — server state STM32-e RESTORE diye jay (all-or-nothing).
//     Shudhu tokhon jokhon ESP queue + STM32 outbox + aggregate sob khali.
// =============================================================================
bool recoverLastMachineState() {
  if (WiFi.status() != WL_CONNECTED || holdReason) return false;
  if (!ctxSeen) return false;                        // STM32 CTX (recPunch) ekhono ase ni
  if (provisionalLoginActive) return false; // never overwrite offline counts with old server snapshot

  // Server state shudhu (a) card punch-er por, ba (b) ajker production day-te login kora operator-er
  // ESP reboot-e. Daily reset-er por kono punch chhara purono operator / counter ferot ashbe na.
  bool punch = ctxRecPunch;
  bool todaySession = ctxTodayLogin;
  if (!punch && !todaySession) {
    Serial.println("[STATE RECOVERY] Skipped: no card punch in current production day.");
    return true;
  }

  uint32_t expectSeq = stm.seq;
  if (stm.outbox != 0 || stm.aggPending || qPending() != 0) return false;

  Serial.println("[STATE RECOVERY] Fetching last machine state from server...");
  JDOC(requestDoc, 128);
  requestDoc["machineId"] = MACHINE_ID;
  requestDoc["mode"] = "last-machine-state";

  String response;
  bool received = mqttRequest(TOPIC_PRODUCTION_GET, requestDoc.as<JsonVariantConst>(), response, cfg.tProdGet);
  if (!received) return false;

  JDOC(doc, 2048);
  DeserializationError error = deserializeJson(doc, response);
  if (error || (doc["status"] | 500) != 200) return false;

  if (doc["found"] | false) {
    if (qPending() != 0 || stm.outbox != 0 || stm.seq != expectSeq) return false;   // request cholakalin notun event
    JsonObject data = doc["data"];
    long tp = data["totalProduction"] | 0;
    long ta = data["totalAlter"] | 0;
    long ac = data["actualProduction"] | 0;
    String op = data["operator"] | "NONE";
    String loc = data["location"] | "NONE";
    String style = data["style"] | "NONE";
    String proc = data["process"] | "NONE";
    double restoredSmv = data["smv"] | 0.0;
    double smv = restoredSmv > 0 ? restoredSmv : 0.6;
    int div = data["divisor"] | 1;
    char num[96];
    snprintf(num, sizeof(num), "%ld,%d,%ld,%ld,%ld,%lu,%lu", (long)(smv * 1000.0 + 0.5), div, tp, ta, ac,
             (unsigned long)expectSeq, (unsigned long)stm.prodDay);
    String body = "RESTORE," + encText(op) + "," + encText(loc) + "," + encText(style) + "," + encText(proc) + "," + num;
    int r = stmCommand(body.c_str());
    if (r != 1) return false;                    // NAK (BUSY / DAY) ba reply nai -> 10 s pore retry
    needOledUpdate = true;
    Serial.println("[STATE RECOVERY] STM32 accepted server state (operator + counters).");
    return true;
  }
  if (punch && stmCommand("RECDONE") != 1) return false;
  return true;
}

// =============================================================================
// 21) BACKGROUND TASK (WiFi, MQTT reconnect/backoff, queue, recovery, time, SD)
// =============================================================================
unsigned long bgLastWiFiReconnectAttempt = 0;
unsigned long bgLastMqttReconnectAttempt = 0;
unsigned long bgLastQueueCheck = 0;
unsigned long bgLastStateRecoveryAttempt = 0;
unsigned long bgLastSdRetry = 0;
unsigned long bgSdRetryIntervalMs = SD_RETRY_MIN_MS;   // 2026-10-27: remount backoff
unsigned long bgLastSdHousekeeping = 0;
bool bgFirstRecovery = true;

static unsigned long lastProvisionalLookupMs = 0;
static void tryProvisionalLookup() {
  // This reconciles CURRENT server lookup only. The backend currently has no
  // historical effective-time / versioned mapping contract, so old SD events
  // remain PENDING_VALIDATION and are never rewritten or sent to legacy POST.
  String card, binding;
  bool pending;
  { SessLock l; pending=provisionalLoginActive; card=provisionalCardId; binding=stmMachineBinding; }
  if (!pending || card.length() != 10 || binding != MACHINE_ID || !stmAlive() ||
      !ctxSeen || holdReason || WiFi.status()!=WL_CONNECTED || !mqttClient.connected()) return;
  if (lastProvisionalLookupMs && millis()-lastProvisionalLookupMs < 60000UL) return;
  lastProvisionalLookupMs = millis();
  JDOC(req,128); req["rfid"] = card;
  String response;
  if (!mqttRequest(TOPIC_ASSETS_GET,req.as<JsonVariantConst>(),response,cfg.tAssets)) return;
  JDOC(doc,1024);
  if (deserializeJson(doc,response) || (doc["status"]|500)!=200) return;
  JsonArray arr=doc["data"].as<JsonArray>();
  if (arr.isNull() || arr.size()!=1) {
    Serial.printf("[RFID RECON] Card=%s ambiguous/not found. Still pending.\n",card.c_str());
    return;
  }
  JsonObject item=arr[0];
  String typ=item["assetType"]|""; typ.toLowerCase();
  if (typ!="operator") {
    Serial.printf("[RFID RECON] Card=%s type conflict (%s). Manual review pending.\n",card.c_str(),typ.c_str());
    return;
  }
  String op=jstr(item["id"]); if (op.length()==0) op=jstr(item["name"]);
  if (op.length()==0) return;
  JDOC(reqLoc,128); reqLoc["machine"]=MACHINE_ID;
  response="";
  if (!mqttRequest(TOPIC_MACHINE_LOCATION_GET,reqLoc.as<JsonVariantConst>(),response,cfg.tLocation)) return;
  JDOC(locDoc,1024);
  if (deserializeJson(locDoc,response) || (locDoc["status"]|500)!=200) return;
  String loc=locDoc["location"]|"";
  String style=locDoc["style"]|"";
  String proc=locDoc["process"]|"";
  double smv=locDoc["smv"]|0.0;
  int div=locDoc["divisor"]|0;
  if (loc.length()==0 || style.length()==0 || proc.length()==0 || smv<=0 || div<=0) return;
  // Limit serialized numeric magnitude and frame size.
  if (smv > 10000 || div > 32767) return;
  char n[48]; snprintf(n,sizeof(n),"%ld,%d",(long)(smv*1000.0+0.5),div);
  String cmd="PRESOLVE,"+encText(card)+","+encText(op)+","+encText(loc)+","+
             encText(style)+","+encText(proc)+","+String(n);
  if (cmd.length() > 480) return;
  if (stmCommand(cmd.c_str())==1) {
    Serial.println("[RFID RECON] Current server lookup appended; prior SD events remain pending historic validation.");
    needOledUpdate=true;
  }
}

void backgroundStep() {
  bgSetStage("REFILL");
  bgLastProgressMs = millis();
  // Passive connection diagnostics; no external service or data-publishing effect.
  static uint32_t lastReportedWiFiDisconnects = 0;
  const uint32_t disconnCount = wifiDisconnectEventCount;
  if (disconnCount != lastReportedWiFiDisconnects) {
    lastReportedWiFiDisconnects = disconnCount;
    Serial.printf("[WIFI-REASON] status=%d reason=%u disconnections=%lu\n",
                  (int)WiFi.status(), (unsigned)wifiLastDisconnectReason,
                  (unsigned long)disconnCount);
  }
  // Refill 64-item work window from immutable SD spool even with Wi-Fi down.
  // This lets >64 pending events survive ESP reset; never delete .evt records.
  if (sdOk && stm.seen && xSemaphoreTake(qMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    custodyRefillUnlocked();
    sdQueueCountStepUnlocked();          // BACKLOG: SD queue gona
    xSemaphoreGive(qMutex);
  }
  bgSetStage("BIND"); bgLastProgressMs = millis();
  serviceBindRequest();
  netWifiUp = WiFi.status() == WL_CONNECTED;
  // 2026-10-27: WiFi chole gele stale TCP socket bondho (non-blocking stop) -> MQTT=1 vul dekhay na,
  // ar "Broker restored" WiFi chhara fire hoy na. Reconnect normal path-e hobe.
  if (!netWifiUp && mqttClient.connected() && xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
    mqttNetworkClient.stop();
    xSemaphoreGive(mqttMutex);
    Serial.println("[MQTT] WiFi down -> stale broker socket closed");
  }
  bool currentMqttState = (netWifiUp && mqttClient.connected());
  netBrokerUp = currentMqttState;
  if (currentMqttState != lastMqttStatusState) {
    if (currentMqttState) {
      lastProvisionalLookupMs = 0; // immediate CURRENT operator reconciliation
      stage1LastServerTimeTryMs = 0; // immediate worker-time check
      Serial.println("[ONLINE-RECOVERY] Broker restored; rechecking time/current RFID only");
      Serial.printf("[NET-ROUTE] ip=%s mask=%s gw=%s broker=%s:%u\n",
                    WiFi.localIP().toString().c_str(), WiFi.subnetMask().toString().c_str(),
                    WiFi.gatewayIP().toString().c_str(), MQTT_BROKER_HOST, MQTT_BROKER_PORT);
    }
    lastMqttStatusState = currentMqttState;
    needOledUpdate = true;
  }
  if (netServerUp && millis() - lastServerReplyMs > 300000UL && serverTimeoutsInRow > 0) netServerUp = false;

  if (netReconfigPending && ssid && *ssid) {
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(250)) == pdTRUE) {
      mqttClient.disconnect();
      xSemaphoreGive(mqttMutex);
    }
    connectWiFi();
  }

  if (netWifiUp) {
    if (mqttClient.connected()) {
      mqttBackoffMs = MQTT_BACKOFF_MIN_MS;
      if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
        setDebugCheckpoint("BACKGROUND_MQTT_LOOP");
        bgSetStage("MQTT_LOOP"); bgLastProgressMs = millis();
        mqttClient.loop();
        xSemaphoreGive(mqttMutex);
      }

      // PRIORITY: never hold production post behind time, provisional RFID or
      // machine-state GET. Retry backoff and strict database ACK remain unchanged.
    if (mqttClient.connected() && qPending() > 0 &&
        (qNextAttemptMs == 0 || (long)(millis() - qNextAttemptMs) >= 0)) {
      setDebugCheckpoint("BACKGROUND_QUEUE_CHECK");
      bgSetStage("DB_QUEUE"); bgLastProgressMs = millis();
      // Non-blocking, bounded work quantum; individual network calls still
      // need their own timeout. No queue item or immutable file is discarded.
      processOfflineQueue(0, 4000);
      bgLastQueueCheck = millis();
    }
      // If production remains pending, defer nonessential server lookups.
      // STM32 RTC / immutable SD timestamps are unaffected.
      if (qPending() == 0) {
        bgSetStage("SERVER_TIME"); bgLastProgressMs = millis();
        stage1TryServerTime();
      }
      // Keep provisional identity reconciliation enabled even when DB queue is pending.
      bgSetStage("RFID_LOOKUP"); bgLastProgressMs = millis();
      tryProvisionalLookup();

      if (!isStateRecovered && !holdReason && stmAlive() && ctxSeen && qPending() == 0 && stm.outbox == 0 && !stm.aggPending &&
          (bgFirstRecovery || millis() - bgLastStateRecoveryAttempt > 10000)) {
        bgFirstRecovery = false;
        bgLastStateRecoveryAttempt = millis();
        Serial.println("[BG Task] Machine State not recovered yet. Attempting now...");
        isStateRecovered = recoverLastMachineState();
      }
    } else if (MACHINE_ID.length() && millis() - bgLastMqttReconnectAttempt >= mqttBackoffMs) {
      bgLastMqttReconnectAttempt = millis();
      setDebugCheckpoint("BACKGROUND_MQTT_RECONNECT");
      if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(250)) == pdTRUE) {
        bgSetStage("MQTT_CONNECT"); bgLastProgressMs = millis();
        bool ok = ensureMqttConnectedUnlocked();
        xSemaphoreGive(mqttMutex);
        if (!ok) mqttBackoffMs = mqttBackoffMs * 2 > MQTT_BACKOFF_MAX_MS ? MQTT_BACKOFF_MAX_MS : mqttBackoffMs * 2;
      }
    }

    if (qPending() == 0) legacyQueueDrainStep();     // upgrade: purono /smuq backlog (current queue khali hole)
    // NTP is WAN-bound; prioritize production and LAN clock before retrying it.
    if (!isTimeSynced && qPending() == 0 && stm.outbox == 0) {
      static unsigned long lastNtp = 0;
      if (lastNtp == 0 || millis() - lastNtp > 60000UL) {
        lastNtp = millis();
        setDebugCheckpoint("BACKGROUND_NTP_SYNC");
        bgSetStage("NTP"); bgLastProgressMs = millis();
        syncTimeFirstTime();
        if (isTimeSynced) pushTimeToStm();
      }
    } else if (isTimeSynced && (!timePushedOnce || millis() - lastTimePushMs > TIME_PUSH_INTERVAL_MS)) {
      pushTimeToStm();
    }

  } else if (millis() - bgLastWiFiReconnectAttempt > 10000) {
    Serial.println("[BG Task] WiFi Disconnected! Attempting Reconnect...");
    setDebugCheckpoint("BACKGROUND_WIFI_RECONNECT");
    bgSetStage("WIFI_RECONNECT"); bgLastProgressMs = millis();
    connectWiFi();
    bgLastWiFiReconnectAttempt = millis();
  }

#if SD_ENABLED
  // SD remount try. 2026-10-27: bar bar fail hole 30 s -> 60 -> 120 -> ... -> 5 min (hung card-e
  // protibar qMutex dhore mount retry EV handling dhir kore dey). Mount PASS hole abar 30 s.
  if (!sdOk && millis() - bgLastSdRetry > bgSdRetryIntervalMs) {
    bgLastSdRetry = millis();
    bgSetStage("SD_REMOUNT"); bgLastProgressMs = millis();
    wdtResetIfSubscribed();
    xSemaphoreTake(qMutex, portMAX_DELAY);
    custodyCloseScan();
    SD.end();
    sdOk = sdInit();
    xSemaphoreGive(qMutex);
    if (sdOk) bgSdRetryIntervalMs = SD_RETRY_MIN_MS;
    else {
      bgSdRetryIntervalMs = bgSdRetryIntervalMs * 2 > SD_RETRY_MAX_MS ? SD_RETRY_MAX_MS : bgSdRetryIntervalMs * 2;
      Serial.printf("[SD] next remount try in %lu s (card power-cycle dorkar hote pare; DB delivery cholche)\n",
                    (unsigned long)(bgSdRetryIntervalMs / 1000UL));
    }
    needOledUpdate = true;
  }
  if (sdOk && !sdSeededWithTime && (unsigned long)time(nullptr) > 1700000000UL) {   // time ekhon jana: ajker log seed
    bgSetStage("SD_LOG_SEED"); bgLastProgressMs = millis();
    xSemaphoreTake(qMutex, portMAX_DELAY);
    sdSeedRecentFromLog();
    xSemaphoreGive(qMutex);
  }
  if (sdOk && (bgLastSdHousekeeping == 0 || millis() - bgLastSdHousekeeping > 60000UL)) {
    bgLastSdHousekeeping = millis();
    // Phase D: SD/FAT operations share qMutex with custody commit, replay,
    // remount and SD log. Never query filesystem allocation concurrently.
    // sdInit() already runs under qMutex and calls sdRefreshFree() itself;
    // only the background housekeeping CALLER takes this lock.
    if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(500)) == pdTRUE) {
      bgSetStage("SD_SPACE"); bgLastProgressMs = millis();
      sdRefreshFree();                                // non-destructive free-space measurement
      xSemaphoreGive(qMutex);
    }
  }
  bgSetStage("PROOF_REPAIR"); bgLastProgressMs = millis();
  dbProofRepairOne(); // one deferred receipt / DB_PROOF_RETRY_MS; strict .evt/.ok checks
#endif
  bgSetStage("IDLE");
  bgLastProgressMs = millis();
}

void backgroundTask(void* pvParameters) {
  backgroundTaskHandle = xTaskGetCurrentTaskHandle();
  esp_task_wdt_add(NULL);
  setDebugCheckpoint("BACKGROUND_TASK_STARTED");
  for (;;) {
    esp_task_wdt_reset();
    backgroundStep();
    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

// =============================================================================
// RECOVERY: SD byte-level console transport. Paths are tightly restricted.
// READ/LIST never change SD data. Staging is isolated from live custody files.
// Mutations require external PC backup; firmware cannot verify PC ownership.
// =============================================================================
static uint32_t recoveryCrc32File(File& f) {
  uint32_t crc=0xFFFFFFFFu;
  f.seek(0);
  while (f.available()) {
    uint8_t b=(uint8_t)f.read();
    crc^=b;
    for (uint8_t j=0;j<8;j++) crc=(crc>>1) ^ (0xEDB88320UL & (uint32_t)-(int32_t)(crc&1));
    if ((f.position() & 0xFFF)==0) { wdtResetIfSubscribed(); vTaskDelay(1); }
  }
  return ~crc;
}
static bool recoveryHexParse(const String& s,uint8_t* output,size_t& len) {
  len=0;
  if (!s.length() || s.length()>128 || s.length()%2) return false;
  for (unsigned i=0;i<s.length();i+=2) {
    int h=isxdigit((unsigned char)s[i]) ? (isdigit((unsigned char)s[i]) ? s[i]-'0' : toupper(s[i])-'A'+10) : -1;
    int l=isxdigit((unsigned char)s[i+1]) ? (isdigit((unsigned char)s[i+1]) ? s[i+1]-'0' : toupper(s[i+1])-'A'+10) : -1;
    if (h<0 || l<0) return false;
    output[len++]=(uint8_t)((h<<4)|l);
  }
  return true;
}
static bool recoveryIdValid(const String& id) {
  if (id.length()!=16) return false;
  for (unsigned i=0;i<id.length();i++) if (!isxdigit((unsigned char)id[i])) return false;
  return true;
}
static String recoveryStagePath(const String& id) { return String("/smu/recovery/")+id+".part"; }
static void recoverySdList(const String& dir) {
  if (!sdOk || !recoverySafePath(dir)) {Serial.println("@TREEERR,PATH_OR_SD");return;}
  if (xSemaphoreTake(qMutex,pdMS_TO_TICKS(2000))!=pdTRUE) {Serial.println("@TREEERR,BUSY");return;}
  File d=SD.open(dir);
  if (!d || !d.isDirectory()) {if(d)d.close();xSemaphoreGive(qMutex);Serial.println("@TREEERR,NOT_DIR");return;}
  File f;
  while ((f=d.openNextFile())) {
    String full=String(f.name());
    if (!full.startsWith("/")) full=dir+"/"+full;
    if (recoverySafePath(full)) Serial.printf("@ENTRY,%c,%s,%lu\n",f.isDirectory()?'D':'F',full.c_str(),(unsigned long)f.size());
    f.close();
    vTaskDelay(1);
  }
  d.close();xSemaphoreGive(qMutex);
  Serial.printf("@ENDTREE,%s\n",dir.c_str());
}
static void recoverySdRead(const String& arg) {
  int sp=arg.lastIndexOf(' ');
  if (sp<1) {Serial.println("@SDERR,ARGS");return;}
  String path=arg.substring(0,sp);String offText=arg.substring(sp+1);
  char* e=nullptr;unsigned long offset=strtoul(offText.c_str(),&e,10);
  if (!recoverySafePath(path) || !e || *e || !offText.length()) {Serial.println("@SDERR,PATH_OR_OFFSET");return;}
  if (xSemaphoreTake(qMutex,pdMS_TO_TICKS(2000))!=pdTRUE) {Serial.println("@SDERR,BUSY");return;}
  File f=SD.open(path,FILE_READ);
  if (!f || f.isDirectory() || offset>f.size() || !f.seek(offset)) {
    if(f)f.close();xSemaphoreGive(qMutex);Serial.println("@SDERR,READ");return;
  }
  uint8_t raw[64];size_t n=f.read(raw,sizeof(raw));f.close();xSemaphoreGive(qMutex);
  char hex[129];const char* alphabet="0123456789ABCDEF";
  for (size_t i=0;i<n;i++){hex[i*2]=alphabet[raw[i]>>4];hex[i*2+1]=alphabet[raw[i]&15];}
  hex[n*2]=0;
  Serial.printf("@SD,%s,%lu,%s\n",path.c_str(),offset,hex);
}
static void recoverySdStage(const String& arg) {
  // Upload is only to /smu/recovery/<id>.part; never overwrites live data.
  int a=arg.indexOf(' '),b=arg.indexOf(' ',a+1);
  if(a<0||b<0){Serial.println("@STAGEERR,ARGS");return;}
  String id=arg.substring(0,a),ofs=arg.substring(a+1,b),hex=arg.substring(b+1);
  char* e=nullptr;unsigned long offset=strtoul(ofs.c_str(),&e,10);
  uint8_t raw[64];size_t n=0;
  if(!recoveryIdValid(id)||!ofs.length()||!e||*e||!recoveryHexParse(hex,raw,n)) {Serial.println("@STAGEERR,DATA");return;}
  if (!sdOk || !SD.exists("/smu/recovery") || xSemaphoreTake(qMutex,pdMS_TO_TICKS(2000))!=pdTRUE){Serial.println("@STAGEERR,SD_BUSY");return;}
  String path=recoveryStagePath(id);
  bool exists=SD.exists(path);
  File old;
  if (exists) old=SD.open(path,FILE_READ);
  uint32_t size=old?old.size():0;
  if(old)old.close();
  if((offset==0 && exists) || (offset>0 && (!exists||size!=offset))) {
    xSemaphoreGive(qMutex);Serial.println("@STAGEERR,OFFSET_OR_EXISTS");return;
  }
  File f=SD.open(path,offset==0?FILE_WRITE:FILE_APPEND);
  bool ok=f && f.write(raw,n)==n;
  if(f){f.flush();f.close();}
  File v=SD.open(path,FILE_READ);
  if(!v || v.size()!=offset+n || !v.seek(offset)) ok=false;
  if(ok)for(size_t i=0;i<n;i++)if(v.read()!=raw[i]){ok=false;break;}
  if(v)v.close();
  xSemaphoreGive(qMutex);
  if(ok)Serial.printf("@STAGED,%s,%lu,%u\n",id.c_str(),offset,(unsigned)n);
  else Serial.println("@STAGEERR,WRITE_VERIFY");
}
static void recoverySdCommit(const String& arg) {
  // Do not replace any existing SD path. Atomic rename on same FAT volume is
  // best-effort; all application `.evt`/`.ok` validation remains unchanged.
  int a=arg.indexOf(' '),b=arg.indexOf(' ',a+1),c=arg.indexOf(' ',b+1);
  if(a<0||b<0||c<0){Serial.println("@COMMITERR,ARGS");return;}
  String id=arg.substring(0,a),target=arg.substring(a+1,b),sz=arg.substring(b+1,c),crcText=arg.substring(c+1);
  char* e=nullptr;unsigned long size=strtoul(sz.c_str(),&e,10);
  if(!recoveryIdValid(id)||!recoverySafePath(target)||target.startsWith("/smu/recovery/")||target.startsWith("/smu/quarantine/")||!sz.length()||*e||crcText.length()!=8) {Serial.println("@COMMITERR,ARGS");return;}
  for(unsigned i=0;i<crcText.length();i++)if(!isxdigit((unsigned char)crcText[i])) {Serial.println("@COMMITERR,CRC_ARG");return;}
  uint32_t expect=strtoul(crcText.c_str(),nullptr,16);
  if(xSemaphoreTake(qMutex,pdMS_TO_TICKS(2000))!=pdTRUE){Serial.println("@COMMITERR,BUSY");return;}
  String stage=recoveryStagePath(id);
  File f=SD.open(stage,FILE_READ);
  bool ok=f && f.size()==size;
  uint32_t actual=ok?recoveryCrc32File(f):0;
  if(f)f.close();
  if(ok && actual==expect && !SD.exists(target)) ok=SD.rename(stage,target);
  else ok=false;
  xSemaphoreGive(qMutex);
  Serial.printf("@COMMIT,%s,%s,%s\n",ok?"OK":"FAIL",id.c_str(),target.c_str());
}
static void recoverySdQuarantine(const String& arg) {
  // Deliberately NO physical erase. User has local PC backup; still preserve
  // SD original in quarantine for rollback. Refuse if RAM queue active.
  int a=arg.indexOf(' '),b=arg.indexOf(' ',a+1),c=arg.indexOf(' ',b+1);
  if(a<0||b<0||c<0){Serial.println("@QUARERR,ARGS");return;}
  String path=arg.substring(0,a),id=arg.substring(a+1,b),sz=arg.substring(b+1,c),crcText=arg.substring(c+1);
  char* e=nullptr;unsigned long size=strtoul(sz.c_str(),&e,10);
  if(!recoverySafePath(path)||!path.startsWith("/smu/custody/")||!recoveryIdValid(id)||!sz.length()||*e||crcText.length()!=8){Serial.println("@QUARERR,ARGS");return;}
  for(unsigned i=0;i<crcText.length();i++)if(!isxdigit((unsigned char)crcText[i])){Serial.println("@QUARERR,CRC_ARG");return;}
  if(qPending()!=0){Serial.println("@QUARERR,QUEUE_NOT_EMPTY");return;}
  if(xSemaphoreTake(qMutex,pdMS_TO_TICKS(2000))!=pdTRUE){Serial.println("@QUARERR,BUSY");return;}
  File f=SD.open(path,FILE_READ);bool ok=f&&!f.isDirectory()&&f.size()==size;
  uint32_t actual=ok?recoveryCrc32File(f):0;
  if(f)f.close();
  String dest=String("/smu/quarantine/")+id+".hold";
  if(ok&&actual==strtoul(crcText.c_str(),nullptr,16)&&!SD.exists(dest))ok=SD.rename(path,dest);
  else ok=false;
  xSemaphoreGive(qMutex);
  Serial.printf("@QUAR,%s,%s\n",ok?"OK":"FAIL",dest.c_str());
}

// =============================================================================
// 22a) STORAGE FULL FORMAT — Serial console (2026-10-26)
//   Protiti command alada. "YES" chhara shudhu warning; kichu muche na.
//   FORMAT_FRAM YES : STM32 FRAM (32 KB) zero + format guard; STM32 nije reset
//   FORMAT_SD   YES : microSD-te notun FAT (f_mkfs); tarpor ESP32 restart
//   FORMAT_NVS  YES : ESP32 NVS partition puro erase; tarpor ESP32 restart
// =============================================================================
static bool formatConfirmed(const char* cmd, const String& arg, const char* what) {
  String a = arg;
  a.trim();
  a.toUpperCase();
  if (a == "YES") return true;
  Serial.printf("[%s] WARNING: %s\n", cmd, what);
  Serial.printf("[%s] Data ferot pawa jabe na. Nishchit hole likhun:  %s YES\n", cmd, cmd);
  return false;
}

// Format cholakalin background task SD remount / seed / refill / NVS write korbe na.
// Format-er por ESP32 restart hoy, tai resume dorkar nei.
static void formatPauseBackgroundTask() {
  if (!backgroundTaskHandle) return;
  esp_task_wdt_delete(backgroundTaskHandle);     // suspended task-e TWDT panic na hoy
  vTaskSuspend(backgroundTaskHandle);
}

static void consoleFormatFram(const String& arg) {
  if (!formatConfirmed("FORMAT_FRAM", arg,
        "STM32 FRAM (32 KB) puro zero hobe: DB-te na jawa outbox event, counter, seq, session, "
        "operator/location context sob muche jabe. STM32 nije reset hobe.")) return;
  if (!stmAlive() || !stm.seen || !stm.uid[0]) {
    Serial.println("[FORMAT_FRAM] FAIL: STM32 link nai (BOOT/HB pawa jay ni). Kichu kora hoy ni.");
    return;
  }
  if (stm.outbox)
    Serial.printf("[FORMAT_FRAM] NOTE: STM32 outbox-e %lu ta event ache - egulo muche jabe.\n",
                  (unsigned long)stm.outbox);
  String body = String("FFMT,") + stm.uid;       // STM32 nijer UID mile gele tobei format kore
  Serial.printf("[FORMAT_FRAM] STM32 uid=%s -> format request pathano hocche...\n", stm.uid);
  int r = stmCommand(body.c_str());
  if (r == 1) {
    Serial.println("[FORMAT_FRAM] STM32 accepted. ~10 s format cholbe (eta somoy STM LINK LOST dekhabe), tarpor STM32 reset.");
    Serial.println("[FORMAT_FRAM] Sesh hole dekhun: [STM-DEBUG] [FRAM FORMAT] DONE ... ebong [STM32 BOOT] ... FRAM=1");
  } else if (r == 2) {
    Serial.println("[FORMAT_FRAM] STM32 refused (upore [LINK] STM32 NAK reason: UID_MISMATCH / NO_FRAM). Kichu muche ni.");
  } else {
    Serial.println("[FORMAT_FRAM] STM32 reply nai. STM32-e notun firmware (FFMT command soho) upload kora ache kina check korun.");
  }
}

static void consoleFormatSd(const String& arg) {
#if SD_ENABLED
  if (!formatConfirmed("FORMAT_SD", arg,
        "microSD card-er SOB file (/smu/log, /smu/custody .evt/.ok, quarantine, recovery, /smuq) "
        "muche notun FAT filesystem toiri hobe. Tarpor ESP32 restart.")) return;
  if (xSemaphoreTake(qMutex, pdMS_TO_TICKS(10000)) != pdTRUE) {
    Serial.println("[FORMAT_SD] FAIL: SD busy (qMutex). Kichu muche ni, abar chesta korun.");
    return;
  }
  formatPauseBackgroundTask();
  custodyCloseScan();                            // khola directory handle bondho
  sdOk = false;                                  // onno path SD-te likhbe na
  SD.end();                                      // VFS unmount + diskio unregister
  Serial.println("[FORMAT_SD] Formatting... (card size onujayi 10-60 s; power off korben na)");
  Serial.flush();
  bool formatted = false;
  const uint32_t speeds[2] = { 4000000UL, 1000000UL };
  for (int s = 0; s < 2 && !formatted; s++) {
    SPI.begin(PIN_SD_SCK, PIN_SD_MISO, PIN_SD_MOSI, PIN_SD_CS);
    uint8_t pd = sdcard_init(PIN_SD_CS, &SPI, (int)speeds[s]);
    if (pd == 0xFF) {
      Serial.printf("[FORMAT_SD] sdcard_init fail @%lu Hz\n", (unsigned long)speeds[s]);
      continue;
    }
    char drv[3] = { (char)('0' + pd), ':', 0 };
    const size_t workLen = 16384;                // boro buffer = druto FAT clear
    void* work = malloc(workLen);
    if (!work) {
      sdcard_uninit(pd);
      Serial.println("[FORMAT_SD] FAIL: work buffer malloc");
      break;
    }
    const uint32_t t0 = millis();
#if ESP_IDF_VERSION < ESP_IDF_VERSION_VAL(5, 0, 0)
    FRESULT res = f_mkfs(drv, FM_ANY, 0, work, workLen);
#else
    const MKFS_PARM opt = { (BYTE)FM_ANY, 0, 0, 0, 0 };
    FRESULT res = f_mkfs(drv, &opt, work, workLen);
#endif
    free(work);
    sdcard_uninit(pd);
    Serial.printf("[FORMAT_SD] f_mkfs result=%d (0=OK) @%lu Hz, %lu ms\n",
                  (int)res, (unsigned long)speeds[s], (unsigned long)(millis() - t0));
    formatted = (res == FR_OK);
  }
  if (formatted) {
    bool mounted = sdInit();                     // notun FAT mount + /smu folder toiri (qMutex held)
    sdOk = mounted;
    Serial.println(mounted ? "[FORMAT_SD] DONE: notun FAT mount PASS, /smu folder toiri."
                           : "[FORMAT_SD] Format OK kintu remount FAIL - card/wiring check korun.");
  } else {
    Serial.println("[FORMAT_SD] FAIL: format hoy ni. Card PC-te format korun ba card badlan.");
  }
  Serial.println("[FORMAT_SD] ESP32 restart (RAM queue/cache clean). STM32 FRAM-er event abar ashbe.");
  Serial.flush();
  delay(300);
  ESP.restart();
#else
  (void)arg;
  Serial.println("[FORMAT_SD] SD_ENABLED=0: SD nei");
#endif
}

static void consoleFormatNvs(const String& arg) {
  if (!formatConfirmed("FORMAT_NVS", arg,
        "ESP32 NVS puro erase hobe: SET kora WiFi/MQTT/machineId/timeout, bound profile (bprof), "
        "DB proof journal (smudbproof), purono smu100 key. Tarpor ESP32 restart; legacy default "
        "+ prothom STM32 profile auto-bind abar cholbe.")) return;
  Serial.println("[FORMAT_NVS] Background task, MQTT, WiFi bondho kora hocche...");
  formatPauseBackgroundTask();
  if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(2000)) == pdTRUE) {
    mqttClient.disconnect();
    xSemaphoreGive(mqttMutex);
  }
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  if (xSemaphoreTake(dbProofMutex, pdMS_TO_TICKS(2000)) == pdTRUE) {
    dbProofReady = false;                        // linkTask ar NVS proof porbe/likhbe na
    xSemaphoreGive(dbProofMutex);
  } else {
    dbProofReady = false;
  }
  cfgPrefs.end();
  prefs.end();
  dbProofPrefs.end();
  esp_err_t e1 = nvs_flash_erase();
  esp_err_t e2 = nvs_flash_init();
  Serial.printf("[FORMAT_NVS] erase=%s init=%s\n", esp_err_to_name(e1), esp_err_to_name(e2));
  Serial.println(e1 == ESP_OK ? "[FORMAT_NVS] DONE. ESP32 restart..." : "[FORMAT_NVS] FAIL. ESP32 restart...");
  Serial.flush();
  delay(300);
  ESP.restart();
}

// =============================================================================
// 22) SETUP / LOOP
// =============================================================================
void setup() {
  Serial.begin(115200);
  delay(300);
  loopTaskHandler = xTaskGetCurrentTaskHandle();
  printBootDiagnostics();
  Serial.println("[RECLAIM POLICY] DB_COMMIT_ONLY (200 DB_COMMIT_ACK ba 409 duplicate); SD receipt optional");
  setDebugCheckpoint("SETUP_BEGIN");

  uint64_t chipid = ESP.getEfuseMac();
  char macBuf[13];
  snprintf(macBuf, sizeof(macBuf), "%04X%08lX", (unsigned)(uint16_t)(chipid >> 32), (unsigned long)(uint32_t)chipid);
  macAddressStr = String(macBuf);

  mqttMutex = xSemaphoreCreateMutex();
  qMutex = xSemaphoreCreateMutex();
  qProcMutex = xSemaphoreCreateMutex();
  dbProofMutex = xSemaphoreCreateMutex();
  sessionMutex = xSemaphoreCreateMutex();
  linkTxMutex = xSemaphoreCreateMutex();
  cmdMutex = xSemaphoreCreateMutex();
  nextCmdId = esp_random() & 0x7FFFFFFFUL;   // ESP reboot-er por id STM32-er last id-er sathe na mile
  if (!mqttMutex || !qMutex || !qProcMutex || !dbProofMutex || !sessionMutex || !linkTxMutex || !cmdMutex) {
    Serial.println("[FATAL] Failed to create FreeRTOS mutex.");
    while (true) delay(1000);
  }

  Wire.begin(PIN_OLED_SDA, PIN_OLED_SCL);
  display.begin(i2c_Address, true);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(0, 0);
  display.println("SMU-100 " FW_REV);
  display.println("Waiting STM32...");
  display.display();

  cfgPrefs.begin("smucfg", false);
  loadNetCfg();
  prefs.begin("smu100", false);          // F2 upgrade cleanup only
  dbProofReady = dbProofPrefs.begin("smudbproof",false);
  if (!dbProofReady) Serial.println("[DB PROOF] NVS unavailable; SD receipt gap path used after DB commit");
  else dbProofLoad();

  StmLink.setRxBufferSize(2048);
  StmLink.setTxBufferSize(1024);
  StmLink.begin(LINK_BAUD, SERIAL_8N1, PIN_STM_RX, PIN_STM_TX);
  RfidSerial.begin(9600, SERIAL_8N1, PIN_RFID_RX, -1);

  setupTaskWatchdog();
  espPendLoad();                        // F2 upgrade: ager NVS ESP event DB-te na gele queue (pore slot clear)
  upgradeCleanupNvs();                  // F3: session data STM32 FRAM-e — ager NVS session key muche
  // linkTask AGE: SD log tail seed lomba holeo EHB cholte thake (STM32 ESP-reset korbe na);
  // SD init cholakalin EV -> qMutex timeout -> NAK,BUSY (STM32 3 s por abar pathay).
  evQueue = xQueueCreate(EVQ_DEPTH, sizeof(EvFrame));   // EVTASK: linkTask-er AGE
  if (!evQueue) Serial.println("[EVTASK] queue create FAILED -> EV linkTask-ei handle hobe (purono path)");
  xTaskCreatePinnedToCore(linkTask, "LinkTask", 12288, NULL, 1, &linkTaskHandle, 1);
  if (evQueue) xTaskCreatePinnedToCore(evTask, "EvTask", 12288, NULL, 1, &evTaskHandle, 1);   // RESET-DEBUG: 8 KB -> 12 KB
  // LOG-FIX 2026-11-02b: priority 2 -> 1. Log-e TASK_WATCHDOG "BackgroundTask did not reset, CPU 1: LinkTask":
  // prio-2 LinkTask EV replay-er SD kaj-e core 1 dhore rakhto, prio-1 Background/loop/diag task CPU pet na.
  // Ekhon same priority -> FreeRTOS time-slice (1 ms) e sobai cholbe.

#if SD_ENABLED
  xSemaphoreTake(qMutex, portMAX_DELAY);
  sdOk = sdInit();
  xSemaphoreGive(qMutex);
#endif

  // STM32 profile-er jonno opekkha (max 3 s). Bound profile thakle WiFi sathe sathe.
  unsigned long w0 = millis();
  while (!stm.seen && millis() - w0 < 3000) delay(20);
  resolveIdentity();
  evaluateHold();
  serviceBindRequest();                 // auto-bind (backgroundTask ekhono shuru hoy ni)

  mqttClient.setServer(MQTT_BROKER_HOST, MQTT_BROKER_PORT);
  mqttClient.setCallback(mqttCallback);
  bool mqttBufferOk = mqttClient.setBufferSize(2048);
  mqttClient.setKeepAlive(30);
  mqttClient.setSocketTimeout(MQTT_PROTOCOL_TIMEOUT_SEC);
  Serial.printf("[MQTT CONFIG] buffer2048=%s, broker=%s:%u\n", mqttBufferOk ? "OK" : "FAILED", MQTT_BROKER_HOST, MQTT_BROKER_PORT);

  WiFi.onEvent([](WiFiEvent_t event, WiFiEventInfo_t info) {
    if (event == ARDUINO_EVENT_WIFI_STA_DISCONNECTED) {
      wifiLastDisconnectReason = (uint8_t)info.wifi_sta_disconnected.reason;
      wifiDisconnectEventCount++;
    }
  }, ARDUINO_EVENT_WIFI_STA_DISCONNECTED);
  Serial.println("[BENCH-BUILD] ESP_DB_ACK_RECEIPT_SPLIT_2026_10_19; FROZEN_FSM_UNCHANGED");
  Serial.println("[BENCH-BUILD] SD_LOG_DECOUPLE_2026_10_25 (log append fail != card offline)");
  Serial.println("[BENCH-BUILD] SD_BAD_FILE_GUARD_2026_10_26 (nosto file skip + quarantine)");
  Serial.println("[BENCH-BUILD] STORAGE_FORMAT_CMDS_2026_10_26 (FORMAT_FRAM / FORMAT_SD / FORMAT_NVS)");
  Serial.println("[BENCH-BUILD] SD_INDEPENDENT_DB_2026_10_27 (409=committed, SD gap retire, WDT-safe MQTT)");
  Serial.println("[BENCH-BUILD] PAYLOAD_CONFLICT_QUARANTINE_2026_10_27b (SD .evt mismatch -> rename, FRAM authority)");
  Serial.printf("[BENCH-BUILD] tProdPost=%lu ms, dbProofs=%d/%d, sdOk=%d\n",
                (unsigned long)cfg.tProdPost, dbProofCount(), DB_PROOF_SLOTS, sdOk ? 1 : 0);
  connectWiFi(true);
  if (WiFi.status() == WL_CONNECTED) {
    stmBeep(150, 0, 1);
    if (xSemaphoreTake(mqttMutex, pdMS_TO_TICKS(1500)) == pdTRUE) {
      ensureMqttConnectedUnlocked();
      xSemaphoreGive(mqttMutex);
    }
  } else {
    Serial.println("[WiFi] Fast boot connection failed. Background task will keep trying.");
  }

  updateOledDisplay();

  BaseType_t bgCreated = xTaskCreatePinnedToCore(backgroundTask, "BackgroundTask", 16384, NULL, 1, &backgroundTaskHandle, 1);
  BaseType_t diagCreated = xTaskCreatePinnedToCore(diagnosticTask, "DiagnosticTask", 6144, NULL, 1, &diagnosticTaskHandle, 1);   // RESET-DEBUG: 4 KB -> 6 KB
  Serial.printf("[TASK CREATE] Link=OK Background=%s Diagnostic=%s\n",
                bgCreated == pdPASS ? "OK" : "FAILED", diagCreated == pdPASS ? "OK" : "FAILED");
  setDebugCheckpoint("SETUP_COMPLETE");
  Serial.println("--- SETUP COMPLETE --- (type HELP on Serial for provisioning)");
}

void loop() {
  readRfid();
  serviceConsole();

  static unsigned long lastOled = 0;
  if (needOledUpdate || millis() - lastOled > 1000) {
    needOledUpdate = false;
    lastOled = millis();
    updateOledDisplay();
  }
  vTaskDelay(10 / portTICK_PERIOD_MS);
}
