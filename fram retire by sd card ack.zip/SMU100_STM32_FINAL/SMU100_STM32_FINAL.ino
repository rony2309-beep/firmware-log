/*
 * =============================================================================
 *  SMU-100 Rev-T1  —  STM32 FINAL FIRMWARE   (Blue Pill STM32F103C8T6)
 *  FW_REV "2026.10.14-F3"   UART PROTOCOL v4
 * =============================================================================
 *  STM32 responsibility (PDF Sheet-02):
 *    real-time machine input sensing, ALL machine-specific production
 *    decisions, encoder counting, cycle time, production/alter counters,
 *    operator buttons, maintenance/Andon state, 4 Andon outputs + buzzer,
 *    FRAM persistence, DS3231 RTC, UART event generation, IWDG,
 *    ESP32 heartbeat monitoring + reset.
 *  F3: SESSION DATA OWNER = STM32 FRAM. Operator login, operator/location/style/
 *    process name, SMV/divisor, maintenance + technician, current session id,
 *    session table, card-punch recovery flag, ESP-r login/maintenance event —
 *    sob STM32 FRAM-e. ESP32 NVS-e shudhu WiFi/MQTT provisioning thake; ESP32
 *    baki sob STM32 theke (CTX / EV frame) RAM-e pay.
 *  F3: OPERATOR LOGIN CHHARA COUNT (COUNT_WITHOUT_OPERATOR=1): production, alter,
 *    reason event "UNKNOWN" (unassigned) session-e FRAM-e jay, SD-te log hoy,
 *    DB-te jay na (HELD). Operator login success hole sob unassigned session
 *    oi operator-er session-e map (alias) hoy -> event gulo operator-er name-e DB-te
 *    jay. Daily reset (03:00)-e tokhono unassigned thakle "UNKNOWN" name-e DB-te jay.
 *
 *  BTN-ISR (2026.10.24): PHANTOM ALTER FIX
 *    Ager buttonsUpdate() shudhu loop-e sample nito. Software I2C FRAM write-e loop
 *    kayek sho ms block hole duto noise spike-ke "20 ms stable LOW" dhore phantom
 *    ALTER hoto (buzzer/Andon switching noise -> self-feeding loop).
 *    Ekhon: TIM3 1 ms ISR-e 5 button sample, BTN_CONFIRM_MS (40 ms) TANA same level
 *    lagbe; ekta-o ulto sample counter reset kore. Loop block holeo sampling chalu.
 *    Diagnostic: btnGlitch[] (confirm-er age bhenge jaoa run) DBG frame-e 5 s por por.
 *
 *  RESET-FIX (2026.11.02): BAR BAR RESTART-er karon + fix + debug
 *    (1) setup()-e PB5 "A6 hypothesis test" 20 ms HIGH pulse chilo. PB5 HIGH = ESP32 EN LOW,
 *        tai STM32 jotobar reboot hoto, ESP32-o SATHE SATHE reboot hoto. Ekhon bondho
 *        (PB5_BOOT_PULSE_TEST 0). ESP watchdog (30 s EHB nai) reset age-r motoi ache.
 *    (2) FRAM software-I2C scan (96 B record ~15 ms) loop-e IWatchdog.reload() shudhu
 *        "slot index % 8/16 == 0" ar valid/active record-e hoto; legacy-mode ACK scan-e
 *        kokhonoi hoto na. Outbox (pending event) beshi hole (~130+) ekta scan 2 s IWDG par
 *        kore STM32 reset -> reboot-er por ESP abar ACK pathay -> abar scan -> abar reset (LOOP).
 *        Ekhon protiti record-er por wdtKick(). ACK scan age 16 B header pore (5x druto).
 *    (3) DEBUG: SDIAG frame (10 s por por + boot/HELLO-te) -> ESP32 Serial-e "[STM-DIAG]":
 *        reset karon (IWDG/POR/PIN/SFT), ager run-e kon loop stage-e chilo (IWDG hole oi
 *        stage-i doshi), slowest stage + ms, HardFault PC/LR/CFSR, stack/heap free gap
 *        (RAM full kina), outbox count, UART drop/CRC, ESP reset count.
 *        Data STM32 backup register (BKP DR1..DR10)-e thake, IWDG/HardFault reset-e harai na.
 *    (4) RETIRE-SD-OR-DB (2026.11.02d): ESP32 theke CUSTODY (SD .evt CRC verified) ba DBCOMMIT
 *        (DB response) je kono ekta pelei FRAM record retire (ENABLE_SD_CUSTODY_RECLAIM 1).
 *        Outbox choto thake -> replay storm / ACK scan pressure nei. HELD event (STORED) FRAM-e-i thake.
 *
 *  SINGLE AUTHORITATIVE PROFILE: MACHINE_PROFILE shudhu EI file-e set korun.
 *  ESP32 profile BOOT/HB message theke jene ney (ESP32 file-e kono profile nai).
 * =============================================================================
 *  Arduino IDE (STM32duino core "STM32 MCU based boards", tested 2.11.0):
 *    Board           : Generic STM32F1 series
 *    Board part no.  : BluePill F103C8
 *    U(S)ART support : Enabled (generic 'Serial')
 *    USB support     : None (production). "CDC (generic Serial supersede U(S)ART)"
 *                      dile USB debug log pawa jay (measured ~61 KB / 64 KB fits, 93%);
 *                      tokhon ESP link Serial1 (PA9/PA10) e thake.
 *    Upload method   : STM32CubeProgrammer (SWD)  — PA13/PA14 shudhu SWD
 *  Recommended     : sketch folder-e "build_opt.h" file (ei zip-e deya ache):
 *                      -DSERIAL_RX_BUFFER_SIZE=256 -DSERIAL_TX_BUFFER_SIZE=256
 * =============================================================================
 *  UART PROTOCOL v4   (USART1 PA9/PA10 <-> ESP32 GPIO16/17, 115200 8N1)
 *    Frame  :  $BODY*CCCC\n     CCCC = CRC-16/CCITT-FALSE of BODY (4 hex)
 *    Text field (name): percent-encoded (',' '%' '$' '*' '~' control/non-ASCII
 *    -> %XX), empty string = "~".
 *  DATA FLOW (owner rule):
 *    event -> FRAM outbox + SATHE SATHE ESP32-e EV -> ESP32 microSD LOG (kokhono
 *    muchbe na) + Database POST -> DB response -> ESP32 "DELIVERED" -> STM32 FRAM
 *    theke oi event muche fele. 3 s-er moddhe DELIVERED na pele STM32 abar pathay.
 *    STORED / RX shudhu info (FRAM theke muche na).
 *  DAILY RESET: local time 03:00-er por notun production day shuru hole (boot-e ba
 *    running obosthay) counter / operator / session / maintenance / pending sob reset.
 *    DB-te na pouchano event (outbox) muchbe na (DAILY_RESET_CLEAR_OUTBOX=0).
 * -----------------------------------------------------------------------------
 *    STM32 -> ESP32
 *      BOOT,proto,profile,name,uid,resetFlags,framState,rtcState,fwRev,seqEpoch
 *      HB,proto,profile,tp,ta,ac,perf,light,maint,opReady,outbox,epoch,rtcOk,
 *         framState,zRpm,aggPending,seq,uid,smvMilli,divisor,sessionId,
 *         lifeP,lifeA,faults,lastDelivered,iwdg,seqEpoch,prodDay
 *      EV,seq,type,ts,ms,prod,alt,irDur,cyc,reason,tp,ta,ac,sessionId,flags,recEpoch,
 *         op,loc,style,proc,smvMilli,div,mech
 *         seqEpoch = per-boot random 32-bit id (hex). (recEpoch, seq) protiti event-ke
 *         globally unique kore — FRAM nai / state rollback holeo duplicate-detection
 *         bhul kore notun event-ke "already stored" bhabe na.
 *         type: 1 production, 2 alter, 3 reason, 4 overflow aggregate,
 *               5 operator LOGIN marker, 6 MAINTENANCE_ON, 7 PRODUCTION_MODE_ON
 *         (type 4: prod=aggregated production count, alt=aggregated alter
 *          count, irDur=aggregated reason-event count, cyc=first seq)
 *         op..div = event-er session metadata (STM32 FRAM session table theke);
 *         mech = technician (type 6/7), noile "~".
 *         flags: 0x01 irDur not final, 0x02 recovered after power loss,
 *                0x04 HELD (operator unknown: SD log only, DB-te pathabe na),
 *                0x08 REASSIGNED (login chhara toiri, pore login kora operator-er name),
 *                0x10 RELEASED_UNKNOWN (daily reset porjonto login hoy ni -> "UNKNOWN"),
 *                0x20 META_MISSING (session table-e nai: upgrade/evict -> "UNKNOWN")
 *      CTX,sid,opReady,maint,assigned,recPunch,todayLogin,held,prodDay,smvMilli,div,
 *          op,loc,style,proc,tech
 *         current session (ESP32 OLED + server recovery-r jonno). Change hole + 5 s por por.
 *      CMDOK,id,CMD   |   CMDNAK,id,CMD,code
 *    ESP32 -> STM32
 *      HELLO,proto                      ESP boot
 *      EHB,proto,wifi,mqtt,server,pending,hold
 *      RX,seq,ep        (1) ESP32-e pouchheche (info)
 *      STORED,seq,ep    (2) ESP32 microSD LOG-e lekha hoyeche (info, FRAM-e thake)
 *      DELIVERED,seq,ep (3) DATABASE response peyeche -> STM32 FRAM theke muche fele
 *      NAK,seq,code,ep  ESP32 nite parche na (FULL / BUSY / HOLD / PROTO) -> 3 s por abar
 *         ep = record epoch (hex); STM32 head record-er (seq, epoch) duto mille tobei apply
 *      LOGIN,opRfid,opName,loc,style,proc,smvMilli,div,id
 *         operator card: notun assigned session + sob unassigned session alias +
 *         LOGIN event + legacy SESSION (performance/profile reset) + recPunch=1
 *      MAINT,1,tech,techRfid,id  |  MAINT,0,id
 *         technician card (maintenance on + event) | operator card in maintenance (off + event)
 *      LOCATION,locRfid,locName,id
 *         legacy location card: counter 0, operator logout, smv 0, divisor 1, notun session
 *      RESTORE,op,loc,style,proc,smvMilli,div,tp,ta,ac,expectSeq,prodDay,id
 *         server last-machine-state (card punch-er por). prodDay mismatch -> CMDNAK DAY;
 *         outbox/pending/aggregate thakle metadata apply, counter na -> CMDNAK BUSY
 *      RECDONE,id       server-e state nai: recPunch clear
 *      TIME,epochUTC |  BEEP,onMs,offMs,count
 * =============================================================================
 */

#include <Arduino.h>
#include <Wire.h>
#include <IWatchdog.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>          // RESET-FIX: ptrdiff_t (_sbrk heap diag)
#include "SMU100_TYPES.h"

// =============================================================================
// 1) MACHINE PROFILE — SINGLE AUTHORITATIVE CONFIGURATION
// =============================================================================
#define PROFILE_PLAIN_OPTO        1  // PLAIN-MACHINE-OPTOCUPLAR
#define PROFILE_OVERLOCK_IR       2  // OVERLOCK IR AND REASON
#define PROFILE_FLATLOCK_DOUBLE   3  // FLAT_LOCK_DOUBLE_OPTO_BODY_LOCK_IR3S
#define PROFILE_BUTTON_ATTACH     4  // BUTTUN_ATTACH
#define PROFILE_ENCODER_BJ100     5  // ENCODER_BJ100_CYCLETIME
#define PROFILE_BUTTON_HOLE       6  // BUTTON HOLE
#define PROFILE_BARTACK           7  // BARTECH

#ifndef MACHINE_PROFILE
#define MACHINE_PROFILE   PROFILE_FLATLOCK_DOUBLE     // <<<<<<<< UPLOAD-ER AGE SHUDHU EKHANE BOLE DIN
#endif

#define PROTO_VER   4
#define FW_REV      "2026.10.24-BTN-ISR"

// =============================================================================
// 2) USER CONFIGURATION
// =============================================================================
#define STM_DEBUG                  1        // USB CDC thakle tobei kaj kore
#define STM_DEBUG_VERBOSE          0
#define USE_CT_SENSOR              0        // PA5 ADC spare (Rev-T1-e core requirement noy)
#define CT_CALIBRATION             30.0
#define NOISE_OFFSET               1.25
#define OVERLOCK_REQUIRE_Z_MOTION  0        // 1 = PDF M1 rule (ENC_Z motion). 0 = legacy.
#define ENC_SRC_Z                  0
#define ENC_SRC_A                  1
#define BJ100_ENCODER_SOURCE       ENC_SRC_Z  // legacy single encoder pin -> Z (PB0) / A (PA6)

// FRAM: hardware config onujayi 0x53 (A0=1,A1=1). DS3231 module-er EEPROM
// 0x50..0x57 er kono ekta address nite pare, tai Fujitsu Device-ID diye verify.
#define FRAM_I2C_ADDR              0x50
#define FRAM_AUTO_SCAN             0        // VERIFIED configured FRAM at 0x50; never FRAM Device-ID probe RTC EEPROM at 0x57
#define RTC_I2C_ADDR               0x68

// PHASE C: 96-byte journal envelope, CRC32, commit-last and digest-bound SD custody ACK.
// IMPORTANT: legacy EventRec payload is kept intact INSIDE 96-byte journal wire schema 0x21.
// SD-only custody does NOT prove MongoDB commit; keep its retirement gate OFF.
#define ESP_WATCHDOG_ENABLE        1
#define ENABLE_SD_CUSTODY_RECLAIM  1  // RETIRE-SD-OR-DB (2026-11-02d): SD .evt CRC-verified CUSTODY ba DBCOMMIT -
                                      // je kono ekta pelei FRAM retire. 0 = shudhu DBCOMMIT (purono niyom).
                                      // HELD (login chhara) event ESP "STORED" dey, CUSTODY na -> FRAM-e-i thake.
// DB-gated retirement: a separate proof-bound UART DBCOMMIT frame is sent ONLY
// following identity-matched backend DB_COMMIT_ACK, or verified persistent DB proof.
// Checkpoint and outbox metadata protection remain unchanged.
#define ENABLE_DB_COMMIT_RECLAIM   1
// Explicit, destructive ONE-TIME provisioning of test FRAM. Restore to 0 after first boot.
// WARNING: 1 WILL ERASE legacy production/configuration data from this FRAM.
#define SMU_V1_ALLOW_DESTRUCTIVE_PROVISION 0
#define ESP_HB_TIMEOUT_MS          30000UL
#define ESP_BOOT_GRACE_MS          60000UL
#define ESP_RESET_BACKOFF_MAX_MS   900000UL  // reset loop protection: max 15 min gap
#define ESP_RESET_PULSE_MS         200UL
#define LINK_BAUD                  115200
#define IWDG_TIMEOUT_US            2000000UL
#define BUTTON_DEBOUNCE_MS         20UL      // (BTN-ISR: ar byabohar hoy na; BTN_CONFIRM_MS dekhun)
#define BTN_CONFIRM_MS             40        // BTN-ISR: 1 ms ISR-e ei koto sample TANA same level lagbe
#define BTN_TIMER_INSTANCE         TIM3      // BTN-ISR: 1 kHz sampling timer (firmware-e PWM/tone nei)
#define BTN_GLITCH_REPORT_MS       5000UL    // BTN-ISR: glitch counter DBG frame interval
#define HB_INTERVAL_MS             1000UL
#define EV_DB_ACK_TIMEOUT_MS       3000UL    // DB response (DELIVERED) 3 s-e na pele abar pathano
#define DAY_RESET_HOUR_LOCAL       3         // production day shuru: local 03:00
#define LOCAL_TZ_OFFSET_SEC        21600L    // Bangladesh UTC+6 (DS3231 UTC rakhe)
#define DAILY_RESET_CLEAR_OUTBOX   0         // 1 = daily reset-e DB-te na pouchano event-o muche (DATA LOSS!)
#define BOOT_SETTLE_MS             300UL     // boot-er por input settle; production sensing bondho
#define TRAIN_GLITCH_US            100UL     // Button attach / Bartack: er cheye chhoto level = noise
#define OVERLOCK_PENDING_MAX_MS    600000UL  // IR 10 min-er beshi active thakle pending event finalize
#define COUNT_WITHOUT_OPERATOR     1         // 1 = login chhara-o production/alter/reason count (UNKNOWN, HELD)
                                             // 0 = legacy: operator login chhara kichu count hoy na
#define REPLAY_INTERVAL_MS         250UL     // login/ESP reboot-er por outbox-er event ESP32-e pathanor gap
#define CTX_PERIOD_MS              5000UL    // CTX frame (session) periodic resend

// RESET-FIX (2026.11.02) switches
#define PB5_BOOT_PULSE_TEST        0         // 1 = purono A6 test: boot-e PB5 HIGH 20 ms (ESP32 reset hoy!). 0 rakhun.
#define STM_RESET_DIAG             1         // SDIAG frame + BKP register stage/reset forensics
                                             // STM_HARDFAULT_CAPTURE switch: SMU100_TYPES.h-e
#define STM_DIAG_FRAME_MS          10000UL   // SDIAG frame interval
#define STM_SLOW_STAGE_MS          500UL     // er beshi ekta loop stage = "slow" count

// =============================================================================
// 3) PROFILE-DERIVED SETTINGS  (legacy values — UNCHANGED)
// =============================================================================
#if MACHINE_PROFILE == PROFILE_PLAIN_OPTO
  #define PROFILE_NAME       "PLAIN_OPTO"
  #define DEFAULT_SMV        0.0
  #define CURRENT_THRESHOLD  5.0
#elif MACHINE_PROFILE == PROFILE_OVERLOCK_IR
  #define PROFILE_NAME       "OVERLOCK_IR"
  #define DEFAULT_SMV        0.6
  #define CURRENT_THRESHOLD  0.0
#elif MACHINE_PROFILE == PROFILE_FLATLOCK_DOUBLE
  #define PROFILE_NAME       "FLATLOCK_DOUBLE"
  #define DEFAULT_SMV        0.6
  #define CURRENT_THRESHOLD  0.0
#elif MACHINE_PROFILE == PROFILE_BUTTON_ATTACH
  #define PROFILE_NAME       "BUTTON_ATTACH"
  #define DEFAULT_SMV        0.6
  #define CURRENT_THRESHOLD  0.0
  #define TRAIN_MIN_MS       8UL
  #define TRAIN_MAX_MS       20UL
#elif MACHINE_PROFILE == PROFILE_ENCODER_BJ100
  #define PROFILE_NAME       "ENCODER_BJ100"
  #define DEFAULT_SMV        0.0
  #define CURRENT_THRESHOLD  0.0
#elif MACHINE_PROFILE == PROFILE_BUTTON_HOLE
  #define PROFILE_NAME       "BUTTON_HOLE"
  #define DEFAULT_SMV        0.6
  #define CURRENT_THRESHOLD  0.0
#elif MACHINE_PROFILE == PROFILE_BARTACK
  #define PROFILE_NAME       "BARTACK"
  #define DEFAULT_SMV        0.6
  #define CURRENT_THRESHOLD  0.0
  #define TRAIN_MIN_MS       100UL
  #define TRAIN_MAX_MS       200UL
#else
  #error "UNSUPPORTED MACHINE_PROFILE (valid: 1..7)"
#endif

// =============================================================================
// 4) SERIAL PORT MAPPING — USART1 PA9/PA10 = ESP32 link
// =============================================================================
#if defined(USBCON) && defined(USBD_USE_CDC)
  #define EspLink        Serial1
  #define DBG_PORT       Serial
  #define DBG_AVAILABLE  1
#else
  #define EspLink        Serial
  #define DBG_AVAILABLE  0
#endif

// Debug goes to ESP32 via the EXISTING CRC-framed UART protocol.
// 12 x 144 bytes boot/event ring: nonblocking, finite RAM use.
// Do not send raw debug text, which the ESP32 frame parser would discard.
#define STM_UART_DEBUG 0 // FLASH64: compile out UART debug text ONLY; BOOT/HB/EV/ACK are unaffected
#define STM_PULSE_TRACE 1 // Profile-3 START/TRIM UART-only diagnostics; no sensing logic changes
#define STM_BTN_TRACE 1   // BTN-ISR: button glitch counter DBG frame (sensing logic-e prabhab nei)
#define STM_DIAG_PERIOD_MS 5000UL
#define DBG_RING_N 10                     // I2CD2: 6 diag line / 5 s + boot line jayga
static char dbgRing[DBG_RING_N][128];
static uint8_t dbgHead = 0, dbgTail = 0;
static uint32_t dbgDropped = 0;
static uint32_t dbgLastSend = 0;
static uint32_t dbgLastProbe = 0;
void stmDebugEnqueue(const char* msg) {
#if STM_UART_DEBUG
  uint8_t next = (uint8_t)((dbgHead + 1) % DBG_RING_N);
  if (next == dbgTail) { dbgDropped++; return; }
  size_t j = 0;
  for (size_t i = 0; msg[i] && j < sizeof(dbgRing[0]) - 1; i++) {
    char c = msg[i];
    if (c == '\n' || c == '\r') continue;
    // DBG is a single comma-separated field; avoid UART frame punctuation.
    if (c == ',' || c == '*' || c == '$') c = ';';
    if ((unsigned char)c < 32 || (unsigned char)c > 126) c = '?';
    dbgRing[dbgHead][j++] = c;
  }
  dbgRing[dbgHead][j] = 0;
  dbgHead = next;
#else
  (void)msg;
#endif
}
void stmDebugPrintf(const char* fmt, ...) {
#if STM_UART_DEBUG
  char line[144];
  va_list ap;
  va_start(ap,fmt);
  vsnprintf(line,sizeof(line),fmt,ap);
  va_end(ap);
  stmDebugEnqueue(line);
#else
  (void)fmt;
#endif
}
#define DBG_BEGIN()       do {} while(0)
#if STM_UART_DEBUG
  #define DBG_PRINT(...)    stmDebugPrintf("%s", __VA_ARGS__)
  #define DBG_PRINTLN(...)  stmDebugPrintf("%s", __VA_ARGS__)
  #define DBG_PRINTF(...)   stmDebugPrintf(__VA_ARGS__)
#else
  // FLASH64: remove diagnostic format strings and varargs at preprocessing time.
  // Do not touch application linkSend()/linkSendf(), event or ACK generation.
  #define DBG_PRINT(...)    do {} while(0)
  #define DBG_PRINTLN(...)  do {} while(0)
  #define DBG_PRINTF(...)   do {} while(0)
#endif

// =============================================================================
// DATA TYPES  (Arduino IDE auto-prototype-er age declare thakte hobe)
// =============================================================================
// Structured types defined in SMU100_TYPES.h, included above.

// =============================================================================
// 5) PIN MAP  (PDF Sheet-02, Rev-T1)
// =============================================================================
#define PIN_BTN_RED       PA0    // Maintenance problem -> legacy REASON_BTN_1
#define PIN_BTN_YELLOW    PA1    // Quality problem     -> legacy REASON_BTN_2
#define PIN_BTN_GREEN     PA2    // Input gap           -> legacy REASON_BTN_3
#define PIN_BTN_BLUE      PA3    // Personal            -> legacy REASON_BTN_4 (triple press)
#define PIN_BTN_BLACK     PA4    // Alter count         -> legacy REJECT_SWITCH
#define PIN_ADC_SPARE     PA5
#define PIN_ENC_A         PA6
#define PIN_ENC_B         PA7
#define PIN_OPT1          PA8    // E3Z/NPN via HC14 (active HIGH)
#define PIN_ENC_Z         PB0
#define PIN_ISO1          PB1    // TLP2361 (active HIGH; idle LOW)
#define PIN_ESP_RESET     PB5    // HIGH = ESP32 EN low. I2CF1: idle = INPUT (Hi-Z), kokhono LOW drive na
                                 // (PB5 LOW korle SDA+SCL duita-i LOW hoye jay — I2CD2 PINMAP proof)
#define PIN_I2C_SCL       PB3    // FRAM-PB3PB4: FRAM software I2C SCL (ager PB6 hardware I2C1)
#define PIN_I2C_SDA       PB4    // FRAM-PB3PB4: FRAM software I2C SDA (ager PB7 hardware I2C1)
                                 // PB3/PB4 = JTAG pin; setup()-e NOJTAG (SWD PA13/PA14 chalu thake)
                                 // PB6/PB7 ekhon kono kaje nei (input, floating)
#define PIN_ISO2          PB10   // TLP2361 (active HIGH; idle LOW)
#define PIN_OPT2          PB11   // spare optical
#define PIN_ANDON_RED     PB12   // high-side, HIGH = ON
#define PIN_ANDON_YELLOW  PB13
#define PIN_ANDON_GREEN   PB14
#define PIN_ANDON_BUZZER  PB15
#define PIN_STATUS_LED    PC13   // active LOW
// PA13/PA14 = SWD (reserved), PB2 = BOOT1 (unused), PA9/PA10 = USART1

#define ISO_ACTIVE_LEVEL  HIGH
#define OPT_ACTIVE_LEVEL  HIGH
#define BTN_ACTIVE_LEVEL  LOW
#define ANDON_ON_LEVEL    HIGH
#define ANDON_OFF_LEVEL   LOW

// legacy code "LOW = active" dhore lekha; notun hardware level ekhane map hoy
static inline int legacyRead(uint32_t pin, int activeLevel) {
  return (digitalRead(pin) == activeLevel) ? LOW : HIGH;
}

#define RELAY_CH1_PIN  0   // RED
#define RELAY_CH2_PIN  1   // YELLOW
#define RELAY_CH3_PIN  2   // GREEN
#define RELAY_CH4_PIN  3   // BUZZER

// Fault bits (HB "faults")
#define FAULT_FRAM_ABSENT        0x0001
#define FAULT_FRAM_WRITE         0x0002
#define FAULT_OUTBOX_FULL        0x0004
#define FAULT_RTC_INVALID        0x0008
#define FAULT_PROTO_MISMATCH     0x0010
#define FAULT_FRAM_UNVERIFIED    0x0020
#define FAULT_STATE_RECOVERY     0x0040
#define FAULT_ESP_RESET_ISSUED   0x0080
#define FAULT_LINK_TX_DROP       0x0100
#define FAULT_RECORD_CORRUPT     0x0200
#define FAULT_MIGRATION_LOSS     0x0400
#define FAULT_SESSION_EVICT      0x0800   // session table full: referenced session overwrite (meta "UNKNOWN")

// Event types / flags
#define EV_PRODUCTION   1
#define EV_ALTER        2
#define EV_REASON       3
#define EV_AGGREGATE    4
#define EV_LOGIN        5
#define EV_MAINT_ON     6
#define EV_PROD_ON      7
#define EV_WORK_START  8       // WORK_START + PENDING_VALIDATION in one immutable event
#define EV_CURRENT_LOOKUP 9   // server lookup observation, NOT proof of historical assignment
#define EVF_DUR_NOT_FINAL  0x01
#define EVF_RECOVERED      0x02
#define EVF_CREATED_UNASSIGNED 0x04   // record flag (FRAM)
#define EVF_PROVISIONAL   0x08   // recorded at creation, never derived from later server state
// EV frame-only flags (send-er somoy session theke hishab)
#define EVX_HELD           0x04
#define EVX_REASSIGNED     0x08
#define EVX_RELEASED       0x10
#define EVX_META_MISSING   0x20
#define EVX_PROVISIONAL    0x40   // transmitted immutable pending-validation status
#define ALIAS_UNKNOWN      0xFFFFFFFFUL

// =============================================================================
// 6) FORWARD DECLARATIONS
// =============================================================================
void linkSend(const char* body);
void queueEvent(uint8_t type, int prodCount, int altCount, unsigned long irActiveDur,
                unsigned long cycTime, const char* reasonCode, uint8_t flags);
void queueProductionData(int prodCount, int altCount, unsigned long irActiveDur,
                         unsigned long cycTime, const char* reasonCode);
void checkAndApplyPerformanceLight();
void triggerBuzzer(int duration);
void saveState();
void profileSetup();
void profileReset();
void profileSense();
void profileFlushPending(const char* why);
bool profileHasPending();
uint32_t rtcNowEpoch();
void sendNow(const EventRec& r);
void checkDailyReset(const char* why);
void sessEnsureCurrent();
bool sessIsAssigned(uint32_t id);
void sessRefAdd(const EventRec& r, int d);
void replayOnPop();
void sendCtx();
void buttonsTimerBegin();
void buttonsGlitchReport();
void sendDiag();

// =============================================================================
// 7) GLOBAL STATE  (legacy variable names preserved)
// =============================================================================
int32_t totalProduction = 0;
int32_t totalAlter = 0;
int32_t actualProduction = 0;
uint32_t lifeProduction = 0;
uint32_t lifeAlter = 0;

bool operatorReady = false;
bool isMaintenanceMode = false;
double activeSmv = DEFAULT_SMV;
int activeDivisor = 1;
uint32_t currentSessionId = 0;
uint32_t eventSeq = 0;
uint32_t lastDeliveredSeq = 0;
uint32_t bootCount = 0;
uint32_t seqEpoch = 0;
uint32_t prodDay = 0;
bool dayUnknownSinceBoot = true;     // boot-er por ekhono valid time paoa jay ni
bool loginSinceBoot = false;         // operator card punch (LOGIN) hoyeche boot-er por
uint16_t faults = 0;

unsigned long lastProductionTime = 0;
unsigned long debounceDelay = 1000;
unsigned long lastSwitchPress = 0;

bool lastBtn1 = HIGH;
bool lastBtn2 = HIGH;
bool lastBtn3 = HIGH;
bool lastBtn4 = HIGH;
int btn4PressCount = 0;
unsigned long btn4FirstPressTime = 0;
const unsigned long BTN4_TIMEOUT = 3000;

bool blinkActive = false;
bool blinkState = false;
int selectedReason = 0;
unsigned long previousBlinkTime = 0;
const unsigned long blinkInterval = 500;

unsigned long productionCycleTimes[5] = {0, 0, 0, 0, 0};
int cycleIndex = 0;
int cycleCount = 0;
unsigned long lastProductionTimestamp = 0;

// Counting gate (machine-specific code-e legacy "operator checked-in" condition).
// F3: COUNT_WITHOUT_OPERATOR=1 -> login chhara-o count; event UNKNOWN session-e HELD thake.
static inline bool opReady() { return operatorReady || (COUNT_WITHOUT_OPERATOR != 0); }

unsigned long stmBootMs = 0;
bool sensingArmed = false;
uint32_t resetFlags = 0;
uint32_t stmUid = 0;

unsigned long lastEspHbMs = 0;
unsigned long lastEspResetMs = 0;
unsigned long espResetPulseStart = 0;
unsigned long espResetBackoffMs = ESP_BOOT_GRACE_MS;
unsigned long espHealthySinceMs = 0;
bool espResetActive = false;
uint32_t espResetCount = 0;
int espProto = 0;
bool espWifi = false, espMqtt = false, espServer = false, espHold = false;
uint32_t espPending = 0;
uint32_t linkCrcErrors = 0;
uint32_t linkTxDrops = 0;

volatile uint32_t zTotal = 0;
volatile unsigned long lastZMs = 0;
volatile uint32_t encoderPulseCount = 0;
volatile bool encoderWindowOpen = false;
uint32_t zRpm = 0;

// =============================================================================
// 7b) RESET-FIX DIAG: IWDG kick helper + loop-stage tracker (BKP registers)
//   BKP DR1..DR10 (backup domain) system reset (IWDG / software / NRST / HardFault)-e
//   muche na; shudhu VBAT chhara power-off hole muche jay (tokhon BKP magic thakbe na
//   = "power cut" chinho). Map:
//     DR1 magic | DR2 current stage | DR3 slowest stage | DR4 slowest ms
//     DR5 HardFault count | DR6/DR7 fault PC lo/hi | DR8 fault LR lo | DR9/DR10 CFSR lo/hi
// =============================================================================
static inline void wdtKick() { if (IWatchdog.isEnabled()) IWatchdog.reload(); }

enum : uint8_t {
  DG_IDLE = 0, DG_LINK_POLL = 1, DG_LINK_TX = 2, DG_DBG_SVC = 3, DG_I2C_PROBE = 4,
  DG_I2C_HEALTH = 5, DG_HOUSEKEEP = 6, DG_OUTBOX = 7, DG_REPLAY = 8, DG_BUTTONS = 9,
  DG_BEEP = 10, DG_SENSE = 11, DG_OP_INPUTS = 12, DG_PERF_LIGHT = 13, DG_OUTPUTS = 14,
  DG_ACK_SCAN = 15, DG_SETUP = 20
};
static uint8_t  dgStage = DG_SETUP;
static uint32_t dgStageT0 = 0;
static uint16_t dgSlowMs = 0;          // ei run-er slowest stage duration
static uint8_t  dgSlowStage = 0;
static uint32_t dgSlowCount = 0;       // STM_SLOW_STAGE_MS-er beshi stage koybar
static uint32_t dgLoopMaxMs = 0;       // ei run-er sobcheye lomba puro loop()
static uint32_t dgLoopT0 = 0;
// boot-e ager run-er BKP snapshot
static bool     dgPrevValid = false;
static uint8_t  dgPrevStage = 0, dgPrevSlowStage = 0;
static uint16_t dgPrevSlowMs = 0, dgHfCount = 0;
static uint32_t dgHfPc = 0, dgHfLr = 0, dgHfCfsr = 0;

#if STM_RESET_DIAG
static inline void diagStage(uint8_t s) {
  uint32_t now = millis();
  uint32_t el = now - dgStageT0;
  if (dgStage != DG_SETUP && el > dgSlowMs) {
    dgSlowMs = (uint16_t)(el > 65535UL ? 65535UL : el);
    dgSlowStage = dgStage;
    BKP->DR3 = dgSlowStage;
    BKP->DR4 = dgSlowMs;
  }
  if (dgStage != DG_SETUP && el >= STM_SLOW_STAGE_MS) dgSlowCount++;
  dgStage = s;
  dgStageT0 = now;
  BKP->DR2 = s;                        // IWDG reset hole boot-e eta-i "doshi stage"
}
static void diagBkpBegin() {
  RCC->APB1ENR |= RCC_APB1ENR_PWREN | RCC_APB1ENR_BKPEN;
  (void)RCC->APB1ENR;
  PWR->CR |= PWR_CR_DBP;               // backup domain write enable
  dgPrevValid = ((BKP->DR1 & 0xFFFFu) == DG_MAGIC);
  if (dgPrevValid) {
    dgPrevStage     = (uint8_t)BKP->DR2;
    dgPrevSlowStage = (uint8_t)BKP->DR3;
    dgPrevSlowMs    = (uint16_t)BKP->DR4;
    dgHfCount       = (uint16_t)BKP->DR5;
    dgHfPc   = (BKP->DR6 & 0xFFFFu) | ((BKP->DR7 & 0xFFFFu) << 16);
    dgHfLr   = (BKP->DR8 & 0xFFFFu) | 0x08000000UL;
    dgHfCfsr = (BKP->DR9 & 0xFFFFu) | ((BKP->DR10 & 0xFFFFu) << 16);
  } else {
    BKP->DR5 = 0; BKP->DR6 = 0; BKP->DR7 = 0; BKP->DR8 = 0; BKP->DR9 = 0; BKP->DR10 = 0;
  }
  BKP->DR1 = DG_MAGIC;
  BKP->DR2 = DG_SETUP; BKP->DR3 = 0; BKP->DR4 = 0;
}
#else
static inline void diagStage(uint8_t s) { (void)s; }
static void diagBkpBegin() {}
#endif

// HardFault capture: SMU100_FAULT.cpp file-e (Arduino auto-prototype extern "C" naked function-e gondogol kore).

// ---- RAM free gap (heap top <-> stack bottom) — "memory full kina" proof ----
// setup()-er sheshe faka RAM 0xA5 diye rang kora hoy; pore jototuku 0xA5 obikrito
// thake setai sorbonimno free gap (heap barle nich theke, stack barle upor theke khay).
extern "C" char _end;                       // linker: .bss sesh = heap shuru
// FLASH-FIX: mallinfo() ~5 KB flash nito (64 KB overflow). _sbrk(0) = heap-er current top (0 byte cost).
extern "C" void* _sbrk(ptrdiff_t incr);
static inline uint32_t diagHeapUsed() { return (uint32_t)((uint8_t*)_sbrk(0) - (uint8_t*)&_end); }
static uint8_t* dgPaintLo = nullptr;
static uint8_t* dgPaintHi = nullptr;
static void diagRamPaint() {
#if STM_RESET_DIAG
  uint8_t* lo = (uint8_t*)_sbrk(0) + 64;              // live heap top-er upor 64 B margin
  uint8_t* hi = (uint8_t*)__get_MSP() - 256;          // current stack-er niche 256 B margin
  if (hi <= lo) return;
  for (uint8_t* p = lo; p < hi; p++) *p = 0xA5;
  dgPaintLo = lo; dgPaintHi = hi;
#endif
}
static uint32_t diagRamFreeGap() {
  if (!dgPaintLo) return 0;
  uint8_t* p = dgPaintLo;
  while (p < dgPaintHi && *p != 0xA5) p++;           // heap growth (nich theke)
  uint8_t* s = p;
  while (p < dgPaintHi && *p == 0xA5) p++;           // obikrito gap
  return (uint32_t)(p - s);
}

// =============================================================================
// 8) CRC + UID
// =============================================================================
uint16_t crc16(const uint8_t* d, size_t n) {
  uint16_t c = 0xFFFF;
  for (size_t i = 0; i < n; i++) {
    c ^= (uint16_t)d[i] << 8;
    for (uint8_t b = 0; b < 8; b++) c = (c & 0x8000) ? (uint16_t)((c << 1) ^ 0x1021) : (uint16_t)(c << 1);
  }
  return c;
}

uint32_t computeUidHash() {
  uint32_t w[3] = { HAL_GetUIDw0(), HAL_GetUIDw1(), HAL_GetUIDw2() };
  uint32_t h = 2166136261UL;
  const uint8_t* p = (const uint8_t*)w;
  for (int i = 0; i < 12; i++) { h ^= p[i]; h *= 16777619UL; }
  return h;
}

// =============================================================================
// 9) ANDON OUTPUT + BUZZER ENGINE  (all profiles)
// =============================================================================
bool andonState[4] = {false, false, false, false};

static inline void relayWrite(int ch, int legacyLevel) {   // legacy: LOW = ON
  if (ch >= 0 && ch < 4) andonState[ch] = (legacyLevel == LOW);
}

BeepReq beepQ[4];
uint8_t beepQHead = 0, beepQLen = 0;
bool beepActive = false, beepOn = false;
unsigned long beepPhaseStart = 0, beepIdleStart = 0;
bool beepGap = false;
BeepReq beepCur;
uint8_t beepLeft = 0;

void beepRequest(uint16_t onMs, uint16_t offMs, uint8_t count) {
  if (count == 0 || onMs == 0 || beepQLen >= 4) return;
  beepQ[(beepQHead + beepQLen) % 4] = { onMs, offMs, count };
  beepQLen++;
}

void beepService() {
  unsigned long now = millis();
  if (!beepActive) {
    if (beepQLen == 0) return;
    if (beepGap) { if (now - beepIdleStart < 80) return; beepGap = false; }
    beepCur = beepQ[beepQHead];
    beepQHead = (beepQHead + 1) % 4;
    beepQLen--;
    beepLeft = beepCur.count;
    beepActive = true;
    beepOn = true;
    beepPhaseStart = now;
    return;
  }
  unsigned long el = now - beepPhaseStart;
  if (beepOn) {
    if (el >= beepCur.onMs) {
      beepOn = false;
      beepPhaseStart = now;
      if (--beepLeft == 0) { beepActive = false; beepGap = true; beepIdleStart = now; }
    }
  } else if (el >= beepCur.offMs) {
    beepOn = true;
    beepPhaseStart = now;
  }
}

void applyOutputs() {
  digitalWrite(PIN_ANDON_RED,    andonState[0] ? ANDON_ON_LEVEL : ANDON_OFF_LEVEL);
  digitalWrite(PIN_ANDON_YELLOW, andonState[1] ? ANDON_ON_LEVEL : ANDON_OFF_LEVEL);
  digitalWrite(PIN_ANDON_GREEN,  andonState[2] ? ANDON_ON_LEVEL : ANDON_OFF_LEVEL);
  bool buz = andonState[3] || (beepActive && beepOn);
  digitalWrite(PIN_ANDON_BUZZER, buz ? ANDON_ON_LEVEL : ANDON_OFF_LEVEL);
}

void triggerBuzzer(int duration) { beepRequest((uint16_t)duration, 0, 1); }

// ---------------- Legacy relay / Andon functions (logic unchanged) ----------
void updateRelays() {
  relayWrite(RELAY_CH1_PIN, HIGH);
  relayWrite(RELAY_CH2_PIN, HIGH);
  relayWrite(RELAY_CH3_PIN, HIGH);
  relayWrite(RELAY_CH4_PIN, HIGH);
  if (!blinkState) return;
  if (selectedReason == 1) {
    relayWrite(RELAY_CH1_PIN, LOW);
    relayWrite(RELAY_CH4_PIN, LOW);
  } else if (selectedReason == 2) {
    relayWrite(RELAY_CH2_PIN, LOW);
    relayWrite(RELAY_CH4_PIN, LOW);
  } else if (selectedReason == 3) {
    relayWrite(RELAY_CH3_PIN, LOW);
    relayWrite(RELAY_CH4_PIN, LOW);
  } else if (selectedReason == 4) {
    // All Relays remain OFF
  }
}

void stopAllRelays() {
  blinkActive = false;
  blinkState = false;
  selectedReason = 0;
  relayWrite(RELAY_CH1_PIN, HIGH);
  relayWrite(RELAY_CH2_PIN, HIGH);
  relayWrite(RELAY_CH3_PIN, HIGH);
  relayWrite(RELAY_CH4_PIN, HIGH);
}

void startReason(int reasonNumber) {
  stopAllRelays();
  selectedReason = reasonNumber;
  blinkActive = true;
  blinkState = true;
  previousBlinkTime = millis();
  updateRelays();
  triggerBuzzer(150);
}

void setIndicatorLight(int relayPin) {
  relayWrite(RELAY_CH1_PIN, HIGH);
  relayWrite(RELAY_CH2_PIN, HIGH);
  relayWrite(RELAY_CH3_PIN, HIGH);
  relayWrite(RELAY_CH4_PIN, HIGH);
  if (relayPin != -1) relayWrite(relayPin, LOW);
}

void checkAndApplyPerformanceLight() {
  if (blinkActive) return;

  if (cycleCount < 5) {
    setIndicatorLight(RELAY_CH1_PIN);
  }

  if (lastProductionTimestamp > 0 && (millis() - lastProductionTimestamp > 60000)) {
    setIndicatorLight(RELAY_CH1_PIN);
    static unsigned long lastIdleDebug = 0;
    if (millis() - lastIdleDebug > 3000) {
      lastIdleDebug = millis();
      DBG_PRINTLN("[STATUS] Machine Idle for > 1 Minute! Forced RED LIGHT ACTIVE.");
    }
    return;
  }

  if (activeSmv <= 0 || cycleCount < 5) return;

  double targetSmvSec = (activeSmv / 1.15) * 30.0;
  unsigned long sumCycleTimeMs = 0;
  for (int i = 0; i < 5; i++) sumCycleTimeMs += productionCycleTimes[i];
  double avgCycleTimeSec = (sumCycleTimeMs / 5.0) / 1000.0;
  if (avgCycleTimeSec <= 0) return;

  double performance = (targetSmvSec / avgCycleTimeSec) * 100.0;
  if (performance >= 90.0) {
    setIndicatorLight(RELAY_CH3_PIN);
  } else if (performance >= 80.0 && performance < 90.0) {
    setIndicatorLight(RELAY_CH2_PIN);
  } else {
    setIndicatorLight(RELAY_CH1_PIN);
  }
}

int currentPerformancePct() {
  if (activeSmv > 0 && cycleCount >= 5) {
    double targetSmvSec = (activeSmv / 1.15) * 30.0;
    unsigned long sumCycleTimeMs = 0;
    for (int i = 0; i < 5; i++) sumCycleTimeMs += productionCycleTimes[i];
    double avgCycleTimeSec = (sumCycleTimeMs / 5.0) / 1000.0;
    if (avgCycleTimeSec > 0) return (int)((targetSmvSec / avgCycleTimeSec) * 100.0);
  }
  return -1;
}

int currentLightCode() {
  if (blinkActive) return 4;
  if (andonState[0]) return 1;
  if (andonState[1]) return 2;
  if (andonState[2]) return 3;
  return 0;
}

// =============================================================================
// 10) CT CURRENT SENSOR (optional, PA5) — EmonLib calcIrms() equivalent
// =============================================================================
double cachedCurrentIrms = 0.0;
unsigned long lastCTReadTime = 0;

#if USE_CT_SENSOR
double ctOffsetI = 2048.0;
double calcIrms(unsigned int samples) {
  double sumI = 0;
  for (unsigned int n = 0; n < samples; n++) {
    int sampleI = analogRead(PIN_ADC_SPARE);
    ctOffsetI = ctOffsetI + ((sampleI - ctOffsetI) / 4096.0);
    double filteredI = sampleI - ctOffsetI;
    sumI += filteredI * filteredI;
  }
  double I_RATIO = CT_CALIBRATION * (3.3 / 4096.0);
  return I_RATIO * sqrt(sumI / samples);
}
#endif

double getFilteredCurrent() {
#if USE_CT_SENSOR
  if (millis() - lastCTReadTime > 1000 || lastCTReadTime == 0) {
    double raw = calcIrms(100);
    double clean = raw - NOISE_OFFSET;
    if (clean < 0.0) clean = 0.0;
    cachedCurrentIrms = clean;
    lastCTReadTime = millis();
  }
#endif
  return cachedCurrentIrms;
}

// =============================================================================
// 11) ENCODER ISR
// =============================================================================
void zISR() {
  zTotal++;
  lastZMs = millis();
#if (MACHINE_PROFILE == PROFILE_ENCODER_BJ100) && (BJ100_ENCODER_SOURCE == ENC_SRC_Z)
  if (encoderWindowOpen) encoderPulseCount++;
#endif
}

#if (MACHINE_PROFILE == PROFILE_ENCODER_BJ100) && (BJ100_ENCODER_SOURCE == ENC_SRC_A)
void encAISR() {
  if (encoderWindowOpen) encoderPulseCount++;
}
#endif

static inline bool zMotionRecent() {
  noInterrupts();
  unsigned long t = lastZMs;
  interrupts();
  return t != 0 && (millis() - t) < 1000;
}

// =============================================================================
// 12) FRAM  (MB85RC256V 32 KB) — detection, state, pending, aggregate, outbox
//   0x0010..0x00F1 legacy interim-build (v1) area — migration only
//   0x0100/0x0150 State A/B | 0x01A0/0x01C0 Outbox hdr A/B
//   0x01E0/0x0230 Pending A/B | 0x0280/0x02C0 Aggregate A/B
//   0x0300/0x0380 Context A/B (F3)
//   0x0000,0x0080   Format guards (128 B, CRC32, commit-last)
//   0x0100..0x03FF Legacy-compatible state/context/pending/aggregate metadata
//   0x0400..0x07FF Configuration reserve (currently unused)
//   0x0800..0x0FFF CRC32 audit checkpoints (16 x 128 B)
//   0x1000..0x6FFF Journal V1 geometry: 256 x 96 B, schema 0x21 legacy adapter
//   0x7000..0x757F Session table (8 x 176 B) | 0x7FF0 test cell
//   Exact 96-byte semantic schema=1 NOT installed; migration is explicit.
// =============================================================================
#define FRAM_STATE_A      0x0100
#define FRAM_STATE_B      0x0150
#define FRAM_OBX_HDR_A    0x01A0
#define FRAM_OBX_HDR_B    0x01C0
#define FRAM_PEND_A       0x01E0
#define FRAM_PEND_B       0x0230
#define FRAM_AGG_A        0x0280
#define FRAM_AGG_B        0x02C0
#define FRAM_CTX_A        0x0300
#define FRAM_CTX_B        0x0380
// Journal V1 GEOMETRY; payload schema 0x21 = LEGACY_COMPAT. Exact 96-byte
// specification schema=1 cannot encode all 9 immutable legacy event types/fields.
#define FRAM_OBX_BASE     0x1000
#define FRAM_SESS_BASE    0x7000
#define FRAM_CP_BASE      0x0800
#define FRAM_CP_END       0x1000
#define FRAM_SUPER_A      0x0000
#define FRAM_SUPER_B      0x0080
#define FRAM_TEST_ADDR    0x7FF0
#define CTX_MAGIC         0x43545835UL   // 'CTX5': adds persistent machineId[32]
#define SESS_MAGIC        0x53455334UL   // 'SES4'
#define OBX_CAP           256
#define RAM_OBX_CAP       32
#define PERSIST_MAGIC     0x534D5532UL   // 'SMU2'
#define PERSIST_VERSION   3
#define OBX_MAGIC         0x4F425832UL   // 'OBX2'
#define PEND_MAGIC        0x50454E44UL   // 'PEND'
#define AGG_MAGIC         0x41474732UL   // 'AGG2'
#define V1_STATE_MAGIC    0x534D5531UL
#define V1_OBX_MAGIC      0x4F425831UL

// compile-time FRAM map checks (no overlap)
static_assert(sizeof(EventRec) == 58, "EventRec size");
static_assert(FRAM_STATE_A + sizeof(PersistState) <= FRAM_STATE_B, "state A/B overlap");
static_assert(FRAM_STATE_B + sizeof(PersistState) <= FRAM_OBX_HDR_A, "state B / obx hdr overlap");
static_assert(FRAM_OBX_HDR_A + sizeof(ObxHdr) <= FRAM_OBX_HDR_B, "obx hdr A/B overlap");
static_assert(FRAM_OBX_HDR_B + sizeof(ObxHdr) <= FRAM_PEND_A, "obx hdr / pending overlap");
static_assert(FRAM_PEND_A + sizeof(PendingSlot) <= FRAM_PEND_B, "pending A/B overlap");
static_assert(FRAM_PEND_B + sizeof(PendingSlot) <= FRAM_AGG_A, "pending / agg overlap");
static_assert(FRAM_AGG_A + sizeof(OverflowAgg) <= FRAM_AGG_B, "agg A/B overlap");
static_assert(FRAM_AGG_B + sizeof(OverflowAgg) <= FRAM_CTX_A, "agg / ctx overlap");
static_assert(FRAM_CTX_A + sizeof(CtxRec) <= FRAM_CTX_B, "ctx A/B overlap");
static_assert(FRAM_CTX_B + sizeof(CtxRec) <= 0x0400, "ctx / config region overlap");
static_assert(sizeof(SessSlot) == 176, "SessSlot size");
static_assert(FRAM_OBX_BASE + (uint32_t)OBX_CAP * 96u == 0x7000u, "96-byte journal geometry mismatch");
static_assert(FRAM_CP_END <= FRAM_OBX_BASE, "checkpoint / journal overlap");
static_assert(FRAM_SESS_BASE + (uint32_t)SESS_SLOTS * sizeof(SessSlot) <= FRAM_TEST_ADDR, "session / test cell overlap");

// framState: 0 absent, 1 ok (Device-ID verified), 2 ok (ID unverified), 3 write fault
uint8_t framAddr = 0;
uint8_t framState = 0;
bool framVerified = false;
uint16_t framProductId = 0;
bool framOk = false;
// Read-only live FRAM health for the UART heartbeat only.
// Does not change framOk, journal writes, recovery or persisted state.
static uint8_t framLiveMisses = 0;
static uint8_t framHeartbeatState() {
  if (!framOk || framLiveMisses >= 3) return 0;
  return framState; // original state semantics (1, 2 or 3)
}

// =============================================================================
// FRAM-PB3PB4: FRAM transport = SOFTWARE I2C (open-drain bit-bang) on PB3/PB4.
// PB6/PB7 hardware I2C1 (Wire) ar byabohar hoy na -> HAL handle lock-up nei.
// Shudhu transport bodlano: FRAM address, memory map, 16-byte chunk, return
// semantics, journal/outbox/state logic HUBOHU same. RTC soft bus PB8/PB9 alada.
// Open-drain: HIGH = release (external 4.7k pull-up to 3.3V REQUIRED), LOW = drive.
// =============================================================================
#define FRAM_SW_DELAY_US           4U
#define FRAM_SW_STRETCH_TIMEOUT_US 2500UL
static bool framSwReady = false;
static uint32_t framSwErrors = 0;          // bus timeout / line-low errors (NACK gona hoy na)
static void framSwInit() {
  digitalWrite(PIN_I2C_SCL, HIGH); digitalWrite(PIN_I2C_SDA, HIGH);   // ODR=1 age (glitch-free)
  pinMode(PIN_I2C_SCL, OUTPUT_OPEN_DRAIN); pinMode(PIN_I2C_SDA, OUTPUT_OPEN_DRAIN);
  digitalWrite(PIN_I2C_SCL, HIGH); digitalWrite(PIN_I2C_SDA, HIGH);
  framSwReady = true;
}
static void framSwRelease() {              // ager Wire.end()-er jaygay: pin Hi-Z
  pinMode(PIN_I2C_SCL, INPUT); pinMode(PIN_I2C_SDA, INPUT);
  framSwReady = false;
}
static inline void fsDly()    { delayMicroseconds(FRAM_SW_DELAY_US); }
static inline void fsSdaLow() { digitalWrite(PIN_I2C_SDA, LOW); }
static inline void fsSdaRel() { digitalWrite(PIN_I2C_SDA, HIGH); }
static inline void fsSclLow() { digitalWrite(PIN_I2C_SCL, LOW); }
static bool fsSclHigh() {
  digitalWrite(PIN_I2C_SCL, HIGH);
  uint32_t t = micros();
  while (!digitalRead(PIN_I2C_SCL)) {
    if ((uint32_t)(micros() - t) > FRAM_SW_STRETCH_TIMEOUT_US) { framSwErrors++; return false; }
  }
  fsDly();
  return true;
}
static bool framSwStart() {                // START ba repeated START
  if (!framSwReady) framSwInit();
  fsSdaRel(); fsDly();
  if (!fsSclHigh()) return false;
  if (!digitalRead(PIN_I2C_SDA)) { framSwErrors++; return false; }
  fsSdaLow(); fsDly();
  fsSclLow(); fsDly();
  return true;
}
static void framSwStop() {
  fsSclLow(); fsDly();
  fsSdaLow(); fsDly();
  if (fsSclHigh()) { fsSdaRel(); fsDly(); } else fsSdaRel();
}
static bool framSwWriteByte(uint8_t v) {
  for (uint8_t b = 0; b < 8; b++) {
    if (v & 0x80) fsSdaRel(); else fsSdaLow();
    fsDly();
    if (!fsSclHigh()) return false;
    fsSclLow();
    v <<= 1;
  }
  fsSdaRel(); fsDly();
  if (!fsSclHigh()) return false;
  bool ack = !digitalRead(PIN_I2C_SDA);
  fsSclLow(); fsDly();
  return ack;
}
static bool framSwReadByte(uint8_t& v, bool ack) {
  v = 0; fsSdaRel();
  for (uint8_t b = 0; b < 8; b++) {
    fsDly();
    if (!fsSclHigh()) return false;
    v = (uint8_t)((v << 1) | (digitalRead(PIN_I2C_SDA) ? 1 : 0));
    fsSclLow();
  }
  if (ack) fsSdaLow(); else fsSdaRel();
  fsDly();
  if (!fsSclHigh()) { fsSdaRel(); return false; }
  fsSclLow(); fsSdaRel(); fsDly();
  return true;
}
// Wire.endTransmission()-er moto code: 0 = ACK, 2 = address NACK, 4 = bus error
static uint8_t framSwAckCode(uint8_t a) {
  if (!framSwStart()) { framSwStop(); return 4; }
  bool ok = framSwWriteByte((uint8_t)(a << 1));
  framSwStop();
  return ok ? 0 : 2;
}
static bool framSwWrite(uint8_t dev, uint16_t mem, const uint8_t* p, size_t n) {
  if (!framSwStart()) { framSwStop(); return false; }
  bool ok = framSwWriteByte((uint8_t)(dev << 1)) &&
            framSwWriteByte((uint8_t)(mem >> 8)) &&
            framSwWriteByte((uint8_t)(mem & 0xFF));
  for (size_t i = 0; ok && i < n; i++) ok = framSwWriteByte(p[i]);
  framSwStop();
  return ok;
}
static bool framSwRead(uint8_t dev, uint16_t mem, uint8_t* p, size_t n) {
  if (!framSwStart()) { framSwStop(); return false; }
  bool ok = framSwWriteByte((uint8_t)(dev << 1)) &&
            framSwWriteByte((uint8_t)(mem >> 8)) &&
            framSwWriteByte((uint8_t)(mem & 0xFF));
  if (ok) ok = framSwStart() && framSwWriteByte((uint8_t)((dev << 1) | 1));
  for (size_t i = 0; ok && i < n; i++) ok = framSwReadByte(p[i], i + 1 < n);
  framSwStop();
  return ok;
}
// MB85RC Device ID: W 0xF8, (dev<<1), Sr, R 0xF9, 3 byte
static bool framSwReadId(uint8_t dev, uint8_t* b) {
  if (!framSwStart()) { framSwStop(); return false; }
  bool ok = framSwWriteByte(0xF8) && framSwWriteByte((uint8_t)(dev << 1));
  if (ok) ok = framSwStart() && framSwWriteByte(0xF9);
  for (uint8_t i = 0; ok && i < 3; i++) ok = framSwReadByte(b[i], i < 2);
  framSwStop();
  return ok;
}

bool framWriteBytes(uint16_t addr, const void* src, size_t len) {
  if (!framOk) return false;
  const uint8_t* p = (const uint8_t*)src;
  while (len) {
    size_t n = len > 16 ? 16 : len;
    if (!framSwWrite(framAddr, addr, p, n)) {
      faults |= FAULT_FRAM_WRITE;
      framState = 3;
      return false;
    }
    addr += n; p += n; len -= n;
  }
  if (framState == 3) {                 // write path works again -> fault cleared
    framState = framVerified ? 1 : 2;
    faults &= ~FAULT_FRAM_WRITE;
  }
  return true;
}

bool framReadBytesAt(uint8_t devAddr, uint16_t addr, void* dst, size_t len) {
  uint8_t* p = (uint8_t*)dst;
  while (len) {
    size_t n = len > 16 ? 16 : len;
    if (!framSwRead(devAddr, addr, p, n)) return false;
    addr += n; p += n; len -= n;
  }
  return true;
}

bool framReadBytes(uint16_t addr, void* dst, size_t len) {
  if (!framOk) return false;
  return framReadBytesAt(framAddr, addr, dst, len);
}

// Readback verification: no metadata generation should advance on an unchecked I2C write.
// It detects ordinary bus/write faults but does not make the whole I2C transaction atomic.
static bool framWriteVerified(uint16_t addr, const void* src, size_t len) {
  if (!framWriteBytes(addr,src,len)) return false;
  uint8_t tmp[16];
  const uint8_t* ptr = (const uint8_t*)src;
  while (len) {
    size_t n = len > sizeof(tmp) ? sizeof(tmp) : len;
    if (!framReadBytes(addr,tmp,n) || memcmp(tmp,ptr,n) != 0) {
      faults |= FAULT_FRAM_WRITE;
      framState = 3;
      return false;
    }
    len -= n; addr += n; ptr += n;
  }
  return true;
}

// Fujitsu MB85RC Device ID (reserved slave 0xF8/0xF9 = 7-bit 0x7C)
bool framReadDeviceId(uint8_t devAddr, uint16_t& manuf, uint16_t& prod) {
  uint8_t id[3];
  if (!framSwReadId(devAddr, id)) return false;
  uint8_t b0 = id[0], b1 = id[1], b2 = id[2];
  manuf = (uint16_t)((b0 << 4) | (b1 >> 4));
  prod = (uint16_t)(((b1 & 0x0F) << 8) | b2);
  return true;
}

// EEPROM write-cycle-e (~5 ms) NACK kore; FRAM sathe sathe read-back dey.
bool framImmediateRwTest(uint8_t devAddr) {
  uint8_t old[4], test[4] = {0xA5, 0x5A, 0xC3, 0x3C}, back[4];
  if (!framReadBytesAt(devAddr, FRAM_TEST_ADDR, old, 4)) return false;
  if (!framSwWrite(devAddr, FRAM_TEST_ADDR, test, 4)) return false;
  bool ok = framReadBytesAt(devAddr, FRAM_TEST_ADDR, back, 4) && memcmp(test, back, 4) == 0;
  framSwWrite(devAddr, FRAM_TEST_ADDR, old, 4);
  return ok;
}

static bool i2cAck(uint8_t a) {            // FRAM bus (software PB3/PB4)
  return framSwAckCode(a) == 0;
}

bool framDetect() {
  uint16_t m = 0, p = 0;
  // 1) configured address
  if (i2cAck(FRAM_I2C_ADDR)) {
    if (framReadDeviceId(FRAM_I2C_ADDR, m, p) && m == 0x00A) {
      if ((p >> 8) >= 5) { framAddr = FRAM_I2C_ADDR; framProductId = p; framState = 1; framVerified = true; return true; }
      DBG_PRINTF("[FRAM] 0x%02X is Fujitsu but too small (prod 0x%03X)\n", FRAM_I2C_ADDR, p);
    }
    // I2C safety: do NOT write to FRAM_TEST_ADDR when identity probing fails.
    // Main must fail closed; diagnosis is read-only until identity is verified.
  }
#if FRAM_AUTO_SCAN
  // 2) Device-ID verified scan only (EEPROM bhul kore nite na pari)
  for (uint8_t a = 0x50; a <= 0x57; a++) {
    if (a == FRAM_I2C_ADDR || !i2cAck(a)) continue;
    if (framReadDeviceId(a, m, p) && m == 0x00A && (p >> 8) >= 5) {
      framAddr = a; framProductId = p; framState = 1; framVerified = true; return true;
    }
  }
#endif
  framState = 0;
  faults |= FAULT_FRAM_ABSENT;
  return false;
}

// ---------------- Critical state ----------------
uint32_t persistGen = 0;

void saveState() {
  if (!framOk) return;
  PersistState s;
  memset(&s, 0, sizeof(s));
  s.magic = PERSIST_MAGIC;
  s.version = PERSIST_VERSION;
  s.size = sizeof(PersistState);
  s.gen = persistGen + 1;
  s.seq = eventSeq;
  s.totalProduction = totalProduction;
  s.totalAlter = totalAlter;
  s.actualProduction = actualProduction;
  s.lifeProduction = lifeProduction;
  s.lifeAlter = lifeAlter;
  s.sessionId = currentSessionId;
  s.lastDeliveredSeq = lastDeliveredSeq;
  s.bootCount = bootCount;
  s.prodDay = prodDay;
  s.activeSmv = (float)activeSmv;
  s.activeDivisor = (int16_t)activeDivisor;
  s.operatorReady = operatorReady ? 1 : 0;
  s.maintenance = isMaintenanceMode ? 1 : 0;
  s.profile = MACHINE_PROFILE;
  s.crc = crc16((const uint8_t*)&s, sizeof(s) - 2);
  if (framWriteVerified((s.gen & 1) ? FRAM_STATE_A : FRAM_STATE_B, &s, sizeof(s))) {
    persistGen = s.gen;
  } else {
    faults |= FAULT_STATE_RECOVERY;
    DBG_PRINTF("[FRAM] PersistState update failed (generation not advanced)\n");
  }
}

static bool stateValid(const PersistState& s) {
  return s.magic == PERSIST_MAGIC && s.version == PERSIST_VERSION && s.size == sizeof(PersistState) &&
         s.crc == crc16((const uint8_t*)&s, sizeof(s) - 2);
}

// return: 1 loaded v2, 2 migrated v1, 0 fresh FRAM, -1 both copies corrupt, -2 I2C read failure
int loadState() {
  if (!framOk) return 0;
  PersistState a, b;
  bool ra = false, rb = false;
  for (int i = 0; i < 3 && !ra; i++) ra = framReadBytes(FRAM_STATE_A, &a, sizeof(a));
  for (int i = 0; i < 3 && !rb; i++) rb = framReadBytes(FRAM_STATE_B, &b, sizeof(b));
  if (!ra || !rb) return -2;            // unreadable: fresh noy — kichu overwrite kora jabe na
  bool va = ra && stateValid(a);
  bool vb = rb && stateValid(b);
  bool magicSeen = (ra && a.magic == PERSIST_MAGIC) || (rb && b.magic == PERSIST_MAGIC);
  if (va || vb) {
    PersistState& s = (va && vb) ? ((a.gen > b.gen) ? a : b) : (va ? a : b);
    persistGen = s.gen;
    eventSeq = s.seq;
    totalProduction = s.totalProduction;
    totalAlter = s.totalAlter;
    actualProduction = s.actualProduction;
    lifeProduction = s.lifeProduction;
    lifeAlter = s.lifeAlter;
    currentSessionId = s.sessionId;
    lastDeliveredSeq = s.lastDeliveredSeq;
    bootCount = s.bootCount;
    prodDay = s.prodDay;
    activeSmv = s.activeSmv;
    activeDivisor = s.activeDivisor;
    operatorReady = s.operatorReady != 0;
    isMaintenanceMode = s.maintenance != 0;
    return 1;
  }
  // v1 (interim build) migration: counters + seq
  PersistStateV1 c, d;
  bool vc = framReadBytes(0x0010, &c, sizeof(c)) && c.magic == V1_STATE_MAGIC && c.crc == crc16((const uint8_t*)&c, sizeof(c) - 2);
  bool vd = framReadBytes(0x0060, &d, sizeof(d)) && d.magic == V1_STATE_MAGIC && d.crc == crc16((const uint8_t*)&d, sizeof(d) - 2);
  if (vc || vd) {
    PersistStateV1& s = (vc && vd) ? ((c.gen > d.gen) ? c : d) : (vc ? c : d);
    eventSeq = s.seq;
    totalProduction = s.totalProduction;
    totalAlter = s.totalAlter;
    actualProduction = s.actualProduction;
    activeSmv = s.activeSmv;
    activeDivisor = s.activeDivisor;
    operatorReady = s.operatorReady != 0;
    isMaintenanceMode = s.maintenance != 0;
    ObxHdrV1 h1, h2;
    bool v1 = framReadBytes(0x00C0, &h1, sizeof(h1)) && h1.magic == V1_OBX_MAGIC && h1.crc == crc16((const uint8_t*)&h1, sizeof(h1) - 2);
    bool v2 = framReadBytes(0x00E0, &h2, sizeof(h2)) && h2.magic == V1_OBX_MAGIC && h2.crc == crc16((const uint8_t*)&h2, sizeof(h2) - 2);
    uint16_t pend = v1 && v2 ? (h1.gen > h2.gen ? h1.count : h2.count) : (v1 ? h1.count : (v2 ? h2.count : 0));
    if (pend > 0) faults |= FAULT_MIGRATION_LOSS;   // v1 outbox migrate hoy na — reported
    return 2;
  }
  return magicSeen ? -1 : 0;
}

// v1 area invalidate (prothom successful v2 save-er por) — purono seq/counter abar load na hoy
void clearV1Area() {
  const uint32_t zero = 0;
  framWriteBytes(0x0010, &zero, 4);
  framWriteBytes(0x0060, &zero, 4);
  framWriteBytes(0x00C0, &zero, 4);
  framWriteBytes(0x00E0, &zero, 4);
}

// ============================================================================
// PHASE C: 96-byte CRC32/commit-last event journal + two-copy format guard.
// Wire schema 0x21 preserves ALL 58 legacy bytes, including types 1..9.
// It is intentionally NOT the separate 96-byte semantic schema=1 in the
// architecture candidate; a converter is needed before changing on-disk schema.
// Journaling guarantees only events whose final marker verifies on real FRAM.
// ============================================================================
#define SMU_EV_BYTES 96u
#define SMU_EV_CRC_OFFSET 90u
#define SMU_EV_COMMIT_OFFSET 94u
#define SMU_EV_VERSION 0x21u
static uint32_t smuCrc32(const uint8_t* p, size_t n) {
  uint32_t v=0xFFFFFFFFUL;
  while (n--) {
    v ^= *p++;
    for (uint8_t k=0;k<8;k++) v=(v>>1)^((v&1u)?0xEDB88320UL:0UL);
  }
  return v ^ 0xFFFFFFFFUL;
}
static void lePut32(uint8_t* p, uint32_t x) {
  for (uint8_t i=0;i<4;i++) p[i]=(uint8_t)(x>>(8*i));
}
static uint32_t leGet32(const uint8_t* p) {
  return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static bool smuFormatReady=false;
static bool smuMetadataRecoveryFault=false;
static bool smuJournalWriteUncertain=false;
static void smuMakeV1Compat(const EventRec& r, uint8_t p[SMU_EV_BYTES]) {
  memset(p,0,SMU_EV_BYTES);
  p[0]='E';p[1]='V';p[2]=SMU_EV_VERSION;p[3]=r.type;
  p[4]=(uint8_t)sizeof(EventRec);
  lePut32(p+8,r.seq);lePut32(p+12,r.epoch);
  memcpy(p+16,&r,sizeof(r));
  lePut32(p+SMU_EV_CRC_OFFSET,smuCrc32(p,SMU_EV_CRC_OFFSET));
  p[94]=0xA5;p[95]=0x5A;
}
static bool smuReadV1Compat(uint16_t address,EventRec& r) {
  uint8_t p[SMU_EV_BYTES];
  if (!framReadBytes(address,p,sizeof(p))) return false;
  if (p[0]!='E'||p[1]!='V'||p[2]!=SMU_EV_VERSION||p[4]!=sizeof(EventRec)||
      p[94]!=0xA5||p[95]!=0x5A||
      leGet32(p+90)!=smuCrc32(p,90)) return false;
  memcpy(&r,p+16,sizeof(r));
  return r.seq!=0 && r.seq==leGet32(p+8) && r.epoch==leGet32(p+12) &&
    r.type==p[3] && r.crc==crc16((const uint8_t*)&r,sizeof(r)-2);
}
static bool smuCommitV1Compat(uint16_t address,const EventRec& r) {
  uint8_t b[SMU_EV_BYTES],chk[SMU_EV_BYTES];
  smuMakeV1Compat(r,b);
  const uint8_t invalid[2]={0,0};
  if (!framWriteVerified(address+94,invalid,2)) return false;
  // Commit tag LAST. A failed intermediate write cannot be a valid record.
  if (!framWriteBytes(address,b,94) || !framReadBytes(address,chk,94) ||
      memcmp(chk,b,94)!=0) return false;
  if (!framWriteVerified(address+94,b+94,2)) return false;
  EventRec back;
  return smuReadV1Compat(address,back) && memcmp(&back,&r,sizeof(r))==0;
}
// Guard lives ONLY at 0x0000 / 0x0080. 128B, CRC then commit marker.
static bool smuGuardValidAt(uint16_t addr) {
  uint8_t b[128];
  if (!framReadBytes(addr,b,sizeof(b))) return false;
  const char sig[8]={'S','M','U','J','N','L','2','1'};
  return memcmp(b,sig,8)==0 && b[8]==1 && leGet32(b+12)==stmUid &&
      leGet32(b+16)==0x1000u && leGet32(b+20)==0x7000u &&
      leGet32(b+24)==SMU_EV_BYTES && b[126]==0xA5 && b[127]==0x5A &&
      leGet32(b+122)==smuCrc32(b,122);
}
static bool smuWriteGuardAt(uint16_t addr) {
  uint8_t b[128];memset(b,0,sizeof(b));
  memcpy(b,"SMUJNL21",8);b[8]=1;
  lePut32(b+12,stmUid);lePut32(b+16,0x1000u);
  lePut32(b+20,0x7000u);lePut32(b+24,SMU_EV_BYTES);
  lePut32(b+122,smuCrc32(b,122));b[126]=0xA5;b[127]=0x5A;
  const uint8_t off[2]={0,0};
  if (!framWriteVerified(addr+126,off,2)) return false;
  if (!framWriteVerified(addr,b,126)) return false;
  return framWriteVerified(addr+126,b+126,2) && smuGuardValidAt(addr);
}
static bool smuExplicitProvision() {
#if SMU_V1_ALLOW_DESTRUCTIVE_PROVISION
  // BENCH ONLY. The user must first back up old contents and opt in in source.
  // Do NOT clear the live FRAM on a mere CRC/metadata failure.
  // Clear only metadata, active session table and all 256 journal commit tags.
  // Existing data outside these areas is irrelevant because no valid marker
  // survives. Format guards are written LAST after all clearing succeeds.
  uint8_t blank[16]={0};
  for (uint32_t a=0;a<0x1000u;a+=sizeof(blank))
    if (!framWriteVerified((uint16_t)a,blank,sizeof(blank))) return false;
  for (uint32_t a=0x7000u;a<0x7580u;a+=sizeof(blank))
    if (!framWriteVerified((uint16_t)a,blank,sizeof(blank))) return false;
  const uint8_t noTag[2]={0,0};
  for (uint16_t i=0;i<256u;i++)
    if (!framWriteVerified((uint16_t)(0x1000u+96u*i+94u),noTag,2)) return false;
  return smuWriteGuardAt(FRAM_SUPER_A) && smuWriteGuardAt(FRAM_SUPER_B);
#else
  return false;
#endif
}
static bool smuValidateOrProvision() {
  if (!framOk) return false;
  bool a=smuGuardValidAt(FRAM_SUPER_A),b=smuGuardValidAt(FRAM_SUPER_B);
  if (a && b) return smuFormatReady=true;
  if (a || b) { faults|=FAULT_STATE_RECOVERY; return smuFormatReady=true; }
  if (smuExplicitProvision()) return smuFormatReady=true;
  DBG_PRINTLN("[FRAM V1] UNRECOGNIZED format. No automatic format; storage locked. For EMPTY BENCH FRAM, explicitly enable provisioning ONCE.");
  faults |= FAULT_STATE_RECOVERY | FAULT_FRAM_WRITE;
  return false;
}
// ---------------- Outbox (FRAM ring + RAM emergency ring) ----------------
EventRec ramObx[RAM_OBX_CAP];
uint16_t ramHead = 0, ramCount = 0;
uint16_t obxHead = 0, obxCount = 0;
uint32_t obxGen = 0, obxCorrupted = 0;
// Legacy state is still the *operational* counter/session checkpoint in Phase C.
// This separately records a CRC32/commit-last audit checkpoint for future V1
// recovery migration. No FRAM retirement is allowed if checkpoint verification fails.
#define SMU_CP_BYTES 128u
static uint32_t smuCpGeneration=0;
static uint32_t smuLastCustodySeq=0;
static uint32_t smuCpLastSequence=0;
static uint32_t smuCpLifeP=0,smuCpLifeA=0;
static int32_t smuCpTotalP=0,smuCpTotalA=0,smuCpActualP=0;
static uint32_t smuCpBootCount=0;
static uint16_t smuCpHead=0;
static bool smuCheckpointCommit(uint32_t retiringThrough) {
  if (!smuFormatReady || !framOk) return false;
  uint8_t b[SMU_CP_BYTES];memset(b,0,sizeof(b));
  memcpy(b,"CP21",4);b[4]=1;b[6]=128;
  uint32_t g=smuCpGeneration+1u;
  lePut32(b+8,g);lePut32(b+12,stmUid);
  lePut32(b+16,eventSeq);
  lePut32(b+20,lifeProduction);
  lePut32(b+24,lifeAlter);
  lePut32(b+28,(uint32_t)totalProduction);
  lePut32(b+32,(uint32_t)totalAlter);
  if (retiringThrough < smuLastCustodySeq) retiringThrough=smuLastCustodySeq;
  lePut32(b+36,retiringThrough);
  lePut32(b+40,obxHead);lePut32(b+44,obxCount);
  lePut32(b+48,bootCount);
  lePut32(b+52,(uint32_t)actualProduction);
  lePut32(b+122,smuCrc32(b,122));b[126]=0xA5;b[127]=0x5A;
  uint16_t slot=(uint16_t)((smuCpHead+1u)%16u);
  uint16_t addr=(uint16_t)(FRAM_CP_BASE+slot*128u);
  uint8_t off[2]={0,0},rd[128];
  if (!framWriteVerified(addr+126,off,2) ||
      !framWriteVerified(addr,b,126) ||
      !framWriteVerified(addr+126,b+126,2) ||
      !framReadBytes(addr,rd,sizeof(rd)) || memcmp(rd,b,sizeof(b))) return false;
  smuCpHead=slot;smuCpGeneration=g;smuLastCustodySeq=retiringThrough;
  smuCpLastSequence=eventSeq;smuCpLifeP=lifeProduction;smuCpLifeA=lifeAlter;
  smuCpTotalP=totalProduction;smuCpTotalA=totalAlter;smuCpActualP=actualProduction;
  smuCpBootCount=bootCount;
  return true;
}
static void smuCheckpointLoad() {
  smuCpGeneration=0;smuCpHead=15;smuLastCustodySeq=0;
  smuCpLastSequence=0;smuCpLifeP=0;smuCpLifeA=0;
  smuCpTotalP=0;smuCpTotalA=0;smuCpActualP=0;smuCpBootCount=0;
  if (!smuFormatReady) return;
  for (uint16_t i=0;i<16;i++) {
    uint8_t b[128];
    if (!framReadBytes((uint16_t)(FRAM_CP_BASE+i*128u),b,sizeof(b))) {
      smuMetadataRecoveryFault=true;return;
    }
    if (memcmp(b,"CP21",4)!=0 || b[4]!=1 || b[6]!=128 ||
        b[126]!=0xA5 || b[127]!=0x5A ||
        leGet32(b+122)!=smuCrc32(b,122) || leGet32(b+12)!=stmUid) continue;
    uint32_t g=leGet32(b+8);
    if (g && (smuCpGeneration==0 || (int32_t)(g-smuCpGeneration)>0)) {
      smuCpGeneration=g;smuCpHead=i;smuLastCustodySeq=leGet32(b+36);
      smuCpLastSequence=leGet32(b+16);smuCpLifeP=leGet32(b+20);
      smuCpLifeA=leGet32(b+24);smuCpTotalP=(int32_t)leGet32(b+28);
      smuCpTotalA=(int32_t)leGet32(b+32);smuCpBootCount=leGet32(b+48);
      smuCpActualP=(int32_t)leGet32(b+52);
    }
  }
}



// Independent, persistent per-slot DB retirement. Reserved FRAM 0x0400..0x04FF.
// Two 128-byte CRC32/commit-last mirrors; no legacy data or journal relocated.
// ACTIVE bit is authoritative after one-time, non-destructive migration.
// A committed PREPARE recovers an interrupted append before its ACTIVE bit is set.
#define NF_META_A 0x0400u
#define NF_META_B 0x0480u
#define NF_META_BYTES 128u
static bool nfMode=false;
static bool nfPrepare=false;
static uint8_t nfActive[32]={0};
// SLOTMAP (2026-11-02e): active slot -> seq RAM map (1 KB). 0 = jana nai. Shudhu FULL-verified read /
// append theke bhora hoy. ACK ashle 256-slot FRAM scan (0.7 s) na kore map dekhe sorasori slot pore;
// sob active slot jana thakle ar map-e na pele = age-i retire -> scan lagbe na (DBCOMMIT after CUSTODY).
static uint32_t nfSlotSeq[OBX_CAP];
static uint8_t linkAckWork = 0;      // ek linkPoll-e koyta FRAM ACK kaj holo (loop block na korar jonno)
static uint32_t nfGen=0, nfIntentSeq=0, nfIntentEpoch=0, nfIntentCRC=0;
static uint16_t nfCursor=0, nfIntentSlot=0;
static inline bool nfHas(uint16_t slot) {
  return slot<OBX_CAP && (nfActive[slot>>3] & (uint8_t)(1u<<(slot&7)))!=0;
}
static inline void nfSet(uint16_t slot,bool value) {
  uint8_t mask=(uint8_t)(1u<<(slot&7));
  if (value) nfActive[slot>>3]|=mask;
  else nfActive[slot>>3]&=(uint8_t)~mask;
}
static uint16_t nfBitCount() {
  uint16_t n=0;
  for (uint8_t i=0;i<32;i++) {
    uint8_t b=nfActive[i];
    while(b) { n+=(b&1u); b>>=1; }
  }
  return n;
}
static bool nfValid(const uint8_t b[NF_META_BYTES]) {
  if (memcmp(b,"NFRET001",8)!=0 || b[68]!=1 || b[126]!=0xA5 || b[127]!=0x5A ||
      leGet32(b+12)!=stmUid || leGet32(b+122)!=smuCrc32(b,122) ||
      leGet32(b+8)==0 || leGet32(b+48)>=OBX_CAP || leGet32(b+52)>OBX_CAP ||
      (b[69]!=0 && b[69]!=1) || leGet32(b+56)>=OBX_CAP) return false;
  uint16_t bits=0;
  for(uint8_t k=0;k<32;k++){uint8_t x=b[16+k];while(x){bits+=(x&1u);x>>=1;}}
  return bits==leGet32(b+52) && (!b[69] || !(b[16+(leGet32(b+56)>>3)] & (1u<<(leGet32(b+56)&7))));
}
static bool nfBlank(const uint8_t b[NF_META_BYTES]) {
  for(uint16_t i=0;i<NF_META_BYTES;i++) if(b[i]!=0 && b[i]!=0xFF) return false;
  return true;
}
static bool nfSave() {
  if(!framOk || !smuFormatReady) return false;
  uint8_t b[NF_META_BYTES]={0}, rd[NF_META_BYTES];
  memcpy(b,"NFRET001",8);
  uint32_t generation=nfGen+1u;
  lePut32(b+8,generation);lePut32(b+12,stmUid);
  memcpy(b+16,nfActive,32);
  lePut32(b+48,nfCursor);lePut32(b+52,nfBitCount());
  lePut32(b+56,nfIntentSlot);lePut32(b+60,nfIntentSeq);
  lePut32(b+64,nfIntentEpoch);b[68]=1;b[69]=nfPrepare?1:0;
  lePut32(b+72,nfIntentCRC);
  lePut32(b+122,smuCrc32(b,122));b[126]=0xA5;b[127]=0x5A;
  const uint16_t addr=(generation&1u)?NF_META_A:NF_META_B;
  uint8_t invalid[2]={0,0};
  if(!framWriteVerified(addr+126,invalid,2) ||
     !framWriteVerified(addr,b,126) ||
     !framWriteVerified(addr+126,b+126,2) ||
     !framReadBytes(addr,rd,NF_META_BYTES) || memcmp(rd,b,NF_META_BYTES)) return false;
  nfGen=generation;
  return true;
}
// Return 1=loaded, 0=brand-new reserved metadata area, -1=uncertain: LOCK.
static int nfLoad() {
  uint8_t a[NF_META_BYTES],b[NF_META_BYTES];
  if(!framReadBytes(NF_META_A,a,sizeof(a)) || !framReadBytes(NF_META_B,b,sizeof(b))) return -1;
  bool va=nfValid(a), vb=nfValid(b);
  if(!va && !vb) return (nfBlank(a)&&nfBlank(b))?0:-1;
  const uint8_t* x=(va&&vb)?(((int32_t)(leGet32(a+8)-leGet32(b+8))>0)?a:b):(va?a:b);
  nfGen=leGet32(x+8);memcpy(nfActive,x+16,32);
  nfCursor=(uint16_t)leGet32(x+48);nfIntentSlot=(uint16_t)leGet32(x+56);
  nfIntentSeq=leGet32(x+60);nfIntentEpoch=leGet32(x+64);nfPrepare=x[69]!=0;
  nfIntentCRC=leGet32(x+72);
  obxCount=nfBitCount();obxHead=nfCursor;nfMode=true;
  return 1;
}
static bool nfActivateFromLegacy() {
  if(nfMode) return true;
  if(smuMetadataRecoveryFault || smuJournalWriteUncertain || !smuFormatReady) return false;
  memset(nfActive,0,sizeof(nfActive));
  uint16_t tail=(uint16_t)((obxHead+OBX_CAP-obxCount)%OBX_CAP);
  for(uint16_t i=0;i<obxCount;i++) nfSet((uint16_t)((tail+i)%OBX_CAP),true);
  nfCursor=obxHead;nfPrepare=false;nfIntentSlot=0;nfIntentSeq=0;nfIntentEpoch=0;nfIntentCRC=0;
  // Install both independent copies BEFORE invalidating stale FIFO headers.
  if(!nfSave() || !nfSave()) {smuMetadataRecoveryFault=true;faults|=FAULT_STATE_RECOVERY;return false;}
  nfMode=true;
  // Make a future all-copy-loss fail closed instead of rebuilding from stale headers.
  uint32_t invalidMagic=0;
  if(!framWriteVerified(FRAM_OBX_HDR_A,&invalidMagic,4) ||
     !framWriteVerified(FRAM_OBX_HDR_B,&invalidMagic,4)) {
    smuMetadataRecoveryFault=true;faults|=FAULT_STATE_RECOVERY;return false;
  }
  DBG_PRINTF("[NF MIGRATE] active=%u cursor=%u; legacy records retained",(unsigned)obxCount,(unsigned)nfCursor);
  return true;
}
static bool nfRecoverIntent() {
  if(!nfMode || !nfPrepare) return true;
  uint8_t raw[SMU_EV_BYTES];
  if(!framReadBytes((uint16_t)(FRAM_OBX_BASE+(uint32_t)nfIntentSlot*SMU_EV_BYTES),raw,sizeof(raw))) {
    smuMetadataRecoveryFault=true;return false;
  }
  EventRec r;
  bool committed=smuReadV1Compat((uint16_t)(FRAM_OBX_BASE+(uint32_t)nfIntentSlot*SMU_EV_BYTES),r);
  // Power can fail immediately after PREPARE, before the old retired slot is
  // overwritten. A valid old, DIFFERENT record is still retired and safe;
  // only the exact intended record becomes ACTIVE after restart.
  committed=committed && r.seq==nfIntentSeq && r.epoch==nfIntentEpoch &&
            smuCrc32((const uint8_t*)&r,sizeof(r))==nfIntentCRC;
  if(committed) nfSet(nfIntentSlot,true);
  nfPrepare=false;nfCursor=(uint16_t)((nfIntentSlot+1u)%OBX_CAP);
  obxCount=nfBitCount();obxHead=nfCursor;
  if(!nfSave()) {smuMetadataRecoveryFault=true;return false;}
  DBG_PRINTF("[NF RECOVER] append slot=%u committed=%u",(unsigned)nfIntentSlot,committed?1u:0u);
  return true;
}
static bool nfAppend(const EventRec& r) {
  if(!nfMode || nfPrepare || obxCount>=OBX_CAP || smuMetadataRecoveryFault || smuJournalWriteUncertain) return false;
  uint16_t slot=OBX_CAP;
  for(uint16_t j=0;j<OBX_CAP;j++) {
    uint16_t candidate=(uint16_t)((nfCursor+j)%OBX_CAP);
    if(!nfHas(candidate)){slot=candidate;break;}
  }
  if(slot==OBX_CAP) return false;
  // Intent is durable BEFORE old, already-retired bytes in this free slot are changed.
  nfPrepare=true;nfIntentSlot=slot;nfIntentSeq=r.seq;nfIntentEpoch=r.epoch;
  nfIntentCRC=smuCrc32((const uint8_t*)&r,sizeof(r));
  if(!nfSave()) {smuJournalWriteUncertain=true;faults|=FAULT_STATE_RECOVERY;return false;}
  if(!smuCommitV1Compat((uint16_t)(FRAM_OBX_BASE+(uint32_t)slot*SMU_EV_BYTES),r)) {
    smuJournalWriteUncertain=true;faults|=FAULT_FRAM_WRITE;return false;
  }
  nfSet(slot,true);nfPrepare=false;nfCursor=(uint16_t)((slot+1u)%OBX_CAP);
  nfSlotSeq[slot]=r.seq;               // SLOTMAP
  obxCount++;obxHead=nfCursor;
  if(!nfSave()) {smuJournalWriteUncertain=true;faults|=FAULT_STATE_RECOVERY;return false;}
  return true;
}
// Independent physical retirement: clear only this proven ACTIVE slot, no FIFO POP.
static bool nfRetire(uint16_t slot,const EventRec& expected) {
  if(!nfMode || nfPrepare || !nfHas(slot) || smuMetadataRecoveryFault || smuJournalWriteUncertain) return false;
  EventRec back;
  if(!smuReadV1Compat((uint16_t)(FRAM_OBX_BASE+(uint32_t)slot*SMU_EV_BYTES),back) ||
     memcmp(&back,&expected,sizeof(back))!=0) return false;
  if(!smuCheckpointCommit(smuLastCustodySeq)) {faults|=FAULT_STATE_RECOVERY;return false;}
  nfSet(slot,false);obxCount--;
  nfSlotSeq[slot]=0;                   // SLOTMAP
  if(!nfSave()) {nfSet(slot,true);obxCount++;smuMetadataRecoveryFault=true;faults|=FAULT_STATE_RECOVERY;return false;}
  sessRefAdd(expected,-1);
  DBG_PRINTF("[NF RETIRED] seq=%lu slot=%u pending=%u",(unsigned long)expected.seq,(unsigned)slot,(unsigned)obxCount);
  return true;
}

uint16_t outboxTotal() { return (uint16_t)(obxCount + ramCount); }

bool obxSaveHdr() {
  if (!framOk) return false;
  ObxHdr h;
  memset(&h, 0, sizeof(h));
  h.magic = OBX_MAGIC;
  h.gen = obxGen + 1;
  h.head = obxHead;
  h.count = obxCount;
  h.corrupted = obxCorrupted;
  h.crc = crc16((const uint8_t*)&h, sizeof(h) - 2);
  if (!framWriteVerified((h.gen & 1) ? FRAM_OBX_HDR_A : FRAM_OBX_HDR_B, &h, sizeof(h))) {
    faults |= FAULT_STATE_RECOVERY;
    return false;
  }
  obxGen = h.gen;
  return true;
}

static bool obxRead(uint16_t idx,EventRec& r);
static inline uint16_t obxAddr(uint16_t idx);
static inline bool recValid(const EventRec& r);
void obxLoadHdr() {
  obxHead = 0; obxCount = 0; obxCorrupted = 0; obxGen = 0;
  if (!framOk) return;
  int nfStatus=nfLoad();
  if(nfStatus==1) return;
  if(nfStatus<0) {
    smuMetadataRecoveryFault=true;faults|=FAULT_STATE_RECOVERY;
    DBG_PRINTLN("[NF RECOVERY] Invalid/unreadable slot ledger; locked, no legacy fallback");
    return;
  }
  ObxHdr a, b;
  bool va = framReadBytes(FRAM_OBX_HDR_A, &a, sizeof(a)) && a.magic == OBX_MAGIC &&
            a.crc == crc16((const uint8_t*)&a, sizeof(a) - 2) && a.head < OBX_CAP && a.count <= OBX_CAP;
  bool vb = framReadBytes(FRAM_OBX_HDR_B, &b, sizeof(b)) && b.magic == OBX_MAGIC &&
            b.crc == crc16((const uint8_t*)&b, sizeof(b) - 2) && b.head < OBX_CAP && b.count <= OBX_CAP;
  if (!va && !vb) {
    // Phase D fail-closed metadata recovery: after destructive test provisioning
    // only ZERO commit tags are permitted in a genuinely empty journal.
    // A corrupt CRC32 record still has a marker and MUST NOT be erased simply
    // because obxRead() rejects it. A partial/malformed tag is also suspicious.
    bool suspicious=false;
    for (uint16_t k=0;k<OBX_CAP;k++) {
      uint8_t tag[2];
      if ((k & 15u) == 0) wdtKick();   // RESET-FIX: runtime FRAM-late attach path-eo ei loop chole
      if (!framReadBytes((uint16_t)(obxAddr(k)+SMU_EV_COMMIT_OFFSET),tag,2)) {
        suspicious=true; break; // I2C error is NOT evidence of an empty journal
      }
      if (tag[0] != 0u || tag[1] != 0u) { suspicious=true; break; }
    }
    if (suspicious) {
      smuMetadataRecoveryFault=true;
      faults|=FAULT_STATE_RECOVERY | FAULT_RECORD_CORRUPT;
      DBG_PRINTLN("[FRAM RECOVERY] A/B outbox metadata invalid; nonempty/uncertain journal. Locked, no auto-initialize.");
      return;
    }
    if (!obxSaveHdr()) {smuMetadataRecoveryFault=true;faults|=FAULT_STATE_RECOVERY;}
    return;
  }
  ObxHdr& h = (va && vb) ? ((a.gen > b.gen) ? a : b) : (va ? a : b);
  obxGen = h.gen; obxHead = h.head; obxCount = h.count; obxCorrupted = h.corrupted;
}

static inline uint16_t obxAddr(uint16_t idx) { return (uint16_t)(FRAM_OBX_BASE + (uint32_t)idx * SMU_EV_BYTES); }
static bool obxRead(uint16_t idx,EventRec& r) {
  return smuReadV1Compat(obxAddr(idx),r);
}


static void smuRecoverCommittedOrphan() {
  if (!smuFormatReady || smuMetadataRecoveryFault || !framOk) return;
  // Power cut after a journal commit but before the outbox-header transaction:
  // the first non-indexed slot may contain a newer immutable committed event.
  for (uint8_t tries=0;tries<3 && obxCount<OBX_CAP;tries++) {
    EventRec r;
    if (!obxRead(obxHead,r) || !recValid(r)) break;
    // Record at the advertised *next* slot is an orphan only when its ID is
    // newer than both the last custodied event and the newest indexed event.
    // Unlike PersistState.eventSeq, this survives a crash after journal commit
    // but before the outbox header was advanced.
    uint32_t floorSeq=smuLastCustodySeq;
    if (obxCount) {
      EventRec newest;
      uint16_t prev=(uint16_t)((obxHead+OBX_CAP-1u)%OBX_CAP);
      if (!obxRead(prev,newest) || !recValid(newest)) {
        smuMetadataRecoveryFault=true;faults|=FAULT_RECORD_CORRUPT;break;
      }
      if (newest.seq>floorSeq) floorSeq=newest.seq;
    }
    if (r.seq<=floorSeq) break;
    const uint16_t oldHead=obxHead,oldCount=obxCount;
    obxHead=(uint16_t)((obxHead+1u)%OBX_CAP);obxCount++;
    if (!obxSaveHdr()) {obxHead=oldHead;obxCount=oldCount;smuMetadataRecoveryFault=true;break;}
    DBG_PRINTF("[FRAM V1] Recovered orphan committed record seq=%lu\n",(unsigned long)r.seq);
  }
}

void sealRec(EventRec& r) {
  r.crc = crc16((const uint8_t*)&r, sizeof(r) - 2);
}

static inline bool recValid(const EventRec& r) {
  return r.seq != 0 && r.crc == crc16((const uint8_t*)&r, sizeof(r) - 2);
}

// Crash-consistent append. A full/failed journal returns a visible fault.
// Phase C never silently aggregates events or claims RAM-only data is durable.
static bool obxFramAppend(const EventRec& r) {
  if (obxCount >= OBX_CAP) return false;
  if(nfMode) return nfAppend(r);
  if (!smuCommitV1Compat(obxAddr(obxHead),r)) {
    smuJournalWriteUncertain=true;
    faults|=FAULT_FRAM_WRITE;
    return false;
  }
  uint16_t oldHead = obxHead, oldCount = obxCount;
  obxHead = (obxHead + 1) % OBX_CAP;
  obxCount++;
  if (!obxSaveHdr()) {
    obxHead = oldHead; obxCount = oldCount;
    // On uncertain metadata write do not claim a durable append or generate
    // an unrelated fallback record. Power-loss recovery needs full V1 journal.
    faults |= FAULT_STATE_RECOVERY;
    smuJournalWriteUncertain=true;
    return false;
  }
  return true;
}

// RAM emergency ring -> FRAM (order thik rekhe) jokhon FRAM abar likhte pare
void obxMigrateRam() {
  while (framOk && ramCount > 0 && obxCount < OBX_CAP) {
    uint16_t tail = (uint16_t)((ramHead + RAM_OBX_CAP - ramCount) % RAM_OBX_CAP);
    if (!obxFramAppend(ramObx[tail])) return;
    ramCount--;
  }
}

bool obxPush(EventRec& r) {
  sealRec(r);
  if (smuJournalWriteUncertain || smuMetadataRecoveryFault) return false;
  if (framOk) {
    obxMigrateRam();
    if (ramCount == 0) {
      if (obxCount >= OBX_CAP) return false;
      if (obxFramAppend(r)) { sessRefAdd(r, +1); return true; }
      // FRAM is present but a write/readback/header operation failed. RAM
      // fallback could duplicate an orphan record; fail closed instead.
      faults |= FAULT_FRAM_WRITE;
      return false;
    }
  }
  if (ramCount < RAM_OBX_CAP && !smuFormatReady) { // volatile diagnostics only, no durable claim
    ramObx[ramHead] = r;
    ramHead = (ramHead + 1) % RAM_OBX_CAP;
    ramCount++;
    sessRefAdd(r, +1);
    return true;
  }
  return false;
}

// Oldest event (FRAM age, tarpor RAM)
bool obxPeek(EventRec& r) {
  if(nfMode) {
    uint32_t best=0xFFFFFFFFUL;bool found=false;
    for(uint16_t i=0;i<OBX_CAP;i++) {
      if(!nfHas(i)) continue;
      wdtKick();                       // RESET-FIX: protiti FRAM record read-er age (ager i%16 hole)
      EventRec x;
      if(!obxRead(i,x) || !recValid(x)) {faults|=FAULT_RECORD_CORRUPT;continue;}
      if(!found || x.seq<best){best=x.seq;r=x;found=true;}
    }
    return found;
  }
  int guard = 32;                                                        // IWDG-safe bound per call
  while (obxCount > 0 && guard-- > 0) {
    wdtKick();                         // RESET-FIX: 32 x 3 retry x ~15 ms = ~1.4 s worst-case
    uint16_t tail = (obxHead + OBX_CAP - obxCount) % OBX_CAP;
    bool valid = false;
    for (int tries = 0; tries < 3 && !valid; tries++) {                  // I2C noise: 3 bar pore
      if (!obxRead(tail, r)) return false;    // I2C read fail: pore abar
      valid = recValid(r);
    }
    if (valid) return true;
    replayOnPop();
    // Do not destructively skip corrupted head; protect forensic evidence.
    // Lossless recovery may require operator intervention or SD reconciliation.
    obxCorrupted++;
    faults |= FAULT_RECORD_CORRUPT;
    return false;
  }
  if (obxCount > 0) return false;                                        // more corrupt records: next call
  if (ramCount > 0) {
    r = ramObx[(ramHead + RAM_OBX_CAP - ramCount) % RAM_OBX_CAP];
    return true;
  }
  return false;
}

// r = obxPeek()-e paoa head record (session reference count komano)
bool obxPop(const EventRec& r) {
  if(nfMode) {
    for(uint16_t i=0;i<OBX_CAP;i++) {
      if(!nfHas(i)) continue;
      wdtKick();                       // RESET-FIX: ager ei loop-e kono reload-i chilo na
      EventRec x;
      if(obxRead(i,x) && recValid(x) && x.seq==r.seq && x.epoch==r.epoch)
        return nfRetire(i,r);
    }
    return false;
  }
  if (obxCount > 0) {
    // SD custody may be transferred only after the derived counter checkpoint
    // is safely persisted. Old event bytes remain until their slot is reused.
    if (!smuCheckpointCommit(r.seq)) {faults|=FAULT_STATE_RECOVERY;return false;}
    obxCount--;
    if (!obxSaveHdr()) {
      obxCount++;
      return false;
    }
    replayOnPop();
    sessRefAdd(r,-1);
    return true;
  }
  if (ramCount > 0) {
    ramCount--;
    sessRefAdd(r,-1);
    return true;
  }
  return false;
}

// Newest stored record (boot reconcile)
bool obxNewest(EventRec& r) {
  if (!framOk) return false;
  if(nfMode) {
    bool found=false;uint32_t highest=0;
    for(uint16_t i=0;i<OBX_CAP;i++) {
      if(!nfHas(i)) continue;
      wdtKick();                       // RESET-FIX
      EventRec x;
      if(!obxRead(i,x) || !recValid(x)) {faults|=FAULT_RECORD_CORRUPT;continue;}
      if(!found || x.seq>highest){highest=x.seq;r=x;found=true;}
    }
    return found;
  }
  uint16_t idx = (uint16_t)((obxHead + OBX_CAP - 1) % OBX_CAP);
  return obxRead(idx, r) && recValid(r);
}

// ---------------- Overflow aggregate (outbox full policy) ----------------
OverflowAgg agg;
uint32_t aggGen = 0;

bool aggActive() { return agg.prod || agg.alt || agg.reasonEv; }

void aggSave() {
  if (!framOk) return;
  agg.magic = AGG_MAGIC;
  agg.gen = ++aggGen;
  agg.crc = crc16((const uint8_t*)&agg, sizeof(agg) - 2);
  framWriteBytes((agg.gen & 1) ? FRAM_AGG_A : FRAM_AGG_B, &agg, sizeof(agg));
}

void aggLoad() {
  memset(&agg, 0, sizeof(agg));
  if (!framOk) return;
  OverflowAgg a, b;
  bool va = framReadBytes(FRAM_AGG_A, &a, sizeof(a)) && a.magic == AGG_MAGIC && a.crc == crc16((const uint8_t*)&a, sizeof(a) - 2);
  bool vb = framReadBytes(FRAM_AGG_B, &b, sizeof(b)) && b.magic == AGG_MAGIC && b.crc == crc16((const uint8_t*)&b, sizeof(b) - 2);
  if (va || vb) {
    agg = (va && vb) ? ((a.gen > b.gen) ? a : b) : (va ? a : b);
    aggGen = agg.gen;
  }
}

void aggAdd(const EventRec& r) {
  if (!aggActive()) { agg.firstSeq = r.seq; agg.sessionId = r.sessionId; }
  if (r.type == EV_PRODUCTION) agg.prod += r.prod ? r.prod : 1;
  else if (r.type == EV_ALTER) agg.alt += r.alt ? r.alt : 1;
  else agg.reasonEv++;
  if (r.seq > agg.lastSeq) {                 // finalized pending (older seq) totals-ke pichone nibe na
    agg.lastSeq = r.seq;
    agg.tp = r.tp; agg.ta = r.ta; agg.ac = r.ac;
  }
  if (r.seq < agg.firstSeq) agg.firstSeq = r.seq;
  faults |= FAULT_OUTBOX_FULL;
  aggSave();
}

// Outbox-e jayga hole aggregate record (type 4) push kore clear
// Aggregate record nijer notun seq pay (unique). prod/alt 16-bit field: 65535-er beshi hole
// kayek ta record-e bhag kore pathano hoy (kichu bad jay na).
void aggTryFlush() {
  if (!aggActive()) return;
  if (framOk && obxCount >= OBX_CAP) return;
  EventRec r;
  memset(&r, 0, sizeof(r));
  uint32_t p = agg.prod > 65535 ? 65535 : agg.prod;
  uint32_t a = agg.alt > 65535 ? 65535 : agg.alt;
  r.seq = eventSeq + 1;
  r.type = EV_AGGREGATE;
  r.ts = rtcNowEpoch();
  r.ms = millis();
  r.prod = (uint16_t)p;
  r.alt = (uint16_t)a;
  r.irDur = agg.reasonEv;
  r.cyc = agg.firstSeq;
  r.tp = agg.tp; r.ta = agg.ta; r.ac = agg.ac;
  r.sessionId = agg.sessionId;
  r.profile = MACHINE_PROFILE;
  r.epoch = seqEpoch;
  r.lifeP = lifeProduction;
  r.lifeA = lifeAlter;
  agg.flushSeq = r.seq; agg.flushP = p; agg.flushA = a; agg.flushR = agg.reasonEv;
  aggSave();                                 // power loss: boot-e jana jabe flush landed kina (double count na)
  if (obxPush(r)) {
    eventSeq = r.seq;
    sendNow(r);
    DBG_PRINTF("[OUTBOX] Aggregate flushed: prod=%lu alt=%lu reasons=%lu\n",
               (unsigned long)p, (unsigned long)a, (unsigned long)agg.reasonEv);
    agg.prod -= p;
    agg.alt -= a;
    agg.reasonEv = 0;
    agg.flushSeq = 0;
    if (!aggActive()) {
      memset(&agg, 0, sizeof(agg));
      faults &= ~FAULT_OUTBOX_FULL;
    } else {
      agg.firstSeq = r.seq;                  // remainder continues
    }
    aggSave();
    saveState();
  } else {
    agg.flushSeq = 0;
    aggSave();
  }
}

// ---------------- Pending slot (overlock) ----------------
PendingSlot pend;
uint32_t pendGen = 0;

void pendSave() {
  if (!framOk) return;
  pend.magic = PEND_MAGIC;
  pend.gen = ++pendGen;
  pend.crc = crc16((const uint8_t*)&pend, sizeof(pend) - 2);
  framWriteBytes((pend.gen & 1) ? FRAM_PEND_A : FRAM_PEND_B, &pend, sizeof(pend));
}

void pendLoad() {
  memset(&pend, 0, sizeof(pend));
  if (!framOk) return;
  PendingSlot a, b;
  bool va = framReadBytes(FRAM_PEND_A, &a, sizeof(a)) && a.magic == PEND_MAGIC && a.crc == crc16((const uint8_t*)&a, sizeof(a) - 2);
  bool vb = framReadBytes(FRAM_PEND_B, &b, sizeof(b)) && b.magic == PEND_MAGIC && b.crc == crc16((const uint8_t*)&b, sizeof(b) - 2);
  if (va || vb) {
    pend = (va && vb) ? ((a.gen > b.gen) ? a : b) : (va ? a : b);
    pendGen = pend.gen;
  }
}

// ---------------- F3: CONTEXT + SESSION TABLE (ager ESP32 NVS data) ----------------
//  ctx  : opRfid / locRfid / techRfid / technician session / session id allocator /
//         login day / card-punch recovery flag / unassigned->operator alias  (A/B, CRC)
//  sess : 8 slot x 176 B (RAM mirror + FRAM). Outbox / pending / aggregate je session
//         refer kore seta overwrite hoy na (reference count). Slot body likhar por bodlay na.
CtxRec ctx;
uint32_t ctxGen = 0;
bool ctxDirty = true;                 // CTX frame ESP32-e pathate hobe
unsigned long lastCtxMs = 0;
SessSlot sess[SESS_SLOTS];
bool sessValid[SESS_SLOTS];
uint16_t sessRef[SESS_SLOTS];

static void strCopy(char* dst, size_t n, const char* src) {
  if (!src) src = "";
  strncpy(dst, src, n - 1);
  dst[n - 1] = 0;
}

void ctxSave() {
  ctxDirty = true;
  if (!framOk) return;
  ctx.magic = CTX_MAGIC;
  ctx.gen = ctxGen + 1;
  ctx.crc = crc16((const uint8_t*)&ctx, sizeof(ctx) - 2);
  if (framWriteVerified((ctx.gen & 1) ? FRAM_CTX_A : FRAM_CTX_B, &ctx, sizeof(ctx))) {
    ctxGen = ctx.gen;
  } else faults |= FAULT_STATE_RECOVERY;
}

bool ctxLoad() {
  memset(&ctx, 0, sizeof(ctx));
  if (!framOk) return false;
  CtxRec a, b;
  bool va = framReadBytes(FRAM_CTX_A, &a, sizeof(a)) && a.magic == CTX_MAGIC && a.crc == crc16((const uint8_t*)&a, sizeof(a) - 2);
  bool vb = framReadBytes(FRAM_CTX_B, &b, sizeof(b)) && b.magic == CTX_MAGIC && b.crc == crc16((const uint8_t*)&b, sizeof(b) - 2);
  if (!va && !vb) return false;
  ctx = (va && vb) ? ((a.gen > b.gen) ? a : b) : (va ? a : b);
  ctxGen = ctx.gen;
  ctx.opRfid[sizeof(ctx.opRfid) - 1] = 0;
  ctx.locRfid[sizeof(ctx.locRfid) - 1] = 0;
  ctx.techRfid[sizeof(ctx.techRfid) - 1] = 0;
  ctx.machineId[sizeof(ctx.machineId) - 1] = 0;
  return true;
}

static inline uint16_t sessAddr(int i) { return (uint16_t)(FRAM_SESS_BASE + (uint32_t)i * sizeof(SessSlot)); }

static void sessTerminate(SessSlot& s) {
  s.op[sizeof(s.op) - 1] = 0; s.loc[sizeof(s.loc) - 1] = 0;
  s.style[sizeof(s.style) - 1] = 0; s.proc[sizeof(s.proc) - 1] = 0;
}

void sessLoadAll() {
  for (int i = 0; i < SESS_SLOTS; i++) {
    sessValid[i] = false;
    sessRef[i] = 0;
    if (!framOk) continue;
    SessSlot& s = sess[i];
    if (framReadBytes(sessAddr(i), &s, sizeof(s)) && s.magic == SESS_MAGIC && s.id != 0 &&
        s.crc == crc16((const uint8_t*)&s, sizeof(s) - 2)) {
      sessTerminate(s);
      sessValid[i] = true;
    }
  }
}

int sessFind(uint32_t id) {
  if (id == 0 || id == ALIAS_UNKNOWN) return -1;
  for (int i = 0; i < SESS_SLOTS; i++) if (sessValid[i] && sess[i].id == id) return i;
  return -1;
}

const SessSlot* sessCur() {
  int i = sessFind(currentSessionId);
  return i >= 0 ? &sess[i] : nullptr;
}

bool sessIsAssigned(uint32_t id) {
  int i = sessFind(id);
  return i >= 0 && sess[i].assigned != 0;
}

static void refStep(uint32_t sid, int d) {
  int i = sessFind(sid);
  if (i < 0) return;
  if (d > 0) sessRef[i]++;
  else if (sessRef[i] > 0) sessRef[i]--;
}

void sessRefAdd(const EventRec& r, int d) {
  refStep(r.sessionId, d);
  if (r.type == EV_MAINT_ON || r.type == EV_PROD_ON) refStep(r.cyc, d);
}

// slot i ekhono kono record / current / pending / aggregate-er kaje lagche?
static bool sessDirectUse(int i) {
  uint32_t id = sess[i].id;
  if (sessRef[i] > 0) return true;
  if (id == currentSessionId || id == ctx.techSid) return true;
  if (pend.active && pend.rec.sessionId == id) return true;
  if (aggActive() && agg.sessionId == id) return true;
  return false;
}

static bool sessInUse(int i) {
  if (!sessValid[i]) return false;
  if (sessDirectUse(i)) return true;
  for (int j = 0; j < SESS_SLOTS; j++)        // unassigned session j -> i (alias target)
    if (j != i && sessValid[j] && sess[j].kind == 0 && !sess[j].assigned && ctx.alias[j] == sess[i].id && sessDirectUse(j)) return true;
  return false;
}

// Notun session slot. Kono record-er refer kora slot overwrite kore na (shob slot busy hole
// shobcheye purono-ta, FAULT_SESSION_EVICT). Power loss: ctx (id allocator) age, slot pore.
uint32_t sessCreate(uint8_t kind, bool assigned, const char* op, const char* loc, const char* style,
                    const char* proc, double smv, int div) {
  int pick = -1;
  for (int i = 0; i < SESS_SLOTS && pick < 0; i++) if (!sessValid[i]) pick = i;
  uint32_t best = 0xFFFFFFFFUL;
  if (pick < 0) {
    for (int i = 0; i < SESS_SLOTS; i++)
      if (!sessInUse(i) && sess[i].id < best) { best = sess[i].id; pick = i; }
  }
  if (pick < 0) {
    for (int i = 0; i < SESS_SLOTS; i++)
      if (sess[i].id != currentSessionId && sess[i].id != ctx.techSid && sess[i].id < best) { best = sess[i].id; pick = i; }
    faults |= FAULT_SESSION_EVICT;
    DBG_PRINTLN("[SESSION] Table full: oldest referenced session overwritten (meta UNKNOWN)");
  }
  if (pick < 0) pick = 0;
  uint32_t id = ctx.nextSid ? ctx.nextSid : 1;
  ctx.nextSid = id + 1;
  if (ctx.nextSid == 0 || ctx.nextSid == ALIAS_UNKNOWN) ctx.nextSid = 1;
  ctx.alias[pick] = 0;
  ctxSave();
  SessSlot& s = sess[pick];
  memset(&s, 0, sizeof(s));
  s.magic = SESS_MAGIC;
  s.id = id;
  s.day = prodDay;
  s.smv = (float)smv;
  s.div = (int16_t)div;
  s.assigned = assigned ? 1 : 0;
  s.kind = kind;
  strCopy(s.op, sizeof(s.op), op);
  strCopy(s.loc, sizeof(s.loc), loc);
  strCopy(s.style, sizeof(s.style), style);
  strCopy(s.proc, sizeof(s.proc), proc);
  s.crc = crc16((const uint8_t*)&s, sizeof(s) - 2);
  sessValid[pick] = true;
  sessRef[pick] = 0;
  if (framOk && !framWriteVerified(sessAddr(pick), &s, sizeof(s))) {
    sessValid[pick] = false;
    faults |= FAULT_STATE_RECOVERY;
    return 0;
  }
  return id;
}

// Event-er session metadata resolve. xf = EVX_* (HELD / REASSIGNED / RELEASED / META_MISSING)
const SessSlot* sessResolve(uint32_t id, uint8_t& xf) {
  xf = 0;
  int i = sessFind(id);
  if (i < 0) { xf = EVX_META_MISSING; return nullptr; }
  if (sess[i].assigned || sess[i].kind != 0) return &sess[i];
  uint32_t a = ctx.alias[i];
  if (a == 0) {
#if COUNT_WITHOUT_OPERATOR
    xf = EVX_HELD;                    // operator ekhono jana nai: login / day-end porjonto DB-te na
#endif
    return &sess[i];
  }
  if (a == ALIAS_UNKNOWN) { xf = EVX_RELEASED; return &sess[i]; }
  int k = sessFind(a);
  if (k < 0) { xf = EVX_META_MISSING; return nullptr; }
  xf = EVX_REASSIGNED;
  return &sess[k];
}

bool recHeld(const EventRec& r) {
  uint8_t xf;
  sessResolve(r.sessionId, xf);
  return (xf & EVX_HELD) != 0;
}

// HELD event count (OLED / CTX)
uint32_t heldCount() {
  uint32_t n = 0;
#if COUNT_WITHOUT_OPERATOR
  for (int i = 0; i < SESS_SLOTS; i++)
    if (sessValid[i] && sess[i].kind == 0 && !sess[i].assigned && ctx.alias[i] == 0) n += sessRef[i];
  if (pend.active && recHeld(pend.rec)) n++;
#endif
  return n;
}

// Deferred operator assignment: ONLY the same line and production day.
// Original EventRec/seq/epoch/CRC are unchanged; ctx.alias is persisted.
uint32_t sessAssignAll(uint32_t toSid, const char* line) {
  uint32_t n = 0;
  for (int i = 0; i < SESS_SLOTS; i++)
    if (sessValid[i] && sess[i].kind == 0 && !sess[i].assigned && ctx.alias[i] == 0 &&
        sess[i].day == prodDay && strcmp(sess[i].loc, line) == 0 && sess[i].id != toSid) {
      ctx.alias[i] = toSid;
      n += sessRef[i];
    }
  ctxSave();
  return n;
}

// With line=null release ALL unknown sessions at daily reset.
// With line!=null release ONLY the old line when its location card changes.
uint32_t sessReleaseAll(const char* line = nullptr) {
  uint32_t n = 0;
  for (int i = 0; i < SESS_SLOTS; i++)
    if (sessValid[i] && sess[i].kind == 0 && !sess[i].assigned && ctx.alias[i] == 0 &&
        (!line || strcmp(sess[i].loc, line) == 0)) {
      ctx.alias[i] = ALIAS_UNKNOWN;
      n += sessRef[i];
    }
  ctxSave();
  return n;
}

// Current session event toirir age valid + operatorReady-r sathe mile ache kina.
// Operator login chhara (ba operator nam jana nai, F2 upgrade) -> UNKNOWN (unassigned) session.
void sessEnsureCurrent() {
  int ci = sessFind(currentSessionId);
  const SessSlot* c = ci >= 0 ? &sess[ci] : nullptr;
  if (operatorReady && (!c || !c->assigned || c->kind != 0)) {   // operator nam jana nai -> abar card punch
    operatorReady = false;
    saveState();
    ctxDirty = true;
  }
  if (c && c->kind == 0 && (c->assigned != 0) == operatorReady && (c->assigned || ctx.alias[ci] == 0)) return;
  currentSessionId = sessCreate(0, false, "UNKNOWN", c ? c->loc : "NONE", c ? c->style : "NONE",
                                c ? c->proc : "NONE", activeSmv, activeDivisor);
  saveState();
  ctxDirty = true;
  DBG_PRINTF("[SESSION] UNKNOWN (login chhara) session %lu\n", (unsigned long)currentSessionId);
}

// Boot: outbox / pending / aggregate theke reference count + id allocator
void sessRebuildRefs() {
  for (int i = 0; i < SESS_SLOTS; i++) sessRef[i] = 0;
  uint32_t maxSid = currentSessionId;
  for (int i = 0; i < SESS_SLOTS; i++) if (sessValid[i] && sess[i].id > maxSid) maxSid = sess[i].id;
  for (uint16_t k = 0; k < (nfMode?OBX_CAP:obxCount); k++) {
    uint16_t idx = nfMode?k:(uint16_t)((obxHead + OBX_CAP - obxCount + k) % OBX_CAP);
    if(nfMode && !nfHas(idx)) continue;
    wdtKick();                         // RESET-FIX: invalid record-e-o (ager continue-er pore chilo)
    EventRec r;
    if (!obxRead(idx, r) || !recValid(r)) continue;
    sessRefAdd(r, +1);
    if (r.sessionId > maxSid && r.sessionId != ALIAS_UNKNOWN) maxSid = r.sessionId;
    if ((r.type == EV_MAINT_ON || r.type == EV_PROD_ON) && r.cyc > maxSid) maxSid = r.cyc;
  }
  for (uint16_t k = 0; k < ramCount; k++) sessRefAdd(ramObx[(ramHead + RAM_OBX_CAP - ramCount + k) % RAM_OBX_CAP], +1);
  if (pend.active && pend.rec.sessionId > maxSid) maxSid = pend.rec.sessionId;
  if (agg.sessionId > maxSid) maxSid = agg.sessionId;
  if (ctx.nextSid <= maxSid && maxSid < ALIAS_UNKNOWN - 1) { ctx.nextSid = maxSid + 1; ctxSave(); }
  if (ctx.nextSid == 0) { ctx.nextSid = 1; ctxSave(); }
}

// ---------------- Replay: outbox-er event ESP32-e abar pathano ----------------
// Login (HELD -> operator), daily release, ESP32 reboot (HELLO) ba STM32 boot-er por
// outbox-er sob event creation order-e ESP32-e jay (SD log / DB queue), shudhu head-er
// 3 s resend-er opor nirbhor na kore.
bool replayActive = false;
uint16_t replayPos = 0, replayLeft = 0;
unsigned long replayLastMs = 0;

void replayStart() {
  if (!framOk || obxCount == 0) { replayActive = false; return; }
  replayPos = nfMode?0:(uint16_t)((obxHead + OBX_CAP - obxCount) % OBX_CAP);
  replayLeft = nfMode?OBX_CAP:obxCount;
  replayActive = true;
}

// obxCount komanor THIK AGE call (tail record bad jacche)
void replayOnPop() {
  if(nfMode) return; // slot map makes in-flight iteration independent of retirement
  if (!replayActive || replayLeft == 0 || obxCount == 0) return;
  uint16_t tail = (uint16_t)((obxHead + OBX_CAP - obxCount) % OBX_CAP);
  if (replayPos == tail) { replayPos = (uint16_t)((replayPos + 1) % OBX_CAP); replayLeft--; }
}

// =============================================================================
// 13) RTC (DS3231, UTC epoch) — cache + soft clock fallback
// =============================================================================
bool rtcPresent = false;
bool rtcOk = false;
// Three consecutive 10-second checks are required before an already-healthy RTC is declared offline.
static uint8_t rtcConsecutiveFails = 0;
static uint32_t rtcLastGoodReadMs = 0;
// OSF evidence: consecutive RTC register observations must advance and agree with trusted cache.
static uint32_t rtcOsfCandidateEpoch = 0;
static uint32_t rtcOsfCandidateMs = 0;
static uint8_t rtcOsfEvidence = 0;
uint32_t rtcCacheEpoch = 0;
unsigned long rtcCacheMs = 0;

static uint8_t bcd2bin(uint8_t v) { return (v & 0x0F) + ((v >> 4) * 10); }
static uint8_t bin2bcd(uint8_t v) { return (uint8_t)(((v / 10) << 4) | (v % 10)); }

static int32_t daysFromCivil(int32_t y, uint32_t m, uint32_t d) {
  y -= (m <= 2);
  const int32_t era = (y >= 0 ? y : y - 399) / 400;
  const uint32_t yoe = (uint32_t)(y - era * 400);
  const uint32_t doy = (153 * (m > 2 ? m - 3 : m + 9) + 2) / 5 + d - 1;
  const uint32_t doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  return era * 146097 + (int32_t)doe - 719468;
}

static void civilFromDays(int32_t z, int32_t& y, uint32_t& m, uint32_t& d) {
  z += 719468;
  const int32_t era = (z >= 0 ? z : z - 146096) / 146097;
  const uint32_t doe = (uint32_t)(z - era * 146097);
  const uint32_t yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
  y = (int32_t)yoe + era * 400;
  const uint32_t doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
  const uint32_t mp = (5 * doy + 2) / 153;
  d = doy - (153 * mp + 2) / 5 + 1;
  m = mp < 10 ? mp + 3 : mp - 9;
  y += (m <= 2);
}

// RTC-ONLY transport: independent software I2C on PB8/PB9.
// FRAM remains on hardware I2C1 PB6/PB7 via Wire, unchanged.
// Open drain, never drive a line HIGH; external 3.3V pull-ups REQUIRED.
#define PIN_RTC_SOFT_SCL PB8
#define PIN_RTC_SOFT_SDA PB9
#define RTC_SOFT_DELAY_US 5U
#define RTC_SOFT_STRETCH_TIMEOUT_US 2500UL
static bool rtcSoftInitialized=false;
static uint32_t rtcSoftErrors=0;
static inline void rtcSclLow(){ pinMode(PIN_RTC_SOFT_SCL, OUTPUT_OPEN_DRAIN); digitalWrite(PIN_RTC_SOFT_SCL,LOW); }
static inline void rtcSdaLow(){ pinMode(PIN_RTC_SOFT_SDA, OUTPUT_OPEN_DRAIN); digitalWrite(PIN_RTC_SOFT_SDA,LOW); }
static inline void rtcSclRelease(){ pinMode(PIN_RTC_SOFT_SCL,INPUT); }
static inline void rtcSdaRelease(){ pinMode(PIN_RTC_SOFT_SDA,INPUT); }
static void rtcSoftInit(){
  if(rtcSoftInitialized)return;
  rtcSclRelease();rtcSdaRelease();rtcSoftInitialized=true;
}
static bool rtcSclHigh(){
  rtcSclRelease();
  uint32_t t=micros();
  while(!digitalRead(PIN_RTC_SOFT_SCL)){
    if((uint32_t)(micros()-t)>RTC_SOFT_STRETCH_TIMEOUT_US){rtcSoftErrors++;return false;}
  }
  delayMicroseconds(RTC_SOFT_DELAY_US);return true;
}
static bool rtcSoftStart(){
  rtcSoftInit();rtcSdaRelease();
  if(!rtcSclHigh())return false;
  if(!digitalRead(PIN_RTC_SOFT_SDA)){rtcSoftErrors++;return false;}
  rtcSdaLow();delayMicroseconds(RTC_SOFT_DELAY_US);
  rtcSclLow();delayMicroseconds(RTC_SOFT_DELAY_US);return true;
}
static void rtcSoftStop(){
  rtcSdaLow();delayMicroseconds(RTC_SOFT_DELAY_US);
  if(rtcSclHigh()){
    rtcSdaRelease();delayMicroseconds(RTC_SOFT_DELAY_US);
  }else rtcSdaRelease();
}
static bool rtcSoftWriteByte(uint8_t v){
  for(uint8_t bit=0;bit<8;bit++){
    if(v&0x80)rtcSdaRelease();else rtcSdaLow();
    delayMicroseconds(RTC_SOFT_DELAY_US);
    if(!rtcSclHigh())return false;
    rtcSclLow();delayMicroseconds(RTC_SOFT_DELAY_US);v<<=1;
  }
  rtcSdaRelease();delayMicroseconds(RTC_SOFT_DELAY_US);
  if(!rtcSclHigh())return false;
  bool ack=!digitalRead(PIN_RTC_SOFT_SDA);
  rtcSclLow();delayMicroseconds(RTC_SOFT_DELAY_US);
  if(!ack)rtcSoftErrors++;
  return ack;
}
static bool rtcSoftReadByte(uint8_t& v,bool ack){
  v=0;rtcSdaRelease();
  for(uint8_t bit=0;bit<8;bit++){
    delayMicroseconds(RTC_SOFT_DELAY_US);
    if(!rtcSclHigh())return false;
    v=(uint8_t)((v<<1)|(digitalRead(PIN_RTC_SOFT_SDA)?1:0));
    rtcSclLow();delayMicroseconds(RTC_SOFT_DELAY_US);
  }
  if(ack)rtcSdaLow();else rtcSdaRelease();
  delayMicroseconds(RTC_SOFT_DELAY_US);
  if(!rtcSclHigh()){rtcSdaRelease();return false;}
  rtcSclLow();rtcSdaRelease();delayMicroseconds(RTC_SOFT_DELAY_US);
  return true;
}
static bool rtcSoftAck(){
  if(!rtcSoftStart()){rtcSoftStop();return false;}
  bool ok=rtcSoftWriteByte((uint8_t)(RTC_I2C_ADDR<<1));
  rtcSoftStop();return ok;
}
static uint8_t rtcSoftAckCode(){return rtcSoftAck()?0:2;}
static bool rtcSoftReadRegs(uint8_t reg,uint8_t* buf,uint8_t n){
  if(!rtcSoftStart()){rtcSoftStop();return false;}
  bool ok=rtcSoftWriteByte((uint8_t)(RTC_I2C_ADDR<<1)) && rtcSoftWriteByte(reg);
  if(ok)ok=rtcSoftStart() && rtcSoftWriteByte((uint8_t)((RTC_I2C_ADDR<<1)|1));
  for(uint8_t i=0;ok && i<n;i++)ok=rtcSoftReadByte(buf[i],i+1<n);
  rtcSoftStop();return ok;
}
static bool rtcSoftWriteRegs(uint8_t reg,const uint8_t* buf,uint8_t n){
  if(!rtcSoftStart()){rtcSoftStop();return false;}
  bool ok=rtcSoftWriteByte((uint8_t)(RTC_I2C_ADDR<<1)) && rtcSoftWriteByte(reg);
  for(uint8_t i=0;ok && i<n;i++)ok=rtcSoftWriteByte(buf[i]);
  rtcSoftStop();return ok;
}

bool rtcReadRegs(uint8_t reg, uint8_t* buf, uint8_t n) {
  return rtcSoftReadRegs(reg,buf,n);
}

bool rtcWriteReg(uint8_t reg, uint8_t v) {
  return rtcSoftWriteRegs(reg,&v,1);
}

bool rtcReadEpoch(uint32_t& e) {
  uint8_t st;
  if (!rtcReadRegs(0x0F, &st, 1)) return false;
  if (st & 0x80) return false;                       // OSF: time invalid
  uint8_t r[7];
  if (!rtcReadRegs(0x00, r, 7)) return false;
  uint32_t sec = bcd2bin(r[0] & 0x7F), mn = bcd2bin(r[1] & 0x7F), hr;
  if (r[2] & 0x40) { hr = bcd2bin(r[2] & 0x1F) % 12; if (r[2] & 0x20) hr += 12; }
  else hr = bcd2bin(r[2] & 0x3F);
  uint32_t day = bcd2bin(r[4] & 0x3F), mon = bcd2bin(r[5] & 0x1F);
  int32_t yr = 2000 + bcd2bin(r[6]) + ((r[5] & 0x80) ? 100 : 0);
  if (mon < 1 || mon > 12 || day < 1 || day > 31 || hr > 23 || mn > 59 || sec > 59) return false;
  e = (uint32_t)daysFromCivil(yr, mon, day) * 86400UL + hr * 3600UL + mn * 60UL + sec;
  return true;
}

bool rtcWriteEpoch(uint32_t e) {
  uint32_t days = e / 86400UL, rem = e % 86400UL;
  int32_t y; uint32_t m, d;
  civilFromDays((int32_t)days, y, m, d);
  if (y < 2000 || y > 2099) return false;
  uint8_t dow = (uint8_t)(((days + 4) % 7) + 1);
  uint8_t b[7] = {
    bin2bcd(rem % 60), bin2bcd((rem / 60) % 60), bin2bcd(rem / 3600),
    dow, bin2bcd((uint8_t)d), bin2bcd((uint8_t)m), bin2bcd((uint8_t)(y-2000))
  };
  if (!rtcSoftWriteRegs(0x00,b,7)) return false;
  uint8_t st;
  if (rtcReadRegs(0x0F, &st, 1)) rtcWriteReg(0x0F, st & ~0x80);
  return true;
}

uint8_t rtcJumpCount = 0;

// Read the calendar registers without treating OSF as proof of a valid clock.
// This is evidence ONLY, never an accepted timestamp until OSF recovery is verified.
static bool rtcReadOsfCandidate(uint32_t& e) {
  uint8_t r[7];
  if (!rtcReadRegs(0x00, r, 7)) return false;
  uint32_t sec=bcd2bin(r[0]&0x7F), mn=bcd2bin(r[1]&0x7F), hr;
  if (r[2]&0x40) { hr=bcd2bin(r[2]&0x1F)%12; if (r[2]&0x20) hr+=12; }
  else hr=bcd2bin(r[2]&0x3F);
  uint32_t day=bcd2bin(r[4]&0x3F), mon=bcd2bin(r[5]&0x1F);
  int32_t yr=2000+bcd2bin(r[6])+((r[5]&0x80)?100:0);
  if (mon<1 || mon>12 || day<1 || day>31 || hr>23 || mn>59 || sec>59 || yr>2099) return false;
  e=(uint32_t)daysFromCivil(yr,mon,day)*86400UL+hr*3600UL+mn*60UL+sec;
  return true;
}

// OSF may be cleared OFFLINE only with recent previously VERIFIED RTC time,
// and two 10s-apart calendar reads advancing at the expected rate.
// If there is no trusted cache (e.g. battery lost power before boot), fail closed.
static bool rtcTryOfflineOsfRecovery() {
  uint8_t st=0;
  if (!rtcReadRegs(0x0F,&st,1)) return false;
  if (!(st&0x80)) { rtcOsfEvidence=0; return false; }
  uint32_t now=millis();
  if (rtcCacheEpoch==0 || rtcLastGoodReadMs==0 ||
      (uint32_t)(now-rtcLastGoodReadMs)>3600000UL) return false;
  uint32_t observed=0;
  if (!rtcReadOsfCandidate(observed)) { rtcOsfEvidence=0; return false; }
  uint32_t predicted=rtcNowEpoch();
  uint32_t delta=observed>predicted ? observed-predicted : predicted-observed;
  if (delta>3UL) { rtcOsfEvidence=0; return false; }
  if (rtcOsfEvidence==0) {
    rtcOsfCandidateEpoch=observed; rtcOsfCandidateMs=now; rtcOsfEvidence=1;
    DBG_PRINTF("[RTC-OSF] offline candidate recorded; checking clock progression");
    return false;
  }
  uint32_t ms=(uint32_t)(now-rtcOsfCandidateMs);
  if (ms<8000UL || ms>30000UL || observed<rtcOsfCandidateEpoch ||
      (observed-rtcOsfCandidateEpoch+2UL)<ms/1000UL ||
      (observed-rtcOsfCandidateEpoch)>(ms/1000UL+2UL)) {
    rtcOsfCandidateEpoch=observed; rtcOsfCandidateMs=now; rtcOsfEvidence=1;
    return false;
  }
  // Re-read status immediately before read-modify-write; preserve other bits.
  if (!rtcReadRegs(0x0F,&st,1) || !(st&0x80)) return false;
  if (!rtcWriteReg(0x0F,(uint8_t)(st&~0x80))) return false;
  uint8_t check=0xFF;
  if (!rtcReadRegs(0x0F,&check,1) || (check&0x80)) return false;
  rtcOsfEvidence=0;
  DBG_PRINTF("[RTC-OSF] cleared OFFLINE after cached-time and tick evidence; no NTP used");
  return true;
}

void rtcRefresh() {
  uint32_t e=0;
  bool success=rtcPresent && rtcReadEpoch(e);
  if (!success && rtcPresent && rtcTryOfflineOsfRecovery()) {
    success=rtcReadEpoch(e);
  }
  if (success) {
    if (rtcCacheEpoch != 0) { // Original >1h jump filter left unchanged.
      uint32_t soft=rtcNowEpoch();
      uint32_t diff=e>soft ? e-soft : soft-e;
      if (diff>3600UL && ++rtcJumpCount<3) return;
    }
    rtcJumpCount=0;
    rtcConsecutiveFails=0;
    rtcLastGoodReadMs=millis();
    rtcOk=true;                       // One verified successful read restores RTC=1 immediately.
    rtcCacheEpoch=e;
    rtcCacheMs=millis();
    faults &= ~FAULT_RTC_INVALID;
  } else {
    if (rtcConsecutiveFails<3) ++rtcConsecutiveFails;
    DBG_PRINTF("[RTC-READ] failed consecutive=%u/3 rtcOk=%u", (unsigned)rtcConsecutiveFails,(unsigned)rtcOk);
    if (rtcConsecutiveFails>=3) {
      rtcOk=false;
      faults |= FAULT_RTC_INVALID;
    }
  }
}

uint32_t rtcNowEpoch() {
  if (rtcCacheEpoch == 0) return 0;
  return rtcCacheEpoch + (millis() - rtcCacheMs) / 1000UL;
}

void rtcSetFromEsp(uint32_t e) {
  if (e < 1700000000UL) return;
  uint32_t cur = rtcNowEpoch();
  long diff = (long)(cur - e);
  if (cur == 0 || !rtcOk || diff > 2 || diff < -2) {
    if (rtcPresent && rtcWriteEpoch(e)) { rtcOk = true; faults &= ~FAULT_RTC_INVALID; }
    rtcCacheEpoch = e;
    rtcCacheMs = millis();
  }
}

// =============================================================================
// 14) UART LINK — non-blocking TX ring, bounded RX, CRC16 framing
// =============================================================================
#define LINK_TX_RING 2048          // F3: EV/CTX frame-e name field (max ~700 B)
uint8_t txRing[LINK_TX_RING];
uint16_t txHead = 0, txTail = 0;

static inline uint16_t txUsed() { return (uint16_t)((txHead + LINK_TX_RING - txTail) % LINK_TX_RING); }

void linkTxService() {
  int room = EspLink.availableForWrite();
  while (room > 0 && txTail != txHead) {
    EspLink.write(txRing[txTail]);
    txTail = (txTail + 1) % LINK_TX_RING;
    room--;
  }
}

void linkSend(const char* body) {
  char tail[8];
  size_t bl = strlen(body);
  snprintf(tail, sizeof(tail), "*%04X\n", crc16((const uint8_t*)body, bl));
  size_t total = 1 + bl + strlen(tail);
  if (total > (size_t)(LINK_TX_RING - 1 - txUsed())) {   // jayga nai -> drop (protocol retry kore)
    linkTxDrops++;
    faults |= FAULT_LINK_TX_DROP;
    return;
  }
  txRing[txHead] = '$'; txHead = (txHead + 1) % LINK_TX_RING;
  for (size_t i = 0; i < bl; i++) { txRing[txHead] = (uint8_t)body[i]; txHead = (txHead + 1) % LINK_TX_RING; }
  for (const char* p = tail; *p; p++) { txRing[txHead] = (uint8_t)*p; txHead = (txHead + 1) % LINK_TX_RING; }
  linkTxService();
}

// FLASH64 pulse visibility: piggyback on existing CRC16 DBG frame handling.
// Skip when UART ring is pressured, so production EV/HB/ACK gets priority.
#if STM_PULSE_TRACE && (MACHINE_PROFILE == PROFILE_FLATLOCK_DOUBLE)
  #define PULSE_TRACE(msg) do { \
    if (espProto == PROTO_VER && txUsed() < LINK_TX_RING - 600) linkSend("DBG," msg); \
  } while (0)
#else
  #define PULSE_TRACE(msg) do {} while (0)
#endif

void linkSendf(const char* fmt, ...) {
  char b[300];
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(b, sizeof(b), fmt, ap);
  va_end(ap);
  linkSend(b);
}

// Drain debug only after ESP HELLO and when protocol TX ring has headroom.
// Never block sensing/ACK/retry; rate limit to one frame per 30 ms.
void stmDebugService() {
#if STM_UART_DEBUG
  if (espProto != PROTO_VER || dbgTail == dbgHead) return;
  if ((uint32_t)(millis() - dbgLastSend) < 30UL) return;
  if (txUsed() > LINK_TX_RING - 600) return;
  char frame[150];
  snprintf(frame, sizeof(frame), "DBG,%s", dbgRing[dbgTail]);
  linkSend(frame);
  dbgTail = (uint8_t)((dbgTail + 1) % DBG_RING_N);
  dbgLastSend = millis();
#endif
}

// =============================================================================
// I2CD2 — I2C BUS HEALTH
//   (a) Pin-isolation snapshot: boot-er protiti dhape SDA/SCL level (S0..S8)
//   (b) BUSY vs NACK alada kora (I2C1->SR2 BUSY flag)
//       NOTE: STM32duino 2.11 twi.c-te i2c_IsDeviceReady() handle READY thakle
//       HAL_BUSY / HAL_TIMEOUT / HAL_ERROR — SOB kichu rc=2 (NACK_ADDR) hisebe dey.
//       Tai rc=2 mane "device nai" na-o hote pare; BUSY=1 hole bus-i atke ache.
//   (c) Bus recovery: Wire.end -> 9 SCL clock (open-drain) -> STOP -> Wire.begin
//   (d) Boot retry + runtime: bus atke gele recover, RTC pore ashle attach,
//       FRAM pore ashle report (safe attach-er jonno STM32 reboot dorkar).
// =============================================================================
#define PIN_SNAP_MAX 9
// S0 setup start (reset state)   S1 Andon PB12..15 OUTPUT   S2 PB5 ESP_RESET Hi-Z (I2CF1)
// S3 LED + button/sensor inputs  S4 UART begin              S5 SDA/SCL INPUT_PULLUP (internal)
// S6 PB5 Hi-Z (2 ms por)         S7 Wire.begin + 500 ms     S8 boot recovery/retry sesh
static uint8_t pinSnap[PIN_SNAP_MAX];   // bit1 = SDA, bit0 = SCL, 0xFF = capture hoy ni
static uint8_t bootRc50 = 255, bootRc68 = 255, bootBusy = 255;
static uint8_t bootRecTries = 0, bootRecLast = 255;
static uint8_t i2cRecLast = 255;        // 0 free, 1 SDA atke chilo -> chhere diyeche, 2 SDA atke ache, 3 SCL LOW dhore rakha
static uint32_t i2cRecCount = 0;
static bool framLateSeen = false;
static uint32_t i2cLastHealthMs = 0;

static inline uint8_t i2cLines() {
  return (uint8_t)((digitalRead(PIN_I2C_SDA) ? 2 : 0) | (digitalRead(PIN_I2C_SCL) ? 1 : 0));
}
static void pinSnapAt(uint8_t i) {
  if (i >= PIN_SNAP_MAX) return;
  delayMicroseconds(50);
  pinSnap[i] = i2cLines();
}
static inline bool i2cHwBusy() { return false; }   // FRAM-PB3PB4: FRAM bus-e hardware I2C peripheral nei
static inline bool i2cLooksStuck() {
  return i2cHwBusy() || digitalRead(PIN_I2C_SCL) == LOW || digitalRead(PIN_I2C_SDA) == LOW;
}
// I2CREC-FIX (1): runtime stuck CONFIRMATION. Ekta transaction-er thik pore
// STOP condition bus-e sesh hote kichu us lage (BUSY=1). Oi muhurte ekbar dekhe
// "stuck" dhorle healthy bus-eo i2cBusRecover() chole jay. Tai 2 ms tana stuck
// thaklei tobei stuck. 100 kHz-e STOP ~10 us; 2 ms = 200x margin. IWDG 2 s safe.
static bool i2cStuckConfirmed() {
  if (!i2cLooksStuck()) return false;
  uint32_t t0 = micros();
  while ((uint32_t)(micros() - t0) < 2000UL) {
    if (!i2cLooksStuck()) return false;
  }
  return true;
}
static void i2cBegin() {                     // FRAM-PB3PB4: software bus init (ager Wire.begin)
  framSwInit();
}

// return: 0 bus free, 1 SDA atke chilo -> clock diye chharano gelo,
//         2 SDA ekhono LOW, 3 SCL bahire theke LOW dhore rakha (STM32 kichu korte pare na)
uint8_t i2cBusRecover() {
  framSwRelease();                             // FRAM-PB3PB4: ager Wire.end() (pin Hi-Z)
  digitalWrite(PIN_I2C_SCL, HIGH);             // ODR=1 age, jate open-drain-e glitch na hoy
  digitalWrite(PIN_I2C_SDA, HIGH);
  pinMode(PIN_I2C_SCL, INPUT);
  pinMode(PIN_I2C_SDA, INPUT);
  delayMicroseconds(20);
  uint8_t res = 0;
  uint32_t t0 = micros();
  while (digitalRead(PIN_I2C_SCL) == LOW && (uint32_t)(micros() - t0) < 3000UL) { }   // clock-stretch shohjo kora
  if (digitalRead(PIN_I2C_SCL) == LOW) {
    res = 3;
  } else {
    pinMode(PIN_I2C_SCL, OUTPUT_OPEN_DRAIN);
    if (digitalRead(PIN_I2C_SDA) == LOW) {
      for (uint8_t i = 0; i < 9 && digitalRead(PIN_I2C_SDA) == LOW; i++) {
        digitalWrite(PIN_I2C_SCL, LOW);  delayMicroseconds(5);
        digitalWrite(PIN_I2C_SCL, HIGH); delayMicroseconds(5);
      }
      res = (digitalRead(PIN_I2C_SDA) == LOW) ? 2 : 1;
    }
    // STOP condition: SCL HIGH thakar somoy SDA LOW -> HIGH
    pinMode(PIN_I2C_SDA, OUTPUT_OPEN_DRAIN);
    digitalWrite(PIN_I2C_SCL, LOW);  delayMicroseconds(5);
    digitalWrite(PIN_I2C_SDA, LOW);  delayMicroseconds(5);
    digitalWrite(PIN_I2C_SCL, HIGH); delayMicroseconds(5);
    digitalWrite(PIN_I2C_SDA, HIGH); delayMicroseconds(5);
    pinMode(PIN_I2C_SDA, INPUT);
    pinMode(PIN_I2C_SCL, INPUT);
  }
  i2cBegin();                                  // FRAM-PB3PB4: software bus abar init
  i2cRecLast = res;
  i2cRecCount++;
  return res;
}

// Late FRAM reattach: never infer an empty journal from an I2C ACK alone.
// This routine is deliberately restricted to a boot where no new runtime event
// or operator state has been created while FRAM was unavailable. Otherwise a
// blind reload could roll back RAM counters or reuse sequence numbers.
static bool framAttachAfterBootFailure() {
  if (framOk) return true;
  if (eventSeq != 0 || totalProduction != 0 || totalAlter != 0 ||
      actualProduction != 0 || ramCount != 0 || pend.active || aggActive() ||
      operatorReady) {
    DBG_PRINTLN("[FRAM-LATE] RAM state changed after boot; refusing unsafe live reload");
    return false;
  }
  uint16_t m=0,p=0;
  if (!i2cAck(FRAM_I2C_ADDR) || !framReadDeviceId(FRAM_I2C_ADDR,m,p) ||
      m!=0x00A || (p>>8)<5) return false;
  // Read-only proof that BOTH format and persisted state are readable. No
  // auto-provision, clearing, write probe, or setting FRAM=1 on ACK alone.
  uint8_t g[16];
  if (!framReadBytesAt(FRAM_I2C_ADDR,FRAM_SUPER_A,g,sizeof(g)) ||
      !framReadBytesAt(FRAM_I2C_ADDR,FRAM_SUPER_B,g,sizeof(g))) return false;
  // Temporarily enable the read-only validator; on failure restore inactive.
  framAddr=FRAM_I2C_ADDR; framProductId=p; framVerified=true;
  framState=1; framOk=true;
  bool guards=smuGuardValidAt(FRAM_SUPER_A) || smuGuardValidAt(FRAM_SUPER_B);
  if (!guards) {
    framOk=false; framState=0; framAddr=0;
    DBG_PRINTLN("[FRAM-LATE] format guard invalid: no write, no auto-format");
    return false;
  }
  // Confirm persistent counters and outbox headers before mutating RAM.
  PersistState a,b;
  bool stateReadable=framReadBytes(FRAM_STATE_A,&a,sizeof(a)) &&
                     framReadBytes(FRAM_STATE_B,&b,sizeof(b));
  ObxHdr oa{},ob{};
  bool obxReadable=framReadBytes(FRAM_OBX_HDR_A,&oa,sizeof(oa)) &&
                   framReadBytes(FRAM_OBX_HDR_B,&ob,sizeof(ob));
  uint8_t nla[NF_META_BYTES],nlb[NF_META_BYTES];
  bool nfReadable=framReadBytes(NF_META_A,nla,sizeof(nla)) &&
                  framReadBytes(NF_META_B,nlb,sizeof(nlb));
  bool obxValid=(oa.magic==OBX_MAGIC && oa.crc==crc16((const uint8_t*)&oa,sizeof(oa)-2) && oa.head<OBX_CAP && oa.count<=OBX_CAP) ||
                (ob.magic==OBX_MAGIC && ob.crc==crc16((const uint8_t*)&ob,sizeof(ob)-2) && ob.head<OBX_CAP && ob.count<=OBX_CAP) ||
                (nfReadable && (nfValid(nla) || nfValid(nlb)));
  if (!stateReadable || !obxReadable || !obxValid) {
    framOk=false; framState=0; framAddr=0;
    DBG_PRINTLN("[FRAM-LATE] metadata unreadable/invalid: keeping FRAM=0");
    return false;
  }
  // From here all core metadata is readable. Reuse the existing boot loaders;
  // don't reset the journal or sequence allocator.
  smuFormatReady=true;
  int ls=loadState();
  if (ls!=1) {
    framOk=false; framState=0; framAddr=0;
    DBG_PRINTF("[FRAM-LATE] state load=%d; refusing unsafe attach",ls);
    return false;
  }
  obxLoadHdr();
  IWatchdog.reload();
  smuCheckpointLoad();
  if (smuCpGeneration) {
    if (smuCpLastSequence>eventSeq) {
      eventSeq=smuCpLastSequence;
      totalProduction=smuCpTotalP; totalAlter=smuCpTotalA;
      actualProduction=smuCpActualP;
    }
    if (smuCpLifeP>lifeProduction) lifeProduction=smuCpLifeP;
    if (smuCpLifeA>lifeAlter) lifeAlter=smuCpLifeA;
    if (smuCpBootCount>bootCount) bootCount=smuCpBootCount;
  }
  if (smuMetadataRecoveryFault) {
    framOk=false; framState=0; framAddr=0;
    DBG_PRINTLN("[FRAM-LATE] checkpoint metadata fault: storage remains locked");
    return false;
  }
  if(nfMode) (void)nfRecoverIntent();
  else {
    smuRecoverCommittedOrphan();
    if(!smuMetadataRecoveryFault) (void)nfActivateFromLegacy();
  }
  if (smuMetadataRecoveryFault) {
    framOk=false; framState=0; framAddr=0;
    DBG_PRINTLN("[FRAM-LATE] journal/slot recovery failed: storage remains locked");
    return false;
  }
  IWatchdog.reload();
  pendLoad(); aggLoad(); ctxLoad(); sessLoadAll(); sessRebuildRefs();
  // Recovery must preserve the preexisting journal and pending records.
  // Do not call reconcileState() here: it persists FRAM immediately.
  EventRec newest;
  if (obxNewest(newest) && newest.seq>eventSeq) {
    eventSeq=newest.seq;
    if (newest.type!=EV_AGGREGATE) {
      totalProduction=newest.tp; totalAlter=newest.ta;
      actualProduction=newest.ac;
      if (newest.lifeP>lifeProduction) lifeProduction=newest.lifeP;
      if (newest.lifeA>lifeAlter) lifeAlter=newest.lifeA;
    }
  }
  if (pend.active && pend.rec.seq>eventSeq) {
    eventSeq=pend.rec.seq;
    totalProduction=pend.rec.tp; totalAlter=pend.rec.ta;
    actualProduction=pend.rec.ac;
  }
  if (aggActive() && agg.lastSeq>eventSeq) {
    eventSeq=agg.lastSeq; totalProduction=agg.tp;
    totalAlter=agg.ta; actualProduction=agg.ac;
  }
  framLateSeen=true;
  faults &= ~(FAULT_FRAM_ABSENT | FAULT_FRAM_WRITE);
  ctxDirty=true;
  replayStart();
  DBG_PRINTF("[FRAM-LATE] ATTACHED 0x%02X M=%03X P=%03X seq=%lu outbox=%u state=%u",
             (unsigned)framAddr,(unsigned)m,(unsigned)p,(unsigned long)eventSeq,
             (unsigned)obxCount,(unsigned)framState);
  return true;
}

// Loop theke: 5 s por por, shudhu jokhon kichu thik nei (bus atke / RTC nai / FRAM nai).
void i2cHealthService() {
  if ((uint32_t)(millis() - i2cLastHealthMs) < 5000UL) return;
  i2cLastHealthMs = millis();
  // Heartbeat-only live check on the existing FRAM hardware I2C1 bus.
  // Three successive missed identity checks mark the HEARTBEAT as absent.
  // One successful identity check restores the reported state immediately.
  // Do NOT change framOk or any storage/write/recovery decision here.
  bool framProbeFailed = false;        // I2CREC-FIX (3)
  {
    uint16_t m=0, p=0;
    bool live = i2cAck(FRAM_I2C_ADDR) &&
                framReadDeviceId(FRAM_I2C_ADDR, m, p) &&
                m == 0x00A && (p >> 8) >= 5;
    framProbeFailed = !live;
    if (live) {
      bool wasDown = framLiveMisses >= 3;
      framLiveMisses = 0;
      if (wasDown) DBG_PRINTLN("[FRAM-LIVE] RESPONSE RESTORED (report only; storage readiness unchanged)");
    } else {
      if (framLiveMisses < 3) ++framLiveMisses;
      if (framLiveMisses == 3) {
        DBG_PRINTLN("[FRAM-LIVE] 3 FAILS: HEARTBEAT FRAM=0 (report only)");
        // Suppress repeating the transition log at every unsuccessful poll.
        ++framLiveMisses;
      }
    }
  }
  bool needRtc = !rtcPresent;
  bool needFram = !framOk;
  bool stuck = i2cStuckConfirmed();    // I2CREC-FIX (1): ager i2cLooksStuck() ekbar-er sample
  // RTC can be present-at-boot but nonresponsive later; cached rtcPresent stays true.
  // Probe only after three consecutive failures; main-loop I2C calls are sequential.
  bool failedRtc = rtcConsecutiveFails>=3;
  if (!stuck && !needRtc && !needFram && !failedRtc && !framProbeFailed) return;
  if (stuck) i2cBusRecover();          // Existing stuck-bus recovery, unchanged.
  else if (framProbeFailed) {
    // I2CREC-FIX (3): pin HIGH, BUSY=0 kintu FRAM probe fail (log: rc50=4 rc53=4,
    // CR1=0401) = I2C1 HAL handle mid-receive-e atke ache. Pin-based stuck check
    // eta dhorte pare na, tai ager build-e power cycle chara fire asto na.
    // I2C1 hard reset + re-init (no FRAM write, no storage-state change).
    static uint32_t halRecoverCount = 0;
    i2cBusRecover();
    if (++halRecoverCount == 1 || (halRecoverCount % 20) == 0)
      DBG_PRINTF("[I2C-REC] FRAM probe fail, pins HIGH -> I2C1 hard reset #%lu",
                 (unsigned long)halRecoverCount);
  }
  if (failedRtc && !stuck) {
    // Separate RTC bus: FRAM/I2C1 must never be reset because RTC failed.
    // Normal 10s rtcRefresh() retry automatically restores status on success.
    static uint32_t lastRtcProbeMs=0;
    if ((uint32_t)(millis()-lastRtcProbeMs)>=30000UL) {
      lastRtcProbeMs=millis();
      DBG_PRINTF("[RTC-SW] retry pb8/pb9 ack=%u SDA=%u SCL=%u errors=%lu",
        (unsigned)rtcSoftAck(),(unsigned)digitalRead(PIN_RTC_SOFT_SDA),
        (unsigned)digitalRead(PIN_RTC_SOFT_SCL),(unsigned long)rtcSoftErrors);
    }
  }
  if (needRtc && rtcSoftAck()) {
    rtcPresent = true;
    rtcRefresh();
    DBG_PRINTF("[I2C] RTC 0x68 late-detected rtcOk=%u", (unsigned)rtcOk);
  }
  if (needFram) {
    // Retry every health cycle; previous framLateSeen latch must NOT suppress attach.
    framAttachAfterBootFailure();
  }
}

// RTC on software PB8/PB9, FRAM on I2C1 PB6/PB7. ACKMAP: protiti boot dhape (pin config-er por por) ashol I2C transaction —
// FRAM 0x50 ar RTC 0x68 ACK dey kina. Test sketch-er moto boot shuru-te (A0) ACK
// pele kintu kono dhape giye na pele, oi dhaper pin/peripheral-i ashami.
// A0 setup shuru (kichu configure hoy ni, 300 ms power settle)   A1 Andon PB12..15 OUTPUT LOW
// A2 PB5 Hi-Z + LED            A3 sob input/pull-up (PB1, PB10 ...)   A4 UART begin
// A5 PB5 INPUT_PULLUP (40k)    A6 PB5 OUTPUT HIGH 20 ms (design-e ESP32 reset hote pare)
#define ACK_MAP_MAX 7
static uint8_t ackMap[ACK_MAP_MAX];     // bit1 = FRAM 0x50 ACK, bit0 = RTC 0x68 ACK, bit2 = BUSY, 0xFF = na
static void ackStage(uint8_t i) {
  if (i >= ACK_MAP_MAX) return;
  i2cBegin();
  delay(3);
  uint8_t v = 0;
  if (i2cHwBusy()) v |= 4;
  if (i2cAck(FRAM_I2C_ADDR)) v |= 2;
  if (rtcSoftAck()) v |= 1;
  ackMap[i] = v;
  framSwRelease();                             // FRAM-PB3PB4: ager Wire.end()
  pinMode(PIN_I2C_SCL, INPUT);
  pinMode(PIN_I2C_SDA, INPUT);
}
static void ackMapStr(char* out, size_t n) {
  size_t o = 0;
  for (uint8_t i = 0; i < ACK_MAP_MAX && o + 5 < n; i++) {
    uint8_t v = ackMap[i];
    if (v == 0xFF) { out[o++] = '-'; out[o++] = '-'; }
    else { out[o++] = (v & 2) ? '1' : '0'; out[o++] = (v & 1) ? '1' : '0'; if (v & 4) out[o++] = 'B'; }
    out[o++] = ' ';
  }
  if (o) o--;
  out[o] = 0;
}

static void pinSnapStr(char* out, size_t n) {
  size_t o = 0;
  for (uint8_t i = 0; i < PIN_SNAP_MAX && o + 4 < n; i++) {
    uint8_t v = pinSnap[i];
    out[o++] = (v == 0xFF) ? '-' : ((v & 2) ? '1' : '0');
    out[o++] = (v == 0xFF) ? '-' : ((v & 1) ? '1' : '0');
    out[o++] = ' ';
  }
  if (o) o--;
  out[o] = 0;
}

// DIAGNOSTIC ONLY. Mark the first STM32 I2C boot phase where either device
// becomes unreachable. Each stage adds two address-only I2C probes.
// This does not write or erase any FRAM or RTC location.
#define I2C_TRACE_STAGES 9
static uint8_t i2cTraceResult[I2C_TRACE_STAGES] = {
  0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};
static uint8_t i2cTraceHalState[I2C_TRACE_STAGES] = {};
static uint32_t i2cTraceHalError[I2C_TRACE_STAGES] = {};
static void i2cTraceStage(uint8_t stage) {
  if (stage >= I2C_TRACE_STAGES) return;
  uint8_t a = framSwAckCode((uint8_t)0x50);    // FRAM-PB3PB4: software bus
  uint8_t b = rtcSoftAckCode();
  i2cTraceResult[stage] = (uint8_t)((a << 4) | (b & 0x0F));
  // FRAM-PB3PB4: hardware HAL handle ar nei; field-e software bus error count.
  i2cTraceHalState[stage] = 0;
  i2cTraceHalError[stage] = framSwErrors;
}
static void i2cTraceReport() {
  char b[3 * I2C_TRACE_STAGES + 1];
  const char hex[] = "0123456789ABCDEF";
  size_t o = 0;
  for (uint8_t i = 0; i < I2C_TRACE_STAGES; ++i) {
    uint8_t v = i2cTraceResult[i];
    if (i) b[o++] = ' ';
    b[o++] = hex[(v >> 4) & 0x0F];
    b[o++] = hex[v & 0x0F];
  }
  b[o] = 0;
  stmDebugPrintf("[I2C-STAGES] 0..8: %s | FRAMBUS=SW_PB3PB4 swErr=%lu",
                 b, (unsigned long)framSwErrors);
  stmDebugPrintf("[I2C-HAL] 1=%02X/%lX 2=%02X/%lX 3=%02X/%lX 5=%02X/%lX",
                 (unsigned)i2cTraceHalState[1], (unsigned long)i2cTraceHalError[1],
                 (unsigned)i2cTraceHalState[2], (unsigned long)i2cTraceHalError[2],
                 (unsigned)i2cTraceHalState[3], (unsigned long)i2cTraceHalError[3],
                 (unsigned)i2cTraceHalState[5], (unsigned long)i2cTraceHalError[5]);
}

// Read-only probes: ACK, FRAM Device-ID, DS3231 status register and time.
// Does not write ANY FRAM location or clear RTC OSF.
void stmI2cDebugProbe() {
#if STM_UART_DEBUG
  if ((uint32_t)(millis() - dbgLastProbe) < STM_DIAG_PERIOD_MS) return;
  dbgLastProbe = millis();
  uint16_t m=0, p=0;
  char snap[3 * PIN_SNAP_MAX + 4];
  pinSnapStr(snap, sizeof(snap));
  {
    char am[4 * ACK_MAP_MAX + 2];
    ackMapStr(am, sizeof(am));
    // [ACKMAP] digit pair = FRAM(0x50) RTC(0x68) ACK, 'B' = I2C BUSY (A0..A6)
    stmDebugPrintf("[ACKMAP] %s", am);
  }
  // [PINMAP] digit pair = SDA SCL (S0..S8). Boot rc + BUSY + recovery result.
  stmDebugPrintf("[PINMAP] %s | rc50=%u rc68=%u busy=%u rec=%u/%u",
                 snap, (unsigned)bootRc50, (unsigned)bootRc68, (unsigned)bootBusy,
                 (unsigned)bootRecTries, (unsigned)bootRecLast);
  // Current bus state BEFORE this round's transactions.
  uint8_t liveSda = (uint8_t)digitalRead(PIN_I2C_SDA);
  uint8_t liveScl = (uint8_t)digitalRead(PIN_I2C_SCL);
  // FRAM-PB3PB4: SDA/SCL = PB4/PB3 (FRAM software bus). swErr = timeout/line-low count.
  stmDebugPrintf("[BUS] FRAM PB4(SDA)=%u PB3(SCL)=%u rec=%lu last=%u swErr=%lu",
                 (unsigned)liveSda, (unsigned)liveScl,
                 (unsigned long)i2cRecCount, (unsigned)i2cRecLast,
                 (unsigned long)framSwErrors);
  uint8_t rc50 = framSwAckCode(0x50);
  uint8_t rc53 = framSwAckCode(0x53);
  uint8_t rc68 = rtcSoftAckCode();
  bool f50 = (rc50 == 0), f53 = (rc53 == 0), r68 = (rc68 == 0);
  stmDebugPrintf("[LIVE-I2C] FRAM=SW_PB3PB4 RTC=SW_PB8PB9 rc50=%u rc53=%u rc68=%u busyAfter=%u",
                 (unsigned)rc50,(unsigned)rc53,(unsigned)rc68,(unsigned)(i2cHwBusy() ? 1 : 0));
  bool id50=f50 && framReadDeviceId(0x50,m,p);
  stmDebugPrintf("[I2C] ACK 0x50=%u 0x53=%u 0x68=%u ID50=%u M=%03X P=%03X",
                 (unsigned)f50,(unsigned)f53,(unsigned)r68,(unsigned)id50,m,p);
  uint8_t st=0;
  bool sr = r68 && rtcReadRegs(0x0F,&st,1);
  uint32_t epoch=0;
  bool valid = r68 && rtcReadEpoch(epoch);
  stmDebugPrintf("[RTC] present=%u statusRead=%u status=0x%02X OSF=%u valid=%u epoch=%lu",
                 (unsigned)rtcPresent,(unsigned)sr,st,(unsigned)(sr && (st&0x80)!=0),(unsigned)valid,(unsigned long)epoch);
  stmDebugPrintf("[FRAM] configured=0x%02X selected=0x%02X ok=%u state=%u late=%u fault=0x%04X drop=%lu",
                 FRAM_I2C_ADDR,framAddr,(unsigned)framOk,(unsigned)framState,(unsigned)framLateSeen,
                 (unsigned)faults,(unsigned long)dbgDropped);
  i2cTraceReport();
#endif
}

// Text field (name) encode: ',' '%' '$' '*' '~' control / non-ASCII -> %XX, empty -> "~"
static void encText(char* out, size_t n, const char* s) {
  static const char hx[] = "0123456789ABCDEF";
  if (!s || !*s) { strCopy(out, n, "~"); return; }
  size_t o = 0;
  for (; *s && o + 4 < n; s++) {
    uint8_t c = (uint8_t)*s;
    if (c < 0x20 || c >= 0x7F || c == ',' || c == '%' || c == '$' || c == '*' || c == '~') {
      out[o++] = '%'; out[o++] = hx[c >> 4]; out[o++] = hx[c & 15];
    } else {
      out[o++] = (char)c;
    }
  }
  out[o] = 0;
}

static int hexNib(char c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  return -1;
}

static void decText(char* s) {           // in place
  if (!strcmp(s, "~")) { s[0] = 0; return; }
  char* w = s;
  for (char* r = s; *r; r++) {
    int h, l;
    if (*r == '%' && (h = hexNib(r[1])) >= 0 && (l = hexNib(r[2])) >= 0) { *w++ = (char)((h << 4) | l); r += 2; }
    else *w++ = *r;
  }
  *w = 0;
}

static const char* reasonText(uint8_t i) {
  static const char* t[] = { "-", "Reason_1", "Reason_2", "Reason_3", "Reason_4" };
  return (i <= 4) ? t[i] : "-";
}

static uint8_t reasonIndexOf(const char* r) {
  if (!r || !*r) return 0;
  if (!strncmp(r, "Reason_", 7)) {
    int v = atoi(r + 7);
    if (v >= 1 && v <= 4) return (uint8_t)v;
  }
  return 0;
}

void sendBoot() {
  linkSendf("BOOT,%d,%d,%s,%08lX,%02lX,%d,%d,%s,%08lX", PROTO_VER, MACHINE_PROFILE, PROFILE_NAME,
            (unsigned long)stmUid, (unsigned long)resetFlags, framState,
            rtcPresent ? (rtcOk ? 1 : 2) : 0, FW_REV, (unsigned long)seqEpoch);
}

void sendHeartbeat() {
  long smvMilli = (long)(activeSmv * 1000.0 + 0.5);
  linkSendf("HB,%d,%d,%ld,%ld,%ld,%d,%d,%d,%d,%u,%lu,%d,%d,%lu,%d,%lu,%08lX,%ld,%d,%lu,%lu,%lu,%04X,%lu,%d,%08lX,%lu",
            PROTO_VER, MACHINE_PROFILE, (long)totalProduction, (long)totalAlter, (long)actualProduction,
            currentPerformancePct(), currentLightCode(), isMaintenanceMode ? 1 : 0,
            operatorReady ? 1 : 0, (unsigned)outboxTotal(), (unsigned long)rtcNowEpoch(),
            rtcOk ? 1 : 0, framHeartbeatState(), (unsigned long)zRpm, aggActive() ? 1 : 0,
            (unsigned long)eventSeq, (unsigned long)stmUid, smvMilli, activeDivisor,
            (unsigned long)currentSessionId, (unsigned long)lifeProduction, (unsigned long)lifeAlter,
            (unsigned)faults, (unsigned long)lastDeliveredSeq, IWatchdog.isEnabled() ? 1 : 0,
            (unsigned long)seqEpoch, (unsigned long)prodDay);
}

// RESET-FIX: diagnostic frame -> ESP32 Serial "[STM-DIAG]" (ESP32 decode kore text dekhay).
// Purono ESP32 firmware eta "UNKNOWN" hisebe ignore kore (kono khoti nei).
//  SDIAG,rstFlags,prevValid,prevStage,prevSlowStage,prevSlowMs,hfCount,hfPC,hfLR,hfCFSR,
//        uptimeS,loopMaxMs,slowStage,slowMs,slowCount,ramFreeGap,heapUsed,obx,ram,
//        txDrops,rxCrcErr,espResets,espHbAgeMs,framSwErr,faults,bootCount
void sendDiag() {
#if STM_RESET_DIAG
  linkSendf("SDIAG,%02lX,%u,%u,%u,%u,%u,%08lX,%08lX,%08lX,%lu,%lu,%u,%u,%lu,%lu,%lu,%u,%u,%lu,%lu,%lu,%lu,%lu,%04X,%lu",
            (unsigned long)resetFlags, dgPrevValid ? 1u : 0u, (unsigned)dgPrevStage, (unsigned)dgPrevSlowStage,
            (unsigned)dgPrevSlowMs, (unsigned)dgHfCount, (unsigned long)dgHfPc, (unsigned long)dgHfLr,
            (unsigned long)dgHfCfsr, (unsigned long)(millis() / 1000UL), (unsigned long)dgLoopMaxMs,
            (unsigned)dgSlowStage, (unsigned)dgSlowMs, (unsigned long)dgSlowCount,
            (unsigned long)diagRamFreeGap(), (unsigned long)diagHeapUsed(),
            (unsigned)obxCount, (unsigned)ramCount, (unsigned long)linkTxDrops, (unsigned long)linkCrcErrors,
            (unsigned long)espResetCount, (unsigned long)(millis() - lastEspHbMs),
            (unsigned long)framSwErrors, (unsigned)faults, (unsigned long)bootCount);
#endif
}

// ---------------- Event creation (PDF offline storage architecture) --------
//  event -> persistent seq -> FRAM outbox (or aggregate) -> state checkpoint -> UART
EventRec makeRec(uint8_t type, int prodCount, int altCount, unsigned long irActiveDur,
                 unsigned long cycTime, const char* reasonCode, uint8_t flags) {
  sessEnsureCurrent();                       // F3: login chhara hole UNKNOWN session
  EventRec r;
  memset(&r, 0, sizeof(r));
  r.seq = ++eventSeq;
  r.type = type;
  r.ts = rtcNowEpoch();
  r.ms = millis();
  r.irDur = irActiveDur;
  r.cyc = cycTime;
  r.tp = totalProduction;
  r.ta = totalAlter;
  r.ac = actualProduction;
  r.sessionId = currentSessionId;
  r.prod = (uint16_t)prodCount;
  r.alt = (uint16_t)altCount;
  r.reason = reasonIndexOf(reasonCode);
  r.flags = flags;
  if (ctx.pad[0] != 0) r.flags |= EVF_PROVISIONAL;
  if (!sessIsAssigned(currentSessionId)) r.flags |= EVF_CREATED_UNASSIGNED;
  r.profile = MACHINE_PROFILE;
  r.epoch = seqEpoch;
  r.lifeP = lifeProduction;
  r.lifeA = lifeAlter;
  return r;
}

void sendEvFrame(const EventRec& r);
void noteImmediateSend(const EventRec& r);

// return true = FRAM/RAM outbox-e ache (ESP-e sathe sathe pathano jay)
bool storeRec(EventRec& r) {
  if (!framOk || !smuFormatReady || smuJournalWriteUncertain || smuMetadataRecoveryFault) {
    faults|=FAULT_FRAM_WRITE;return false;
  }
  if (aggActive() || !obxPush(r)) {
    // Old aggregate preserves coarse totals but NOT per-event identity. Do not
    // silently aggregate events in the new critical identity journal.
    faults|=FAULT_OUTBOX_FULL;return false;
  }
  return true;
}

// Owner rule: FRAM-e save + SATHE SATHE ESP32-e (SD log + DB). TX ring-e jayga na thakle
// head hoye serviceOutbox() theke jabe.
void sendNow(const EventRec& r) {
  if (txUsed() < LINK_TX_RING - 800) { sendEvFrame(r); noteImmediateSend(r); }
}

void queueEvent(uint8_t type, int prodCount, int altCount, unsigned long irActiveDur,
                unsigned long cycTime, const char* reasonCode, uint8_t flags) {
  aggTryFlush();                                   // jayga thakle age aggregate (sequence order)
  EventRec r = makeRec(type, prodCount, altCount, irActiveDur, cycTime, reasonCode, flags);
  bool inOutbox = storeRec(r);   // 1) event record (FRAM)
  saveState();                   // 2) legacy counter state checkpoint
  if (inOutbox && !smuCheckpointCommit(smuLastCustodySeq))
    faults|=FAULT_STATE_RECOVERY;
  if (inOutbox) sendNow(r);      // 3) sathe sathe ESP32
  DBG_PRINTF("[EVENT] seq=%lu type=%u prod=%d alt=%d reason=%s outbox=%u\n",
             (unsigned long)r.seq, type, prodCount, altCount, reasonText(r.reason), (unsigned)outboxTotal());
}

// Legacy call signature (alter / reason / production)
void queueProductionData(int prodCount, int altCount, unsigned long irActiveDur,
                         unsigned long cycTime, const char* reasonCode) {
  uint8_t type = prodCount > 0 ? EV_PRODUCTION : (altCount > 0 ? EV_ALTER : EV_REASON);
  queueEvent(type, prodCount, altCount, irActiveDur, cycTime, reasonCode, 0);
}

// ---------------- Outbox transmit / DB ACK ----------------
// Head record: microSD proof-bearing CUSTODY na asa porjonto 3s retry.
// Head-er pore-r record gulo creation-er somoy ekbar pathano hoy (SD log + DB POST);
// tader DELIVERED age ashle "early" list-e rakha hoy, head hole sathe sathe muche.
#define EARLY_N   96
#define RECENT_TX 16
struct SeqKey { uint32_t seq; uint32_t epoch; };
SeqKey earlyDelivered[EARLY_N];
uint8_t earlyCount = 0;
struct TxNote { uint32_t seq; uint32_t epoch; unsigned long ms; };
TxNote recentTx[RECENT_TX];
uint8_t recentTxHead = 0;

bool headKnown = false;
uint32_t headSeq = 0, headEpoch = 0;
unsigned long lastHeadSendMs = 0;

static inline bool espAlive() { return (millis() - lastEspHbMs) < 3000UL; }

// EV frame: record + session metadata (F3: ESP32-r nijer session table nai)
static char evBuf[820];
static char encOp[100], encLoc[100], encStyle[148], encProc[130], encMech[100], encMach[100];

void sendEvFrame(const EventRec& r) {
  uint8_t xf = 0;
  const SessSlot* m = nullptr;
  // Ordinary no-operator production stays HELD until same-line login,
  // line change (UNKNOWN) or 03:00 release. Physical provisional RFID
  // sessions keep their existing PENDING_VALIDATION handling unchanged.
  if ((r.flags & EVF_CREATED_UNASSIGNED) && !(r.flags & EVF_PROVISIONAL)) {
    m = sessResolve(r.sessionId, xf);
    if (!m) xf = EVX_PROVISIONAL; // missing history: never invent attribution
  } else {
    int immutableIndex = sessFind(r.sessionId);
    if (immutableIndex >= 0) m = &sess[immutableIndex];
    if (r.flags & EVF_CREATED_UNASSIGNED) xf = EVX_PROVISIONAL;
  }
  const char* mech = "";
  uint32_t cyc = r.cyc;
  if (r.type == EV_MAINT_ON || r.type == EV_PROD_ON) {
    int k = sessFind(r.cyc);
    mech = k >= 0 ? sess[k].op : "UNKNOWN_TECH";
    cyc = 0;
  }
  encText(encOp, sizeof(encOp), m ? m->op : "UNKNOWN");
  encText(encLoc, sizeof(encLoc), m ? m->loc : "NONE");
  encText(encStyle, sizeof(encStyle), m ? m->style : "NONE");
  encText(encProc, sizeof(encProc), m ? m->proc : "NONE");
  encText(encMech, sizeof(encMech), mech);
  long smvMilli = m ? (long)(m->smv * 1000.0f + 0.5f) : 0;
  int div = m ? m->div : 1;
  unsigned fl = (unsigned)((r.flags & (EVF_DUR_NOT_FINAL | EVF_RECOVERED)) | xf |
                ((r.flags & EVF_PROVISIONAL) ? EVX_PROVISIONAL : 0));
  snprintf(evBuf, sizeof(evBuf), "EV,%lu,%u,%lu,%lu,%u,%u,%lu,%lu,%s,%ld,%ld,%ld,%lu,%u,%08lX,%s,%s,%s,%s,%ld,%d,%s,%08lX",
           (unsigned long)r.seq, (unsigned)r.type, (unsigned long)r.ts, (unsigned long)r.ms,
           (unsigned)r.prod, (unsigned)r.alt, (unsigned long)r.irDur, (unsigned long)cyc,
           reasonText(r.reason), (long)r.tp, (long)r.ta, (long)r.ac,
           (unsigned long)r.sessionId, fl, (unsigned long)r.epoch,
           encOp, encLoc, encStyle, encProc, smvMilli, div, encMech,
           (unsigned long)smuCrc32((const uint8_t*)&r,sizeof(r)));
  linkSend(evBuf);
}

// CTX frame: current session (ESP32 OLED + server recovery decision)
void sendCtx() {
  if (txUsed() > LINK_TX_RING - 800) return;            // porer loop-e (ctxDirty thake)
  const SessSlot* c = sessCur();
  int tk = sessFind(ctx.techSid);
  encText(encOp, sizeof(encOp), (c && c->assigned) ? c->op : "UNKNOWN");
  encText(encLoc, sizeof(encLoc), c ? c->loc : "NONE");
  encText(encStyle, sizeof(encStyle), c ? c->style : "NONE");
  encText(encProc, sizeof(encProc), c ? c->proc : "NONE");
  encText(encMech, sizeof(encMech), tk >= 0 ? sess[tk].op : "NONE");
  encText(encMach, sizeof(encMach), ctx.machineId);
  bool todayLogin = operatorReady && ctx.loginDay != 0 && ctx.loginDay == prodDay;
  snprintf(evBuf, sizeof(evBuf), "CTX,%lu,%d,%d,%d,%d,%d,%lu,%lu,%ld,%d,%s,%s,%s,%s,%s,%d,%s,%s",
           (unsigned long)currentSessionId, operatorReady ? 1 : 0, isMaintenanceMode ? 1 : 0,
           (c && c->assigned) ? 1 : 0, ctx.recPunch ? 1 : 0, todayLogin ? 1 : 0,
           (unsigned long)heldCount(), (unsigned long)prodDay, (long)(activeSmv * 1000.0 + 0.5), activeDivisor,
           encOp, encLoc, encStyle, encProc, encMech, (int)(ctx.pad[0] != 0), ctx.opRfid, encMach);
  linkSend(evBuf);
  ctxDirty = false;
  lastCtxMs = millis();
}

void noteImmediateSend(const EventRec& r) {
  recentTx[recentTxHead] = { r.seq, r.epoch, millis() };
  recentTxHead = (uint8_t)((recentTxHead + 1) % RECENT_TX);
}

static bool recentTxLookup(uint32_t seq, uint32_t epoch, unsigned long& ms) {
  for (int i = 0; i < RECENT_TX; i++)
    if (recentTx[i].seq == seq && recentTx[i].epoch == epoch && seq != 0) { ms = recentTx[i].ms; return true; }
  return false;
}

static int earlyFind(uint32_t seq, uint32_t epoch) {
  for (int i = 0; i < earlyCount; i++) if (earlyDelivered[i].seq == seq && earlyDelivered[i].epoch == epoch) return i;
  return -1;
}
static void earlyRemove(int i) { earlyDelivered[i] = earlyDelivered[--earlyCount]; }

// head DB-te pouchale pop; tarpor je gulo age-i DELIVERED peyechilo segulo-o pop
static void popDeliveredChain(const EventRec& head) {
  if (!obxPop(head)) return;
  headKnown = false;
  EventRec r;
  for (int guard = 0; guard < EARLY_N && earlyCount > 0; guard++) {
    if (!obxPeek(r)) break;
    int k = earlyFind(r.seq, r.epoch);
    if (k < 0) break;
    if (!obxPop(r)) break;
    earlyRemove(k);
  }
}

// Per-slot non-FIFO TRANSMISSION and physical retirement via NF bitmap.
// The 96-byte journal schema and event identity/DB proof remain unchanged.
// An unreadable slot is retained; it cannot prevent independent valid events.
void serviceOutbox() {
  aggTryFlush();
  if (outboxTotal() == 0) { headKnown=false; earlyCount=0; return; }
  if (espProto != 0 && espProto != PROTO_VER) return;
  // Legacy chain applies only to the old FIFO, not the independent slot ledger.
  EventRec head;
  if (!nfMode && obxPeek(head) && earlyFind(head.seq,head.epoch)>=0) {
    earlyRemove(earlyFind(head.seq,head.epoch));
    popDeliveredChain(head);
    return;
  }
  static uint16_t cursor=0;
  static unsigned long lastScanMs=0;
  if ((uint32_t)(millis()-lastScanMs) < REPLAY_INTERVAL_MS) return;
  if (txUsed() > LINK_TX_RING-800) return;
  lastScanMs=millis();
  uint16_t count=nfMode?OBX_CAP:obxCount;
  if (!count) return;
  if (cursor >= count) cursor=0;
  uint16_t tail=(uint16_t)((obxHead+OBX_CAP-obxCount)%OBX_CAP);
  uint16_t slot=nfMode?cursor:(uint16_t)((tail+cursor)%OBX_CAP);
  cursor=(uint16_t)((cursor+1)%count);
  if(nfMode && !nfHas(slot)) return;
  EventRec r;
  if (!obxRead(slot,r) || !recValid(r)) {
    faults |= FAULT_RECORD_CORRUPT;
    // Isolate this record for later verified recovery; DO NOT delete it.
    // Diagnosis is rate limited to protect link and watchdog.
    static unsigned long lastBadReport=0;
    if ((uint32_t)(millis()-lastBadReport)>5000UL) {
      DBG_PRINTF("[OUTBOX ISOLATED] slot=%u cursor=%u",(unsigned)slot,(unsigned)cursor);
      lastBadReport=millis();
    }
    return;
  }
  if (nfMode) nfSlotSeq[slot]=r.seq;   // SLOTMAP: verified read
  if (earlyFind(r.seq,r.epoch)>=0) return; // already DB-ACKed; awaiting ordered reclaim
  unsigned long prior=0;
  if (recentTxLookup(r.seq,r.epoch,prior) &&
      (uint32_t)(millis()-prior)<EV_DB_ACK_TIMEOUT_MS) return;
  sendEvFrame(r);
  noteImmediateSend(r);
}

// Replay step (REPLAY_INTERVAL_MS por por ekta record; HELD record-o jay — ESP32 shudhu SD log kore)
void serviceReplay() {
  if (!replayActive) return;
  if (replayLeft == 0 || obxCount == 0) { replayActive = false; return; }
  if (!espAlive() || espHold || (espProto != 0 && espProto != PROTO_VER)) return;
  unsigned long now = millis();
  if (now - replayLastMs < REPLAY_INTERVAL_MS) return;
  if (txUsed() > LINK_TX_RING - 800) return;
  replayLastMs = now;
  uint16_t pos = replayPos;
  replayPos = (uint16_t)((replayPos + 1) % OBX_CAP);
  replayLeft--;
  EventRec r;
  if(nfMode && !nfHas(pos)) return;
  if (!obxRead(pos, r) || !recValid(r)) return;
  if (nfMode) nfSlotSeq[pos]=r.seq;    // SLOTMAP: verified read
  sendEvFrame(r);
  noteImmediateSend(r);
}

// FRAM retirement only on a proof-bearing, DB-VERIFIED DBCOMMIT UART frame.
// SD-only CUSTODY / DELIVERED / STORED / RX / NAK never authorize retirement.
// hasEpoch: require exact (seq, epoch), and immutable raw 58-byte record CRC32.
// Keep corrupted historical journal slots intact; retire only separately proven
// identities, never treating a corrupted older slot as successfully DB committed.
// No firmware path formats/erases FRAM as a side effect of this ACK.
static bool smuFindAckedEvent(uint32_t seq,uint32_t epoch,uint32_t expectedCrc,bool* foundIdentity,uint16_t* matchedSlot) {
  if (foundIdentity) *foundIdentity=false;
  if (matchedSlot) *matchedSlot=OBX_CAP;
  if (!framOk || !smuFormatReady || !expectedCrc) {
    DBG_PRINTLN("[CF] NOT_READY"); return false;
  }
  linkAckWork++;
  if (nfMode) {                        // SLOTMAP fast path: O(1) FRAM read
    bool allKnown = true;
    for (uint16_t i=0;i<OBX_CAP;i++) {
      if (!nfHas(i)) continue;
      if (nfSlotSeq[i]==0) { allKnown=false; continue; }
      if (nfSlotSeq[i]!=seq) continue;
      wdtKick();
      EventRec r;
      if (obxRead(i,r) && recValid(r) && r.seq==seq && r.epoch==epoch) {
        if (foundIdentity) *foundIdentity=true;
        if (matchedSlot) *matchedSlot=i;
        return smuCrc32((const uint8_t*)&r,sizeof(r))==expectedCrc;
      }
      nfSlotSeq[i]=0; allKnown=false;  // map bhul/stale: niche full scan
    }
    if (allKnown) return false;        // FRAM-e nei (age-i retire hoyeche) -> scan na
  }
  // Newest-first proof lookup: recent valid records are checked before
  // old damaged journal slots. This does NOT change the outbox or retire data.
  for (uint16_t i=0;i<(nfMode?OBX_CAP:obxCount);i++) {
    uint16_t idx=nfMode?i:(uint16_t)((obxHead+OBX_CAP-1u-i)%OBX_CAP);
    if(nfMode && !nfHas(idx)) continue;
    // RESET-FIX: ager reload shudhu nfMode-e ar i%8==0 hole; legacy mode-e KOKHONO na.
    // Outbox ~130+ record hole ei scan 2 s IWDG par kore STM32 reset korto.
    wdtKick();
    // RESET-FIX: fast pre-filter — 96 B-er bodole age 16 B header (seq/epoch) pora.
    // Header valid kintu identity mile na -> eta target noy, skip (5x kom I2C somoy).
    // Header pora na gele / header bhanga hole niche ager full-verify path (corrupt report soho).
    {
      uint8_t h[16];
      if (framReadBytes(obxAddr(idx),h,sizeof(h)) && h[0]=='E' && h[1]=='V' &&
          h[2]==SMU_EV_VERSION && h[4]==sizeof(EventRec) &&
          (leGet32(h+8)!=seq || leGet32(h+12)!=epoch)) continue;
    }
    EventRec r;
    if (!obxRead(idx,r) || !recValid(r)) {
      DBG_PRINTF("[CF] BAD_RECORD idx=%u",(unsigned)idx);
      faults|=FAULT_RECORD_CORRUPT;
      // Skip ONLY for searching an unrelated ACK proof. Do not alter the
      // journal head/count, counters, replay, SD or retirement permissions.
      continue;
    }
    if (nfMode) nfSlotSeq[idx]=r.seq;  // SLOTMAP: verified read
    if (r.seq==seq && r.epoch==epoch) {
      if (foundIdentity) *foundIdentity=true;
      if (matchedSlot) *matchedSlot=idx;
      uint32_t local=smuCrc32((const uint8_t*)&r,sizeof(r));
      if (local!=expectedCrc)
        DBG_PRINTF("[CF] PROOF seq=%lu local=%08lX ack=%08lX",
                   (unsigned long)seq,(unsigned long)local,(unsigned long)expectedCrc);
      return local==expectedCrc;
    }
  }
  DBG_PRINTF("[CF] NOT_FOUND seq=%lu",(unsigned long)seq);
  return false;
}
void onEventAck(const char* kind,uint32_t seq,bool hasEpoch,uint32_t epoch,
                bool hasProof,uint32_t proof) {
  const bool dbCommit = strcmp(kind,"DBCOMMIT") == 0;
  if (!dbCommit && strcmp(kind,"CUSTODY") != 0) return;
  if (!hasEpoch || !hasProof) return;
  // ENABLE_SD_CUSTODY_RECLAIM 0 hole: CUSTODY-te scan-i hoy na (LOG-FIX 2026-11-02b, 720 ms bachay).
  // 1 hole (default): CUSTODY ba DBCOMMIT je kono ekta -> scan + retire. Outbox choto thake, scan druto.
#if !ENABLE_SD_CUSTODY_RECLAIM
  if (!dbCommit) return;
#endif
  diagStage(DG_ACK_SCAN);              // RESET-FIX diag: FRAM ACK scan (handleLine-e LINK_POLL-e ferot)
  DBG_PRINTF("[ACK RX] kind=%s seq=%lu ep=%08lX\n",kind,(unsigned long)seq,(unsigned long)epoch);
  bool foundIdentity=false;
  uint16_t matchedSlot=OBX_CAP;
  if (!smuFindAckedEvent(seq,epoch,proof,&foundIdentity,&matchedSlot)) {
    // Duplicate late UART ACK after successful retirement is normal: the
    // already-popped identity no longer exists. Only a MATCHED identity with
    // a bad CRC32 signals a forged/damaged proof; do not invent corruption.
    if (foundIdentity) faults|=FAULT_RECORD_CORRUPT;
    return;
  }
  // RETIRE-SD-OR-DB: CUSTODY (SD .evt CRC32 + identity verified) = DBCOMMIT-er moto retire.
  // ESP32 SD queue theke pore DB-te pathabe; FRAM ar oi event dhore rakhe na.
#if ENABLE_DB_COMMIT_RECLAIM || ENABLE_SD_CUSTODY_RECLAIM
  if (smuMetadataRecoveryFault || smuJournalWriteUncertain) return;
  DBG_PRINTF("[DB RETIRE ACK] seq=%lu proof=OK\n",(unsigned long)seq);
  if(nfMode) {
    EventRec proved;
    if(matchedSlot<OBX_CAP && nfHas(matchedSlot) && obxRead(matchedSlot,proved) &&
       recValid(proved) && proved.seq==seq && proved.epoch==epoch &&
       smuCrc32((const uint8_t*)&proved,sizeof(proved))==proof) {
      (void)nfRetire(matchedSlot,proved);
    }
    return;
  }
  EventRec head;
  if (!obxPeek(head)) return;
  if (head.seq==seq && head.epoch==epoch) {
    popDeliveredChain(head);return;
  }
  if (earlyFind(seq,epoch)<0 && earlyCount<EARLY_N)
    earlyDelivered[earlyCount++]={seq,epoch};
#else
  (void)proof; // explicitly disabled DB-retirement build
#endif
}

// ---------------- Reliable commands (id-based, idempotent) ----------------
// Last 4 command ids + reply (retry hole same reply, command abar execute hoy na)
#define CMD_HIST 4
uint32_t cmdHistId[CMD_HIST] = {0, 0, 0, 0};
char cmdHistReply[CMD_HIST][48];
uint8_t cmdHistHead = 0;

bool cmdIsDuplicate(uint32_t id) {
  if (id == 0) return false;
  for (int i = 0; i < CMD_HIST; i++) {
    if (cmdHistId[i] == id) { linkSend(cmdHistReply[i]); return true; }
  }
  return false;
}

void cmdReply(uint32_t id, const char* fmt, ...) {
  uint8_t k = cmdHistHead;
  cmdHistHead = (uint8_t)((cmdHistHead + 1) % CMD_HIST);
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(cmdHistReply[k], sizeof(cmdHistReply[k]), fmt, ap);
  va_end(ap);
  cmdHistId[k] = id;
  linkSend(cmdHistReply[k]);
}

void resetPerformanceSession() {
  for (int i = 0; i < 5; i++) productionCycleTimes[i] = 0;
  cycleIndex = 0;
  cycleCount = 0;
  lastProductionTimestamp = 0;
  lastProductionTime = 0;
  lastSwitchPress = 0;
  btn4PressCount = 0;
  btn4FirstPressTime = 0;
  stopAllRelays();
}

void handleCommand(char** tok, int n) {
  // RECOVERY BENCH: address-limited, read-only 32-byte FRAM chunk export.
  // No metadata write, formatting, ACK, or counter modification.
  if (n >= 2 && strcmp(tok[0],"FRD") == 0) {
    char* end = nullptr;
    unsigned long addr = strtoul(tok[1], &end, 10);
    if (!end || *end || addr > 32768UL-32UL || !i2cAck(FRAM_I2C_ADDR)) {
      linkSendf("FRERR,%lu", addr); return;
    }
    uint8_t raw[32];
    if (!framReadBytesAt(FRAM_I2C_ADDR,(uint16_t)addr,raw,sizeof(raw))) {
      linkSendf("FRERR,%lu",addr); return;
    }
    const char* hexdigits="0123456789ABCDEF";
    char hex[65];
    for (unsigned i=0;i<sizeof(raw);i++) {
      hex[i*2]=hexdigits[raw[i]>>4];hex[i*2+1]=hexdigits[raw[i]&15];
    }
    hex[64]=0;
    linkSendf("FR,%lu,%s",addr,hex);
    return;
  }
  const char* cmd = tok[0];

  if ((!strcmp(cmd, "RX") || !strcmp(cmd, "STORED") || !strcmp(cmd, "CUSTODY") || !strcmp(cmd, "DBCOMMIT") || !strcmp(cmd, "DELIVERED")) && n >= 2) {
    onEventAck(cmd,strtoul(tok[1],NULL,10),n>=3,
               n>=3?strtoul(tok[2],NULL,16):0,n>=4,
               n>=4?strtoul(tok[3],NULL,16):0);
  } else if (!strcmp(cmd, "NAK") && n >= 2) {
    onEventAck(cmd,strtoul(tok[1],NULL,10),n>=4,n>=4?strtoul(tok[3],NULL,16):0,false,0);
  } else if (!strcmp(cmd, "EHB") && n >= 7) {
    espProto = atoi(tok[1]);
    espWifi = atoi(tok[2]) != 0;
    espMqtt = atoi(tok[3]) != 0;
    espServer = atoi(tok[4]) != 0;
    espPending = strtoul(tok[5], NULL, 10);
    espHold = atoi(tok[6]) != 0;
    if (espProto != PROTO_VER) faults |= FAULT_PROTO_MISMATCH; else faults &= ~FAULT_PROTO_MISMATCH;
  } else if (!strcmp(cmd, "HELLO") && n >= 2) {
    espProto = atoi(tok[1]);
    if (espProto != PROTO_VER) faults |= FAULT_PROTO_MISMATCH; else faults &= ~FAULT_PROTO_MISMATCH;
    sendBoot();
    sendDiag();                        // RESET-FIX: ESP32 reboot-er por-o STM32 reset karon dekhabe
    ctxDirty = true;
    replayStart();                     // ESP32 reboot: RAM DB queue gechhe -> outbox abar pathao
  } else if (!strcmp(cmd, "LOGIN") && n >= 9) {
    // Operator card (legacy: ESP session set + LOGIN event + SESSION/ESP.restart).
    // F3: notun assigned session; sob HELD (UNKNOWN) session ei operator-er -> DB-te jabe.
    uint32_t id = strtoul(tok[8], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    if (isMaintenanceMode) { cmdReply(id, "CMDNAK,%lu,LOGIN,MAINT", (unsigned long)id); return; }
    for (int k = 1; k <= 5; k++) decText(tok[k]);
    // ACK may be lost after a durable LOGIN commit. A retry with a NEW
    // command ID must not create a second session/LOGIN/WORK_START.
    if (operatorReady && ctx.pad[0]==0 && ctx.opRfid[0] &&
        strcmp(ctx.opRfid,tok[1])==0 && ctx.loginDay==prodDay) {
      cmdReply(id,"CMDOK,%lu,LOGIN",(unsigned long)id);
      return;
    }
    double smv = atol(tok[6]) / 1000.0;
    int div = atoi(tok[7]);
    profileFlushPending("operator login");
    uint32_t sid = sessCreate(0, true, tok[2], tok[3], tok[4], tok[5], smv, div);
    currentSessionId = sid;
    operatorReady = true;
    activeSmv = smv;
    activeDivisor = div;
    strCopy(ctx.opRfid, sizeof(ctx.opRfid), tok[1]);
    ctx.pad[0] = 0;                     // verified login, unlike PLOGIN
    ctx.pad[2] = 0;
    ctx.recPunch = 1;                  // ESP restart-er por server state (RESTORE)
    ctx.loginDay = prodDay;
    // Only this line/day's pre-login events belong to the punching operator.
    uint32_t moved = sessAssignAll(sid, tok[3]);
    ctxSave();
    saveState();
    queueEvent(EV_LOGIN, 0, 0, 0, 0, "", 0);
    queueEvent(EV_WORK_START, 0, 0, 0, 0, "", 0); // new immutable work-start event
    resetPerformanceSession();         // legacy SESSION (ESP.restart equivalent)
    profileReset();
    loginSinceBoot = true;
    replayStart();
    DBG_PRINTF("[LOGIN] %s session %lu, %lu UNKNOWN event -> operator\n", tok[2], (unsigned long)sid, (unsigned long)moved);
    (void)moved;
    cmdReply(id, "CMDOK,%lu,LOGIN", (unsigned long)id);
  } else if (!strcmp(cmd, "PLOGIN") && n >= 4) {
    // OFFLINE CARD: any well-formed physical RDM6300 token may start a *provisional*
    // operator work session. It is NOT an authorization or assignment assertion.
    // Save raw token + unknown metadata in STM32 FRAM. No database-derived data invented.
    uint32_t id = strtoul(tok[3], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    decText(tok[1]); decText(tok[2]);
    if (strlen(tok[1]) != 10 || strspn(tok[1], "0123456789ABCDEF") != 10 ||
        strlen(tok[2]) == 0 || strlen(tok[2]) >= sizeof(ctx.machineId) ||
        !framOk || isMaintenanceMode || obxCount + 1 >= OBX_CAP) {
      cmdReply(id, "CMDNAK,%lu,PLOGIN,NOT_DURABLE_OR_MODE", (unsigned long)id);
      return;
    }
    // Ensure that an earlier provisional command was not already completed.
    if (operatorReady && ctx.pad[0] && strcmp(ctx.opRfid, tok[1]) == 0 && strcmp(ctx.machineId, tok[2]) == 0) {
      if (ctx.pad[2]) cmdReply(id,"CMDOK,%lu,PLOGIN",(unsigned long)id);
      else cmdReply(id,"CMDNAK,%lu,PLOGIN,RECOVERY_NEEDED",(unsigned long)id);
      return;
    }
    profileFlushPending("provisional operator login");
    uint32_t sid = sessCreate(0, true, tok[1], "UNKNOWN", "UNKNOWN", "UNKNOWN", 0.0, 0);
    if (!sid) { cmdReply(id, "CMDNAK,%lu,PLOGIN,SESSION_WRITE", (unsigned long)id); return; }
    currentSessionId = sid;
    operatorReady = true;
    activeSmv = 0.0;
    activeDivisor = 1; // safe arithmetic default, NOT a server-assigned divisor
    strCopy(ctx.opRfid, sizeof(ctx.opRfid), tok[1]);
    strCopy(ctx.machineId, sizeof(ctx.machineId), tok[2]);
    ctx.pad[0] = 1;  // PENDING_VALIDATION state (CtxRec CRC-backed)
    ctx.pad[1] = 0;  // current lookup not yet recorded
    ctx.pad[2] = 0;  // WORK_START not committed yet
    ctx.recPunch = 0; // never RESTORE server counters over provisional local history
    ctx.loginDay = prodDay;
    uint32_t beforeCtxGen = ctxGen, beforePersistGen = persistGen;
    ctxSave();
    saveState();
    if (ctxGen == beforeCtxGen || persistGen == beforePersistGen) {
      cmdReply(id,"CMDNAK,%lu,PLOGIN,CTX_NOT_DURABLE",(unsigned long)id);
      return;
    }
    // Exactly one immutable event: type WORK_START, status PENDING_VALIDATION.
    // This single event uniquely records both requirements at original punch time.
    EventRec r = makeRec(EV_WORK_START, 0, 0, 0, 0, "", EVF_PROVISIONAL);
    if (!obxPush(r)) {
      faults |= FAULT_FRAM_WRITE;
      cmdReply(id, "CMDNAK,%lu,PLOGIN,EVENT_COMMIT", (unsigned long)id);
      return;
    }
    beforePersistGen = persistGen;
    saveState();
    if (persistGen == beforePersistGen) {
      cmdReply(id,"CMDNAK,%lu,PLOGIN,EVENT_STATE_UNCERTAIN",(unsigned long)id);
      return;
    }
    // Final command completion marker for retry. A/B CRC-protected.
    // Interrupted between event commit and marker still needs boot journal scan.
    beforeCtxGen = ctxGen;
    ctx.pad[2] = 1;
    ctxSave();
    if (ctxGen == beforeCtxGen) {
      cmdReply(id,"CMDNAK,%lu,PLOGIN,COMPLETION_UNCERTAIN",(unsigned long)id);
      return;
    }
    resetPerformanceSession();
    profileReset();
    loginSinceBoot = true;
    ctxDirty = true;
    sendNow(r);
    replayStart();
    DBG_PRINTF("[RFID] PLOGIN provisional WORK_START seq=%lu session=%lu card=%s ts=%lu\n",
      (unsigned long)r.seq, (unsigned long)sid, tok[1], (unsigned long)r.ts);
    cmdReply(id, "CMDOK,%lu,PLOGIN", (unsigned long)id);
  } else if (!strcmp(cmd, "PRESOLVE") && n >= 9) {
    // Server CURRENT operator/assignment lookup; historical effective-time proof
    // requires a backend contract and stays pending on the earlier immutable events.
    uint32_t id = strtoul(tok[8], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    for (int k=1;k<=5;k++) decText(tok[k]);
    if (!framOk || !operatorReady || !ctx.pad[0] || strcmp(ctx.opRfid,tok[1]) != 0 ||
        !tok[2][0] || atol(tok[6]) <= 0 || atoi(tok[7]) <= 0 || obxCount+1>=OBX_CAP) {
      cmdReply(id,"CMDNAK,%lu,PRESOLVE,CONTEXT_OR_DATA",(unsigned long)id);
      return;
    }
    uint32_t earlierSession = currentSessionId;
    const uint32_t newSid = sessCreate(0,true,tok[2],tok[3],tok[4],tok[5],
                                      atol(tok[6])/1000.0,atoi(tok[7]));
    if (!newSid) {
      cmdReply(id,"CMDNAK,%lu,PRESOLVE,SESSION_WRITE",(unsigned long)id);
      return;
    }
    // The verification marker refers to the ORIGINAL provisional session.
    // No mutation of the original WORK_START or production event.
    currentSessionId = newSid;
    activeSmv = atol(tok[6])/1000.0;
    activeDivisor = atoi(tok[7]);
    ctx.pad[0] = 0;
    ctx.pad[1] = 1; // current server lookup complete; HISTORICAL remains unresolved
    ctx.recPunch = 0;
    uint32_t cg = ctxGen, pg = persistGen;
    ctxSave();
    saveState();
    if (cg == ctxGen || pg == persistGen) {
      cmdReply(id,"CMDNAK,%lu,PRESOLVE,CTX_NOT_DURABLE",(unsigned long)id);
      return;
    }
    EventRec r = makeRec(EV_CURRENT_LOOKUP,0,0,0,earlierSession,"", EVF_PROVISIONAL);
    if (!obxPush(r)) {
      cmdReply(id,"CMDNAK,%lu,PRESOLVE,EVENT_COMMIT",(unsigned long)id);
      return;
    }
    pg = persistGen; saveState();
    if (pg == persistGen) {
      cmdReply(id,"CMDNAK,%lu,PRESOLVE,EVENT_STATE_UNCERTAIN",(unsigned long)id);
      return;
    }
    sendNow(r);
    ctxDirty=true;
    DBG_PRINTF("[RFID] CURRENT lookup session %lu -> %lu, original immutable. Historic pending.\n",
      (unsigned long)earlierSession,(unsigned long)newSid);
    cmdReply(id,"CMDOK,%lu,PRESOLVE",(unsigned long)id);
  } else if (!strcmp(cmd, "MAINT") && n >= 3) {
    uint32_t id = strtoul(tok[n - 1], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    bool on = atoi(tok[1]) != 0;
    if (on && n >= 5) {                // technician card
      decText(tok[2]); decText(tok[3]);
      profileFlushPending("maintenance on");
      int k = sessFind(ctx.techSid);
      if (k < 0 || strcmp(sess[k].op, tok[2]) != 0) ctx.techSid = sessCreate(1, true, tok[2], "", "", "", 0.0, 1);
      strCopy(ctx.techRfid, sizeof(ctx.techRfid), tok[3]);
      isMaintenanceMode = true;
      ctxSave();
      saveState();
      queueEvent(EV_MAINT_ON, 0, 0, 0, ctx.techSid, "", 0);
      cmdReply(id, "CMDOK,%lu,MAINT", (unsigned long)id);
    } else if (!on) {                  // operator card in maintenance -> production mode
      uint32_t t = ctx.techSid;
      isMaintenanceMode = false;
      ctx.techSid = 0;
      ctx.techRfid[0] = 0;
      ctxSave();
      saveState();
      queueEvent(EV_PROD_ON, 0, 0, 0, t, "", 0);
      cmdReply(id, "CMDOK,%lu,MAINT", (unsigned long)id);
    } else {
      cmdReply(id, "CMDNAK,%lu,MAINT,ARGS", (unsigned long)id);
    }
  } else if (!strcmp(cmd, "LOCATION") && n >= 4) {
    // Legacy location-card rule: SESSION counters 0, operator logout, smv 0, divisor 1.
    // Pending/outbox/aggregate EVENT record gulo muche na (shudhu running counter reset).
    uint32_t id = strtoul(tok[3], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    decText(tok[1]); decText(tok[2]);
    char oldLine[sizeof(((SessSlot*)0)->loc)];
    const SessSlot* beforeLineChange = sessCur();
    strCopy(oldLine, sizeof(oldLine), beforeLineChange ? beforeLineChange->loc : "NONE");
    profileFlushPending("location reset");
    // Unassigned events on the departing line are released as UNKNOWN.
    uint32_t released = sessReleaseAll(oldLine);
    operatorReady = false;
    activeSmv = 0.0;
    activeDivisor = 1;
    totalProduction = 0;
    totalAlter = 0;
    actualProduction = 0;
    strCopy(ctx.locRfid, sizeof(ctx.locRfid), tok[1]);
    ctx.opRfid[0] = 0;
    ctx.pad[0] = 0;
    ctx.pad[2] = 0;
    currentSessionId = sessCreate(0, false, "UNKNOWN", tok[2], "NONE", "NONE", 0.0, 1);
    ctxSave();
    saveState();
    if (released) replayStart();  // send previous line's UNKNOWN events; DB ACK alone retires
    cmdReply(id, "CMDOK,%lu,LOCATION", (unsigned long)id);
  } else if (!strcmp(cmd, "RESTORE") && n >= 13) {
    // Server last-machine-state (card punch-er por). All-or-nothing: EKI production day,
    // STM32-e kono undelivered/pending/aggregate nai ebong eventSeq == expectSeq hole
    // metadata + counter duto-i apply; noile kichui na (ESP 10 s por abar).
    uint32_t id = strtoul(tok[12], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    if (ctx.pad[0]) { cmdReply(id, "CMDNAK,%lu,RESTORE,PROVISIONAL", (unsigned long)id); return; }
    uint32_t expectSeq = strtoul(tok[10], NULL, 10);
    uint32_t stDay = strtoul(tok[11], NULL, 10);
    if (stDay != prodDay) { cmdReply(id, "CMDNAK,%lu,RESTORE,DAY", (unsigned long)id); return; }
    if (outboxTotal() != 0 || aggActive() || profileHasPending() || eventSeq != expectSeq) {
      cmdReply(id, "CMDNAK,%lu,RESTORE,BUSY", (unsigned long)id);
      return;
    }
    for (int k = 1; k <= 4; k++) decText(tok[k]);
    double smv = atol(tok[5]) / 1000.0;
    int div = atoi(tok[6]);
    bool asg = tok[1][0] && strcmp(tok[1], "NONE") != 0 && strcmp(tok[1], "UNKNOWN") != 0;
    const SessSlot* c = sessCur();
    bool same = c && c->kind == 0 && (c->assigned != 0) == asg && !strcmp(c->op, asg ? tok[1] : "UNKNOWN") &&
                !strncmp(c->loc, tok[2], sizeof(c->loc) - 1) && !strncmp(c->style, tok[3], sizeof(c->style) - 1) &&
                !strncmp(c->proc, tok[4], sizeof(c->proc) - 1) && c->smv == (float)smv && c->div == div;
    if (!same) currentSessionId = sessCreate(0, asg, asg ? tok[1] : "UNKNOWN", tok[2], tok[3], tok[4], smv, div);
    operatorReady = asg;
    if (asg) strCopy(ctx.opRfid, sizeof(ctx.opRfid), "RESTORED");   // legacy activeOperatorRfid = "RESTORED"
    activeSmv = smv;
    activeDivisor = div;
    totalProduction = atol(tok[7]);
    totalAlter = atol(tok[8]);
    actualProduction = atol(tok[9]);
    ctx.recPunch = 0;
    ctxSave();
    saveState();
    cmdReply(id, "CMDOK,%lu,RESTORE", (unsigned long)id);
  } else if (!strcmp(cmd, "RECDONE") && n >= 2) {
    uint32_t id = strtoul(tok[1], NULL, 10);
    if (cmdIsDuplicate(id)) return;
    ctx.recPunch = 0;
    ctxSave();
    cmdReply(id, "CMDOK,%lu,RECDONE", (unsigned long)id);
  } else if (!strcmp(cmd, "TIME") && n >= 2) {
    rtcSetFromEsp(strtoul(tok[1], NULL, 10));
    if (sensingArmed) checkDailyReset("time set");
  } else if (!strcmp(cmd, "BEEP") && n >= 4) {
    beepRequest((uint16_t)atoi(tok[1]), (uint16_t)atoi(tok[2]), (uint8_t)atoi(tok[3]));
  }
}

char rxBuf[560];                        // F3: LOGIN frame-e name field
uint16_t rxLen = 0;

void handleLine(char* line) {
  if (line[0] != '$') return;
  char* star = strrchr(line, '*');
  if (!star || strlen(star) != 5) { linkCrcErrors++; return; }
  *star = 0;
  uint16_t rxCrc = (uint16_t)strtoul(star + 1, NULL, 16);
  char* body = line + 1;
  if (crc16((const uint8_t*)body, strlen(body)) != rxCrc) { linkCrcErrors++; return; }

  char* tok[24];
  int n = 0;
  char* save = NULL;
  char* p = strtok_r(body, ",", &save);
  while (p && n < 24) { tok[n++] = p; p = strtok_r(NULL, ",", &save); }
  if (n == 0) return;

  lastEspHbMs = millis();
  handleCommand(tok, n);
  if (dgStage != DG_LINK_POLL) diagStage(DG_LINK_POLL);   // RESET-FIX diag
}

void linkPoll() {
  int budget = 256;                        // bounded per loop
  linkAckWork = 0;
  while (budget-- > 0 && EspLink.available() && linkAckWork < 1) {   // ACK-LIMIT: loop-e max 1 FRAM ACK kaj (~0.2 s), baki porer loop-e -> sensing poll deri na
    char c = (char)EspLink.read();
    if (c == '$') {
      rxLen = 0;
      rxBuf[rxLen++] = c;
    } else if (c == '\n' || c == '\r') {
      if (rxLen > 0) { rxBuf[rxLen] = 0; handleLine(rxBuf); rxLen = 0; }
    } else if (rxLen > 0 && rxLen < sizeof(rxBuf) - 1) {
      rxBuf[rxLen++] = c;
    } else if (rxLen >= sizeof(rxBuf) - 1) {
      rxLen = 0;
      linkCrcErrors++;
    }
  }
}

// =============================================================================
// 15) COMMON OPERATOR INPUTS  (all 7 profiles — legacy semantics)
// =============================================================================
DebBtn btns[5] = {
  { PIN_BTN_RED,    HIGH, HIGH, 0 },
  { PIN_BTN_YELLOW, HIGH, HIGH, 0 },
  { PIN_BTN_GREEN,  HIGH, HIGH, 0 },
  { PIN_BTN_BLUE,   HIGH, HIGH, 0 },
  { PIN_BTN_BLACK,  HIGH, HIGH, 0 },
};

// -----------------------------------------------------------------------------
// BTN-ISR: 1 ms hardware-timer sampling + consecutive-count debounce.
//   Ager problem: buttonsUpdate() loop-e sample nito. FRAM software-I2C write-e
//   loop kayek sho ms block hole duto noise spike-er majher HIGH obostha dekha
//   jeto na -> "20 ms stable LOW" dhore phantom ALTER.
//   Ekhon: protiti 1 ms-e 5 button sample. Stable level bodlate BTN_CONFIRM_MS
//   sample TANA ulto level lagbe; majhe ekta-o stable-level sample counter 0 kore.
//   Loop block holeo ISR chalu thake, tai debounce somoy-er sathe thik thake.
//   btnPins[] uint32_t: DebBtn.pin-er type jai hok, PA0..PA4 (196..) truncate hoy na.
// -----------------------------------------------------------------------------
static const uint32_t btnPins[5] = { PIN_BTN_RED, PIN_BTN_YELLOW, PIN_BTN_GREEN,
                                     PIN_BTN_BLUE, PIN_BTN_BLACK };
volatile uint8_t  btnStableIsr[5] = { HIGH, HIGH, HIGH, HIGH, HIGH };  // legacy: LOW = pressed
volatile uint8_t  btnCnt[5]       = { 0, 0, 0, 0, 0 };
volatile uint32_t btnGlitch[5]    = { 0, 0, 0, 0, 0 };  // confirm-er age bhenge jaoa run = noise/bounce
static HardwareTimer* btnTimer = nullptr;

void btnTickISR() {
  for (int i = 0; i < 5; i++) {
    uint8_t raw = (digitalRead(btnPins[i]) == BTN_ACTIVE_LEVEL) ? LOW : HIGH;
    if (raw == btnStableIsr[i]) {
      if (btnCnt[i]) btnGlitch[i]++;        // spike chhilo, confirm hoy ni
      btnCnt[i] = 0;
    } else if (++btnCnt[i] >= BTN_CONFIRM_MS) {
      btnStableIsr[i] = raw;
      btnCnt[i] = 0;
    }
  }
}

// setup()-e button pinMode-er por call (IWatchdog-er age)
void buttonsTimerBegin() {
  for (int i = 0; i < 5; i++) {               // boot-e current level-kei stable dhori (phantom edge na)
    btnStableIsr[i] = (digitalRead(btnPins[i]) == BTN_ACTIVE_LEVEL) ? LOW : HIGH;
    btnCnt[i] = 0;
    btns[i].lastRaw = btnStableIsr[i];
    btns[i].stable = btnStableIsr[i];
  }
  btnTimer = new HardwareTimer(BTN_TIMER_INSTANCE);
  btnTimer->setOverflow(1000, HERTZ_FORMAT);  // 1 kHz = 1 ms
  btnTimer->attachInterrupt(btnTickISR);
  btnTimer->resume();
}

// Loop theke: ISR-er confirmed level legacy btns[] struct-e copy (baki logic unchanged)
void buttonsUpdate() {
  for (int i = 0; i < 5; i++) {
    uint8_t s = btnStableIsr[i];
    btns[i].lastRaw = s;
    btns[i].stable = s;
  }
}

// Diagnostic: glitch counter 5 s por por DBG frame (ESP32 serial-e dekha jabe).
// Button na chepe-o K= barle PA4 line-e electrical noise ashche.
void buttonsGlitchReport() {
#if STM_BTN_TRACE
  static unsigned long lastBtnDbg = 0;
  unsigned long now = millis();
  if (now - lastBtnDbg < BTN_GLITCH_REPORT_MS) return;
  if (espProto != PROTO_VER || txUsed() >= LINK_TX_RING - 600) return;
  lastBtnDbg = now;
  uint32_t g[5];
  noInterrupts();
  for (int i = 0; i < 5; i++) g[i] = btnGlitch[i];
  interrupts();
  linkSendf("DBG,[BTN] glitch R=%lu Y=%lu G=%lu B=%lu K=%lu",
            (unsigned long)g[0], (unsigned long)g[1], (unsigned long)g[2],
            (unsigned long)g[3], (unsigned long)g[4]);
#endif
}

static inline int btnLevel(int i) { return btns[i].stable; }

void handleOperatorInputs() {
  bool btn1 = btnLevel(0);
  bool btn2 = btnLevel(1);
  bool btn3 = btnLevel(2);
  bool btn4 = btnLevel(3);

  if (lastBtn1 == HIGH && btn1 == LOW) {
    if (opReady()) { startReason(1); queueProductionData(0, 0, 0, 0, "Reason_1"); }
  }
  if (lastBtn2 == HIGH && btn2 == LOW) {
    if (opReady()) { startReason(2); queueProductionData(0, 0, 0, 0, "Reason_2"); }
  }
  if (lastBtn3 == HIGH && btn3 == LOW) {
    if (opReady()) { startReason(3); queueProductionData(0, 0, 0, 0, "Reason_3"); }
  }
  if (lastBtn4 == HIGH && btn4 == LOW) {
    if (opReady()) {
      unsigned long currentTime = millis();
      if (btn4PressCount == 0 || (currentTime - btn4FirstPressTime > BTN4_TIMEOUT)) {
        btn4PressCount = 1;
        btn4FirstPressTime = currentTime;
      } else {
        btn4PressCount++;
      }
      if (btn4PressCount == 3) {
        stopAllRelays();
        triggerBuzzer(150);
        queueProductionData(0, 0, 0, 0, "Reason_4");
        btn4PressCount = 0;
      }
    }
  }
  lastBtn1 = btn1;
  lastBtn2 = btn2;
  lastBtn3 = btn3;
  lastBtn4 = btn4;

  // ALTER (PA4): count once on debounced HIGH-to-LOW press edge.
  // BTN-ISR: edge ekhon 40 ms TANA LOW confirm-er por (ISR); 1000 ms lockout unchanged.
  static bool lastAlterState = HIGH;
  const bool alterState = btnLevel(4);
  if (lastAlterState == HIGH && alterState == LOW &&
      (millis() - lastSwitchPress > 1000)) {
    if (opReady()) {
      triggerBuzzer(200);
      totalAlter++;
      lifeAlter++;
      actualProduction = totalProduction - totalAlter;
      queueProductionData(0, 1, 0, 0, "");
      lastSwitchPress = millis();
    }
  }
  lastAlterState = alterState;

  if (blinkActive && millis() - previousBlinkTime >= blinkInterval) {
    previousBlinkTime = millis();
    blinkState = !blinkState;
    updateRelays();
  }
}

// =============================================================================
// 16) COMMON PRODUCTION COMMIT  (legacy order: count -> cycle buffer -> light -> queue)
// =============================================================================
void countProduction(unsigned long cycTime) {
  totalProduction++;
  lifeProduction++;
  actualProduction = totalProduction - totalAlter;
  productionCycleTimes[cycleIndex] = cycTime;
  cycleIndex = (cycleIndex + 1) % 5;
  if (cycleCount < 5) cycleCount++;
  lastProductionTimestamp = millis();
  checkAndApplyPerformanceLight();
}

void registerProduction(unsigned long irDur, unsigned long cycTime) {
  countProduction(cycTime);
  queueProductionData(1, 0, irDur, cycTime, "");
}

// =============================================================================
// =============================================================================
//   MACHINE-SPECIFIC PRODUCTION LOGIC START
//   (protiti profile alada block; legacy condition/threshold UNCHANGED)
// =============================================================================
// =============================================================================

#if MACHINE_PROFILE == PROFILE_PLAIN_OPTO
// -----------------------------------------------------------------------------
// [1] PLAIN MACHINE — OPTOCOUPLER   (source: PLAIN-MACHINE-OPTOCUPLAR.txt)
//   Input   : legacy GPIO34 (LOW = body) -> ISO1 PB1 (TLP2361, active LOW)
//   Rule    : 40 ms stable LOW + 2000 ms interlock -> body +1
//   Needle  : CT current spike -> body (CT disabled hole 0)
//   Cycle   : current body end - previous body end (legacy)
//   Change  : boot/session-er por ISO1 ekbar HIGH (inactive) na dekha porjonto
//             arm hoy na (boot-e held signal phantom count protirodh).
// -----------------------------------------------------------------------------
bool optoLastState = HIGH;
bool pulseActive = false;
const unsigned long stableTime = 40;
unsigned long stateChangeTime = 0;
const unsigned long PULSE_INTERVAL_MS = 2000;
unsigned long needleStartTime = 0;
unsigned long lastPulseEndTime = 0;
bool isNeedleActive = false;
unsigned long lastSavedNeedleDuration = 0;
unsigned long lastSavedCycleTime = 0;
bool plainArmed = false;

void profileReset() {
  optoLastState = HIGH; pulseActive = false; stateChangeTime = millis();
  needleStartTime = 0; lastPulseEndTime = 0; isNeedleActive = false;
  lastSavedNeedleDuration = 0; lastSavedCycleTime = 0;
  plainArmed = false;
}
void profileSetup() { pinMode(PIN_ISO1, INPUT); profileReset(); }
bool profileHasPending() { return false; }
void profileFlushPending(const char* why) { (void)why; }

void profileSense() {
  double currentIrms = getFilteredCurrent();
  bool isMachineRunning = (currentIrms >= CURRENT_THRESHOLD);
  if (isMachineRunning && !isNeedleActive) {
    needleStartTime = millis();
    isNeedleActive = true;
    DBG_PRINTLN("[DEBUG][CURRENT] First Current Spike Detected. Needle Down Timing Started!");
  }

  bool rawState = legacyRead(PIN_ISO1, ISO_ACTIVE_LEVEL);
  if (!plainArmed) {                         // boot guard
    if (rawState == HIGH) plainArmed = true;
    optoLastState = rawState;
    stateChangeTime = millis();
    return;
  }
  if (rawState != optoLastState) stateChangeTime = millis();

  if (millis() - stateChangeTime >= stableTime) {
    if (rawState == LOW && !pulseActive) {
      if (millis() - lastProductionTime >= PULSE_INTERVAL_MS) {
        pulseActive = true;
        if (opReady()) {
          unsigned long currentEndTime = millis();
          if (isNeedleActive && needleStartTime > 0) lastSavedNeedleDuration = currentEndTime - needleStartTime;
          else lastSavedNeedleDuration = 0;
          // wrap-safe: legacy '>' guard millis() rollover-e cycle 0 dito
          if (lastPulseEndTime > 0) lastSavedCycleTime = currentEndTime - lastPulseEndTime;
          else lastSavedCycleTime = 0;
          lastPulseEndTime = currentEndTime;

          registerProduction(lastSavedNeedleDuration, lastSavedCycleTime);
          DBG_PRINTF("[OPTOCOUPLER BODY DETECTED] Body Count: %ld | Needle: %lu ms | Cycle: %lu ms\n",
                     (long)totalProduction, lastSavedNeedleDuration, lastSavedCycleTime);

          isNeedleActive = false;
          needleStartTime = 0;
          lastProductionTime = millis();
        } else {
          DBG_PRINTLN("[BODY DETECTED REJECTED] Optocoupler signal received but No Operator Checked-in!");
        }
      } else {
        static unsigned long lastIgnoreLog = 0;
        if (millis() - lastIgnoreLog > 500) { lastIgnoreLog = millis(); DBG_PRINTLN("[PULSE IGNORED] Time interval less than set delay!"); }
      }
    }
    if (rawState == HIGH && pulseActive) {
      pulseActive = false;
      DBG_PRINTLN("[OPTOCOUPLER SIGNAL] Body Sensing Ended (HIGH)");
    }
  }
  optoLastState = rawState;
}

#elif MACHINE_PROFILE == PROFILE_OVERLOCK_IR
// -----------------------------------------------------------------------------
// [2] OVERLOCK — IR   (source: OVERLOCK IR AND REASON(1).txt)
//   Input   : legacy GPIO32 IR (LOW = fabric) -> OPT1 PA8 (HC14, active HIGH)
//   Rule    : IR LOW >= 1000 ms (machine running) = cycle start;
//             start theke >= 3000 ms LOW = body +1 (legacy timing UNCHANGED);
//             200 ms HIGH = release.
//   Cycle   : current start - previous counted start (legacy)
//   BUG FIX : legacy count-er somoy AGER body-r IR duration pathato.
//             Ekhon count-e counter/light sathe sathe update hoy (legacy timing),
//             kintu event PENDING (FRAM) thake; IR release-e EI body-r duration
//             (legacy formula: release confirm - start) diye finalize hoy.
//             Power-loss: boot-e pending lower-bound duration + flags diye
//             finalize, ar IR tokhono active thakle same body abar count hoy na.
// -----------------------------------------------------------------------------
bool irWasActive = false;
bool productionCounted = false;
unsigned long irActiveStartTime = 0;
unsigned long previousIrStartTime = 0;
unsigned long irLowStartTime = 0;
unsigned long irLastLowTime = 0;
unsigned long lastSavedIrDuration = 0;
unsigned long lastSavedCycleTime = 0;
bool overlockSuppressUntilRelease = false;

bool profileHasPending() { return pend.active != 0; }

void finalizePending(unsigned long irDur, uint8_t extraFlags) {
  if (!pend.active) return;
  EventRec r = pend.rec;
  r.irDur = irDur;
  r.flags = (uint8_t)((r.flags & ~EVF_DUR_NOT_FINAL) | extraFlags);
  bool inOutbox = storeRec(r); // 1) outbox (same seq, already counted)
  pend.active = 0;
  pendSave();                  // 2) pending clear
  if (inOutbox) sendNow(r);    // 3) sathe sathe ESP32
  DBG_PRINTF("[OVERLOCK] Finalized seq=%lu irDur=%lu ms flags=%u\n", (unsigned long)r.seq, irDur, r.flags);
}

void profileFlushPending(const char* why) {
  (void)why;
  if (!pend.active) return;
  unsigned long dur = irActiveStartTime ? (millis() - irActiveStartTime) : pend.rec.irDur;
  finalizePending(dur, EVF_DUR_NOT_FINAL);
}

void profileReset() {
  // Counted body IR-e tokhono thakle (session change) same body abar count na
  bool countedBodyActive = irWasActive && productionCounted;
  irWasActive = false; productionCounted = false; irActiveStartTime = 0;
  previousIrStartTime = 0; irLowStartTime = 0; irLastLowTime = 0;
  lastSavedIrDuration = 0; lastSavedCycleTime = 0;
  if (countedBodyActive) { overlockSuppressUntilRelease = true; irLastLowTime = millis(); }
}

void profileSetup() {
  pinMode(PIN_OPT1, INPUT);
  profileReset();
  // Power-loss recovery: pending event
  if (pend.active) {
    EventRec newest;
    if ((obxNewest(newest) && newest.seq == pend.rec.seq) || (aggActive() && agg.lastSeq == pend.rec.seq)) {        // already stored before loss
      pend.active = 0;
      pendSave();
    } else {
      finalizePending(pend.rec.irDur, EVF_DUR_NOT_FINAL | EVF_RECOVERED);
    }
    overlockSuppressUntilRelease = true;    // same body abar count na
  }
}

void profileSense() {
  double currentIrms = getFilteredCurrent();
  bool isMachineRunning = (currentIrms >= CURRENT_THRESHOLD);
#if OVERLOCK_REQUIRE_Z_MOTION
  isMachineRunning = isMachineRunning && zMotionRecent();
#endif

  int irState = legacyRead(PIN_OPT1, OPT_ACTIVE_LEVEL);

  if (overlockSuppressUntilRelease) {        // recovered body: release-er jonno opekkha
    if (irState == HIGH) { if (millis() - irLastLowTime > 200) overlockSuppressUntilRelease = false; }
    else irLastLowTime = millis();
    return;
  }

  if (irState == LOW) {
    irLastLowTime = millis();
    if (!irWasActive) {
      if (isMachineRunning) {
        if (irLowStartTime == 0) {
          irLowStartTime = millis();
        } else if (millis() - irLowStartTime >= 1000) {
          irActiveStartTime = millis();
          irWasActive = true;
          productionCounted = false;
          if (previousIrStartTime > 0) lastSavedCycleTime = irActiveStartTime - previousIrStartTime;
          else lastSavedCycleTime = 0;
          DBG_PRINTLN("[SENSOR] Valid Production Cycle Started (Debounced)...");
        }
      }
    } else if (!productionCounted) {
      if (millis() - irActiveStartTime >= 3000) {
        if (opReady()) {
          if (millis() - lastProductionTime > debounceDelay) {
            previousIrStartTime = irActiveStartTime;
            countProduction(lastSavedCycleTime);                       // legacy count timing
            unsigned long lowerBound = millis() - irActiveStartTime;
            pend.rec = makeRec(EV_PRODUCTION, 1, 0, lowerBound, lastSavedCycleTime, "", EVF_DUR_NOT_FINAL);
            pend.rec.ts = rtcNowEpoch();
            sealRec(pend.rec);                                         // CRC: boot reconcile-e valid
            pend.active = 1;
            pendSave();                                                // pending -> FRAM
            saveState();
            lastProductionTime = millis();
            productionCounted = true;
            DBG_PRINTF("[PRODUCTION] Body: %ld | Cycle: %lu ms (IR duration pending until release)\n", (long)totalProduction, lastSavedCycleTime);
          }
        } else {
          DBG_PRINTLN("[PRODUCTION REJECTED] No Operator Checked-in!");
          productionCounted = true;
        }
      }
    } else if (pend.active && millis() - irActiveStartTime >= OVERLOCK_PENDING_MAX_MS) {
      finalizePending(millis() - irActiveStartTime, EVF_DUR_NOT_FINAL);  // stuck IR safety
    }
  } else {
    if (millis() - irLastLowTime > 200) {
      irLowStartTime = 0;
      if (irWasActive && productionCounted) {
        lastSavedIrDuration = millis() - irActiveStartTime;             // legacy formula
        finalizePending(lastSavedIrDuration, 0);                        // EI body-r duration
      }
      irWasActive = false;
      productionCounted = false;
    }
  }
}

#elif MACHINE_PROFILE == PROFILE_FLATLOCK_DOUBLE
// -----------------------------------------------------------------------------
// [3] FLATLOCK — DOUBLE OPTO + BODY LOCK   (source: FLAT_LOCK_DOUBLE_OPTO_BODY_LOCK_IR3S)
//   Input   : legacy GPIO32 START, GPIO35 TRIM -> ISO1 PB1 START, ISO2 PB10 TRIM
//   Rule    : first START (machine running) = BODY LOCK; extra START ignore;
//             TRIM pulse 30..3000 ms; START->TRIM >= 3000 ms; debounce 1000 ms;
//             trim without lock = reject. Cycle = valid START - previous valid START.
//   Change  : none (interrupted cycle on power loss is discarded — legacy).
// -----------------------------------------------------------------------------
bool optoStartActive = false;
bool bodyCycleActive = false;
unsigned long optoStartBeginTime = 0;
unsigned long previousStartCycleTime = 0;
unsigned long calculatedCycleTime = 0;
const unsigned long MIN_IR_ACTIVE_MS = 3000;
int lastTrimState = HIGH;
unsigned long trimPulseStartTime = 0;
bool trimPulseInProgress = false;

void profileReset() {
  optoStartActive = false; bodyCycleActive = false; optoStartBeginTime = 0;
  previousStartCycleTime = 0; calculatedCycleTime = 0;
  lastTrimState = HIGH; trimPulseStartTime = 0; trimPulseInProgress = false;
}
void profileSetup() { pinMode(PIN_ISO1, INPUT); pinMode(PIN_ISO2, INPUT); profileReset(); }
bool profileHasPending() { return false; }
void profileFlushPending(const char* why) { (void)why; }

void profileSense() {
  double currentIrms = getFilteredCurrent();
  bool isMachineRunning = (currentIrms >= CURRENT_THRESHOLD);

  int startOptoState = legacyRead(PIN_ISO1, ISO_ACTIVE_LEVEL);
  if (startOptoState == LOW) {
    if (!optoStartActive) {
      optoStartActive = true;
      PULSE_TRACE("[OPTO START] INPUT LOW");
      if (!bodyCycleActive && isMachineRunning) {
        bodyCycleActive = true;
        optoStartBeginTime = millis();
        if (previousStartCycleTime > 0) calculatedCycleTime = optoStartBeginTime - previousStartCycleTime;
        else calculatedCycleTime = 0;
        DBG_PRINTF("[OPTO START] FIRST Start accepted. BODY LOCK ON | Cycle: %lu ms\n", calculatedCycleTime);
        PULSE_TRACE("[OPTO START] BODY LOCK ON");
      } else if (bodyCycleActive) {
        DBG_PRINTLN("[OPTO START] Extra Start ignored - body locked, waiting for valid Trim.");
      }
    }
  } else {
    optoStartActive = false;
  }

  int currentTrimState = legacyRead(PIN_ISO2, ISO_ACTIVE_LEVEL);
  if (lastTrimState == HIGH && currentTrimState == LOW) {
    trimPulseStartTime = millis();
    trimPulseInProgress = true;
    PULSE_TRACE("[TRIM] INPUT LOW");
  }
  if (lastTrimState == LOW && currentTrimState == HIGH) {
    if (trimPulseInProgress) {
      unsigned long pulseWidth = millis() - trimPulseStartTime;
      if (pulseWidth >= 30 && pulseWidth <= 3000) {
        if (!bodyCycleActive) {
          DBG_PRINTF("[PRODUCTION REJECTED] Trim (%lums) but no active START/LOCK.\n", pulseWidth);
        } else if (millis() - lastProductionTime > debounceDelay) {
          unsigned long runDuration = 0;
          if (optoStartBeginTime > 0) runDuration = millis() - optoStartBeginTime;
          if (runDuration < MIN_IR_ACTIVE_MS) {
            DBG_PRINTF("[PRODUCTION REJECTED] IR Active too short: %lu ms < %lu ms. Trim=%lums\n",
                       runDuration, MIN_IR_ACTIVE_MS, pulseWidth);
          } else if (opReady()) {
            previousStartCycleTime = optoStartBeginTime;
            registerProduction(runDuration, calculatedCycleTime);
            lastProductionTime = millis();
            PULSE_TRACE("[TRIM CONFIRMED] PRODUCTION+1");
            DBG_PRINTF("[TRIM CONFIRMED] Trim: %lums | Run: %lu ms | Cycle: %lu ms | Body: %ld\n",
                       pulseWidth, runDuration, calculatedCycleTime, (long)totalProduction);
          } else {
            DBG_PRINTLN("[PRODUCTION REJECTED] Valid Start->Trim, but Operator Not Checked-in!");
          }
          bodyCycleActive = false;
          optoStartBeginTime = 0;
          calculatedCycleTime = 0;
          DBG_PRINTLN("[BODY LOCK] OFF - next body START is now allowed.");
        }
      }
      trimPulseInProgress = false;
    }
  }
  lastTrimState = currentTrimState;
}

#elif (MACHINE_PROFILE == PROFILE_BUTTON_ATTACH) || (MACHINE_PROFILE == PROFILE_BARTACK)
// -----------------------------------------------------------------------------
// [4] BUTTON ATTACH  (source: BUTTUN_ATTACH.txt)  window  8..20 ms
// [7] BARTACK        (source: BARTECH.txt)        window 100..200 ms
//   Input   : legacy GPIO34/35 pulse train -> ISO1 PB1; legacy GPIO32 START -> ISO2 PB10
//   Rule    : train = first LOW start -> last LOW end; 200 ms no edge = finished;
//             duration window-e hole body +1. Cycle = START->START (fallback:
//             last production -> now). (UNCHANGED)
//   Capture : EXTI interrupt + edge FIFO (legacy 1 ms polling-er bodole) so FRAM/
//             UART kaj-e pulse miss hoy na. Edge timestamp = millis() (legacy unit).
//   Change  : TRAIN_GLITCH_US (100 us) er cheye chhoto level-change noise hishebe
//             bad (polling legacy-te egulo shadharonoto dhorai porto na).
// -----------------------------------------------------------------------------
bool optoStartActive = false;
unsigned long optoStartBeginTime = 0;
unsigned long previousStartCycleTime = 0;
unsigned long calculatedCycleTime = 0;

#define TIMEOUT_MS 200
int lastState1 = HIGH;
unsigned long stateStartTime1 = 0;
unsigned long pulseTrainStart1 = 0;
unsigned long lastPulseEndTime1 = 0;
bool isPulseActive1 = false;
int pulseCount1 = 0;

#define EDGE_FIFO_SIZE 64
volatile uint32_t edgeMs[EDGE_FIFO_SIZE];
volatile uint32_t edgeUs[EDGE_FIFO_SIZE];
volatile uint8_t  edgeL[EDGE_FIFO_SIZE];
volatile uint8_t  edgeHead = 0, edgeTail = 0;
volatile uint32_t edgeOverflow = 0;

// deglitch state
bool dgPending = false;
uint32_t dgMs = 0, dgUs = 0;
int dgLevel = HIGH;
int dgEmittedLevel = HIGH;

void trainEdgeISR() {
  uint8_t nh = (uint8_t)((edgeHead + 1) % EDGE_FIFO_SIZE);
  if (nh == edgeTail) { edgeOverflow++; return; }
  edgeMs[edgeHead] = millis();
  edgeUs[edgeHead] = micros();
  edgeL[edgeHead] = (uint8_t)legacyRead(PIN_ISO1, ISO_ACTIVE_LEVEL);
  edgeHead = nh;
}

bool popEdge(uint32_t& tMs, uint32_t& tUs, int& lvl) {
  noInterrupts();
  if (edgeTail == edgeHead) { interrupts(); return false; }
  tMs = edgeMs[edgeTail];
  tUs = edgeUs[edgeTail];
  lvl = edgeL[edgeTail];
  edgeTail = (uint8_t)((edgeTail + 1) % EDGE_FIFO_SIZE);
  interrupts();
  return true;
}

// Legacy train state machine (unchanged) — deglitched edge input
void processTrainEdge(unsigned long currentMillis, int currentState1) {
  if (currentState1 == lastState1) return;
  if (lastState1 == LOW) {
    lastPulseEndTime1 = currentMillis;
    pulseCount1++;
  } else {
    if (!isPulseActive1) {
      isPulseActive1 = true;
      pulseTrainStart1 = currentMillis;
      pulseCount1 = 0;
    }
  }
  stateStartTime1 = currentMillis;
  lastState1 = currentState1;
}

void deglitchEmit() {
  if (!dgPending) return;
  dgPending = false;
  dgEmittedLevel = dgLevel;
  processTrainEdge(dgMs, dgLevel);
}

void deglitchEdge(uint32_t tMs, uint32_t tUs, int lvl) {
  if (dgPending) {
    if ((uint32_t)(tUs - dgUs) < TRAIN_GLITCH_US) {   // pending change revert hoyeche = glitch
      dgPending = false;
      return;
    }
    deglitchEmit();
  }
  if (lvl == dgEmittedLevel) return;
  dgPending = true; dgMs = tMs; dgUs = tUs; dgLevel = lvl;
}

void profileReset() {
  optoStartActive = false; optoStartBeginTime = 0; previousStartCycleTime = 0; calculatedCycleTime = 0;
  noInterrupts(); edgeTail = edgeHead; interrupts();
  lastState1 = legacyRead(PIN_ISO1, ISO_ACTIVE_LEVEL);
  dgEmittedLevel = lastState1;
  dgPending = false;
  stateStartTime1 = millis();
  pulseTrainStart1 = 0; lastPulseEndTime1 = 0; isPulseActive1 = false; pulseCount1 = 0;
}

void profileSetup() {
  pinMode(PIN_ISO1, INPUT);
  pinMode(PIN_ISO2, INPUT);
  profileReset();
  attachInterrupt(digitalPinToInterrupt(PIN_ISO1), trainEdgeISR, CHANGE);
}
bool profileHasPending() { return false; }
void profileFlushPending(const char* why) { (void)why; }

void profileSense() {
  uint32_t tMs, tUs; int lvl;
  while (popEdge(tMs, tUs, lvl)) deglitchEdge(tMs, tUs, lvl);
  if (dgPending && (uint32_t)(micros() - dgUs) >= TRAIN_GLITCH_US) deglitchEmit();
  noInterrupts(); bool fifoEmpty = (edgeTail == edgeHead); interrupts();
  if (fifoEmpty && !dgPending) {                       // missed-edge safety (FIFO overflow)
    int polled = legacyRead(PIN_ISO1, ISO_ACTIVE_LEVEL);
    if (polled != dgEmittedLevel) { dgPending = true; dgMs = millis(); dgUs = micros(); dgLevel = polled; }
  }

  if (!dgPending && isPulseActive1 && (millis() - stateStartTime1 >= TIMEOUT_MS)) {
    unsigned long totalTrainDuration1 = lastPulseEndTime1 - pulseTrainStart1;
    DBG_PRINTF("[ISO1] TRAIN FINISHED | Pulses: %d | Duration: %lu ms\n", pulseCount1, totalTrainDuration1);
    if (totalTrainDuration1 >= TRAIN_MIN_MS && totalTrainDuration1 <= TRAIN_MAX_MS) {
      if (opReady()) {
        unsigned long runDuration = 0;
        if (optoStartBeginTime > 0) runDuration = millis() - optoStartBeginTime;
        if (calculatedCycleTime == 0 && lastProductionTime > 0) calculatedCycleTime = millis() - lastProductionTime;
        registerProduction(runDuration, calculatedCycleTime);
        DBG_PRINTF("[PRODUCTION] Valid Pulse Sequence! Total = %ld\n", (long)totalProduction);
        lastProductionTime = millis();
        optoStartBeginTime = 0;
        calculatedCycleTime = 0;
      } else {
        DBG_PRINTLN("[PRODUCTION REJECTED] Valid Pulse Sequence, but Operator Not Checked-in!");
      }
    } else {
      DBG_PRINTF("[PRODUCTION] Ignored (Duration out of %lu-%lu ms range)\n", TRAIN_MIN_MS, TRAIN_MAX_MS);
    }
    isPulseActive1 = false;
  }

  double currentIrms = getFilteredCurrent();
  bool isMachineRunning = (currentIrms >= CURRENT_THRESHOLD);
  int startOptoState = legacyRead(PIN_ISO2, ISO_ACTIVE_LEVEL);
  if (startOptoState == LOW) {
    if (!optoStartActive && isMachineRunning) {
      optoStartActive = true;
      optoStartBeginTime = millis();
      if (previousStartCycleTime > 0) calculatedCycleTime = optoStartBeginTime - previousStartCycleTime;
      else calculatedCycleTime = 0;
      previousStartCycleTime = optoStartBeginTime;
      DBG_PRINTLN("[ISO2 START] Start signal detected. Timing locked, waiting for pulse train...");
    }
  } else {
    optoStartActive = false;
  }
}

#elif MACHINE_PROFILE == PROFILE_ENCODER_BJ100
// -----------------------------------------------------------------------------
// [5] ENCODER + BJ100   (source: ENCODER_BJ100_CYCLETIME_UPDATED(2).txt)
//   Input   : legacy GPIO32 BJ100 (LOW active) -> OPT1 PA8 (HC14, active HIGH)
//             legacy GPIO35 encoder FALLING     -> ENC_Z PB0 (or ENC_A PA6)
//   Rule    : BJ100 active >= 5000 ms AND pulses >= 150 in window, 90 ms release
//             debounce; accepted on release. Cycle = this valid START - previous
//             valid START (first = 0); rejected cycle reference update kore na.
//             irActiveDuration + cycleTime = SAME accepted cycle. (UNCHANGED)
// -----------------------------------------------------------------------------
const unsigned long BJ100_MIN_ACTIVE_MS = 5000;
const uint32_t ENCODER_MIN_PULSES = 150;
const unsigned long BJ100_RELEASE_DEBOUNCE_MS = 90;

unsigned long bj100ActiveStartTime = 0;
unsigned long bj100InactiveStartTime = 0;
unsigned long lastBj100EndTime = 0;
unsigned long previousValidProductionStartTime = 0;
bool bj100CycleActive = false;
unsigned long lastSavedIrDuration = 0;
unsigned long lastSavedCycleTime = 0;

void profileReset() {
  bj100ActiveStartTime = 0; bj100InactiveStartTime = 0; lastBj100EndTime = 0;
  previousValidProductionStartTime = 0; bj100CycleActive = false;
  lastSavedIrDuration = 0; lastSavedCycleTime = 0;
  noInterrupts(); encoderPulseCount = 0; encoderWindowOpen = false; interrupts();
}

void profileSetup() {
  pinMode(PIN_OPT1, INPUT);
#if BJ100_ENCODER_SOURCE == ENC_SRC_A
  attachInterrupt(digitalPinToInterrupt(PIN_ENC_A), encAISR, RISING);
#endif
  profileReset();
}
bool profileHasPending() { return false; }
void profileFlushPending(const char* why) { (void)why; }

void profileSense() {
  const unsigned long nowMs = millis();
  const bool bj100ActiveNow = (legacyRead(PIN_OPT1, OPT_ACTIVE_LEVEL) == LOW);

  if (bj100ActiveNow) {
    bj100InactiveStartTime = 0;
    if (!bj100CycleActive) {
      bj100CycleActive = true;
      bj100ActiveStartTime = nowMs;
      noInterrupts();
      encoderPulseCount = 0;
      encoderWindowOpen = true;
      interrupts();
      DBG_PRINTLN("[PRODUCTION] BJ100 Active -> Encoder counting window opened.");
    }
  } else if (bj100CycleActive) {
    if (bj100InactiveStartTime == 0) bj100InactiveStartTime = nowMs;

    if (nowMs - bj100InactiveStartTime >= BJ100_RELEASE_DEBOUNCE_MS) {
      const unsigned long cycleEndTime = bj100InactiveStartTime;
      const unsigned long bj100ActiveDuration = cycleEndTime - bj100ActiveStartTime;

      uint32_t pulsesThisCycle;
      noInterrupts();
      encoderWindowOpen = false;
      pulsesThisCycle = encoderPulseCount;
      interrupts();

      lastSavedIrDuration = bj100ActiveDuration;
      lastBj100EndTime = cycleEndTime;

      const bool durationOk = (bj100ActiveDuration >= BJ100_MIN_ACTIVE_MS);
      const bool pulseOk = (pulsesThisCycle >= ENCODER_MIN_PULSES);

      DBG_PRINTF("[PRODUCTION] BJ100 Released | Duration: %lu ms | Pulses: %lu | DurOK: %s | PulseOK: %s\n",
                 bj100ActiveDuration, (unsigned long)pulsesThisCycle, durationOk ? "YES" : "NO", pulseOk ? "YES" : "NO");

      if (durationOk && pulseOk) {
        if (opReady()) {
          // wrap-safe: legacy '>' guard millis() 49.7-day rollover-e cycle 0 dito
          if (previousValidProductionStartTime > 0)
            lastSavedCycleTime = bj100ActiveStartTime - previousValidProductionStartTime;
          else
            lastSavedCycleTime = 0;
          previousValidProductionStartTime = bj100ActiveStartTime;
          registerProduction(lastSavedIrDuration, lastSavedCycleTime);
          lastProductionTime = nowMs;
          DBG_PRINTF("[PRODUCTION SUCCESS] Pulses: %lu | Cycle: %lu ms | Total: %ld\n",
                     (unsigned long)pulsesThisCycle, lastSavedCycleTime, (long)totalProduction);
        } else {
          DBG_PRINTLN("[PRODUCTION REJECTED] Valid sensor cycle, but Operator Not Checked-In!");
        }
      } else {
        DBG_PRINTLN("[PRODUCTION REJECTED] Minimum Active Time or Encoder Pulse requirement not met.");
      }

      bj100CycleActive = false;
      bj100InactiveStartTime = 0;
      noInterrupts();
      encoderPulseCount = 0;
      interrupts();
    }
  }
}

#elif MACHINE_PROFILE == PROFILE_BUTTON_HOLE
// -----------------------------------------------------------------------------
// [6] BUTTON HOLE   (source: BUTTON HOLE.txt)
//   Input   : legacy GPIO32 PC817 (CHANGE ISR) -> ISO1 PB1 (TLP2361, CHANGE ISR)
//   Rule    : pulse width >= 5 ms, lockout 20 ms; 500 ms no pulse = session end;
//             session >= 30 pulses -> body +1. irActive = session start -> end;
//             cycle = now - last production (first = irActive). (UNCHANGED)
// -----------------------------------------------------------------------------
const unsigned long OPTO_MIN_PULSE_WIDTH_MS = 5;
const unsigned long OPTO_LOCKOUT_TIME_MS = 20;
const unsigned long PULSE_STOP_TIMEOUT_MS = 500;
const int MIN_PULSE_REQUIRED = 30;

volatile bool optoPulseStarted = false;
volatile unsigned long optoPulseStartTime = 0;
volatile uint32_t optoPulseDetectedCount = 0;    // flag -> counter (loop latency-te pulse harabe na)
volatile unsigned long lastPulseTime = 0;

unsigned long currentPulseCount = 0;
bool pulseInSession = false;
unsigned long sessionStartTime = 0;

void optoPulseISR() {
  int state = legacyRead(PIN_ISO1, ISO_ACTIVE_LEVEL);
  if (state == LOW) {
    if (!optoPulseStarted && (millis() - lastPulseTime >= OPTO_LOCKOUT_TIME_MS)) {
      optoPulseStarted = true;
      optoPulseStartTime = millis();
    }
  } else {
    if (optoPulseStarted) {
      unsigned long pulseWidth = millis() - optoPulseStartTime;
      if (pulseWidth >= OPTO_MIN_PULSE_WIDTH_MS) optoPulseDetectedCount++;
      optoPulseStarted = false;
    }
  }
}

void profileReset() {
  noInterrupts(); optoPulseStarted = false; optoPulseDetectedCount = 0; lastPulseTime = 0; interrupts();
  currentPulseCount = 0; pulseInSession = false; sessionStartTime = 0;
}
void profileSetup() {
  pinMode(PIN_ISO1, INPUT);
  profileReset();
  attachInterrupt(digitalPinToInterrupt(PIN_ISO1), optoPulseISR, CHANGE);
}
bool profileHasPending() { return false; }
void profileFlushPending(const char* why) { (void)why; }

void profileSense() {
  noInterrupts();
  uint32_t detected = optoPulseDetectedCount;
  optoPulseDetectedCount = 0;
  interrupts();
  if (detected) {
    lastPulseTime = millis();
    currentPulseCount += detected;
    if (!pulseInSession) {
      pulseInSession = true;
      sessionStartTime = millis();
    }
  }

  if (pulseInSession && (millis() - lastPulseTime >= PULSE_STOP_TIMEOUT_MS)) {
    if (currentPulseCount >= (unsigned long)MIN_PULSE_REQUIRED) {
      if (opReady()) {
        unsigned long currentTime = millis();
        unsigned long irActiveDur = currentTime - sessionStartTime;
        unsigned long cycTime = 0;
        if (lastProductionTimestamp > 0) cycTime = currentTime - lastProductionTimestamp;
        else cycTime = irActiveDur;
        registerProduction(irActiveDur, cycTime);
        DBG_PRINTF("[PRODUCTION COUNTED] Pulses: %lu | IR Active: %lu ms | Cycle: %lu ms\n",
                   currentPulseCount, irActiveDur, cycTime);
      }
    }
    currentPulseCount = 0;
    pulseInSession = false;
  }
}
#endif

// =============================================================================
//   MACHINE-SPECIFIC PRODUCTION LOGIC END
// =============================================================================

// =============================================================================
// 17) BOOT RECONCILE — state checkpoint vs newest outbox / pending record
// =============================================================================
void reconcileState() {
  EventRec r;
  bool have = false;
  EventRec best;
  if (agg.flushSeq != 0) {                   // aggregate flush-er majhe power gechilo
    EventRec nr;
    if (obxNewest(nr) && nr.type == EV_AGGREGATE && nr.seq == agg.flushSeq) {
      agg.prod -= (agg.flushP <= agg.prod) ? agg.flushP : agg.prod;
      agg.alt -= (agg.flushA <= agg.alt) ? agg.flushA : agg.alt;
      agg.reasonEv -= (agg.flushR <= agg.reasonEv) ? agg.flushR : agg.reasonEv;
      if (!aggActive()) memset(&agg, 0, sizeof(agg));
    }
    agg.flushSeq = 0;
    aggSave();
  }
  if (obxNewest(r)) {
    if (r.type == EV_AGGREGATE) { if (r.seq > eventSeq) eventSeq = r.seq; }   // seq only
    else { best = r; have = true; }
  }
  if (pend.active && recValid(pend.rec) && (!have || pend.rec.seq > best.seq)) { best = pend.rec; have = true; }
  if (aggActive() && agg.lastSeq > eventSeq) {
    eventSeq = agg.lastSeq;
    totalProduction = agg.tp; totalAlter = agg.ta; actualProduction = agg.ac;
  }
  if (have && best.seq > eventSeq) {
    eventSeq = best.seq;
    totalProduction = best.tp;
    totalAlter = best.ta;
    actualProduction = best.ac;
    if (best.lifeP > lifeProduction) lifeProduction = best.lifeP;
    if (best.lifeA > lifeAlter) lifeAlter = best.lifeA;
    faults |= FAULT_STATE_RECOVERY;      // info: checkpoint-er age power gechilo
    DBG_PRINTF("[FRAM] State reconciled from record seq=%lu\n", (unsigned long)best.seq);
  }
  saveState();
}

// per-boot sequence epoch (no TRNG on F103: UID + persistent boot counter + RTC + timer + ADC noise)
uint32_t makeSeqEpoch() {
  uint32_t h = 2166136261UL;
  uint32_t parts[6] = { stmUid, bootCount, rtcNowEpoch(), micros(), (uint32_t)analogRead(PIN_ADC_SPARE), SysTick->VAL };
  const uint8_t* p = (const uint8_t*)parts;
  for (unsigned i = 0; i < sizeof(parts); i++) { h ^= p[i]; h *= 16777619UL; }
  return h ? h : 1;
}

// =============================================================================
// 17b) DAILY RESET — production day = local (UTC+6) time - 03:00. Notun day shuru
//      hole (boot-e ba running) operator/counter/session/maintenance/pending reset.
//      Operator card punch korle counter server theke (STATE) ashe.
// =============================================================================
uint32_t currentProdDay() {
  uint32_t e = rtcNowEpoch();
  if (e < 1700000000UL) return 0;                       // time unknown: decide kora jabe na
  int64_t local = (int64_t)e + LOCAL_TZ_OFFSET_SEC - (int64_t)DAY_RESET_HOUR_LOCAL * 3600;
  return (uint32_t)(local / 86400);
}

void dailyReset(uint32_t newDay) {
  profileFlushPending("daily reset");                   // counted body-r event age outbox-e
  uint32_t released = sessReleaseAll();                 // F3: login hoy ni -> "UNKNOWN" name-e DB-te
  char keepLoc[sizeof(((SessSlot*)0)->loc)];
  const SessSlot* cur = sessCur();
  strCopy(keepLoc, sizeof(keepLoc), cur ? cur->loc : "NONE");   // legacy: location daily reset-e thake
  totalProduction = 0;
  totalAlter = 0;
  actualProduction = 0;
  operatorReady = false;
  isMaintenanceMode = false;
  activeSmv = DEFAULT_SMV;
  activeDivisor = 1;
  resetPerformanceSession();
  profileReset();
#if DAILY_RESET_CLEAR_OUTBOX
  obxCount = 0; ramCount = 0; obxSaveHdr();
  memset(&agg, 0, sizeof(agg)); aggSave();
  for (int i = 0; i < SESS_SLOTS; i++) sessRef[i] = 0;
#endif
  prodDay = newDay;
  ctx.opRfid[0] = 0;
  ctx.techSid = 0;
  ctx.techRfid[0] = 0;
  ctx.recPunch = 0;
  ctx.loginDay = 0;
  ctx.pad[0] = 0;
  currentSessionId = sessCreate(0, false, "UNKNOWN", keepLoc, "NONE", "NONE", DEFAULT_SMV, 1);   // ctxSave
  saveState();
  replayStart();                                        // released event gulo ekhon DB-te
  beepRequest(80, 80, 2);
  (void)released;
  DBG_PRINTF("[DAY] Daily reset -> production day %lu (released %lu UNKNOWN event)\n", (unsigned long)newDay, (unsigned long)released);
}

void checkDailyReset(const char* why) {
  (void)why;
  uint32_t d = currentProdDay();
  if (d == 0) return;
  if (dayUnknownSinceBoot) {
    dayUnknownSinceBoot = false;
    // RTC invalid chilo, operator ajke login korse, pore time eseche: mid-shift reset na kore adopt
    if (loginSinceBoot && d != prodDay) { prodDay = d; saveState(); return; }
  }
  if (prodDay == 0) { prodDay = d; saveState(); return; }         // prothom bar (fresh FRAM)
  if (d > prodDay) dailyReset(d);
  else if (d < prodDay) { prodDay = d; saveState(); }             // RTC age bhul (samne) chilo: shudhu sync
}

// =============================================================================
// 18) HOUSEKEEPING: RTC cache, heartbeat, ESP watchdog (backoff), LED, RPM
// =============================================================================
// I2CF1: PB5 LOW drive korle I2C bus (SDA+SCL) LOW-e pore jay (hardware net PB5-er sathe juri).
// Tai idle-e PB5 Hi-Z (INPUT) — test sketch-er moto, jekhane FRAM kaj korechilo.
// Reset pulse-e shudhu HIGH drive (design: HIGH = ESP32 EN low).
static inline void espResetRelease() { pinMode(PIN_ESP_RESET, INPUT); }
static inline void espResetAssert()  { digitalWrite(PIN_ESP_RESET, HIGH); pinMode(PIN_ESP_RESET, OUTPUT); digitalWrite(PIN_ESP_RESET, HIGH); }

void serviceEspWatchdog() {
#if ESP_WATCHDOG_ENABLE
  unsigned long now = millis();
  if (espResetActive) {
    if (now - espResetPulseStart >= ESP_RESET_PULSE_MS) {
      espResetRelease();
      espResetActive = false;
      lastEspHbMs = now;
    }
    return;
  }
  if (espAlive()) {
    if (espHealthySinceMs == 0) espHealthySinceMs = now;
    if (now - espHealthySinceMs > 300000UL) espResetBackoffMs = ESP_BOOT_GRACE_MS;   // 5 min healthy: backoff reset
  } else {
    espHealthySinceMs = 0;
  }
  if (now - stmBootMs < ESP_BOOT_GRACE_MS) return;
  if (lastEspResetMs != 0 && (now - lastEspResetMs) < espResetBackoffMs) return;
  if (now - lastEspHbMs > ESP_HB_TIMEOUT_MS) {
    espResetAssert();
    espResetActive = true;
    espResetPulseStart = now;
    lastEspResetMs = now;
    espResetCount++;
    faults |= FAULT_ESP_RESET_ISSUED;
    espResetBackoffMs = (espResetBackoffMs * 2 > ESP_RESET_BACKOFF_MAX_MS) ? ESP_RESET_BACKOFF_MAX_MS : espResetBackoffMs * 2;
  }
#endif
}

void housekeeping() {
  static unsigned long lastRtc = 0, lastHb = 0, lastRpm = 0;
  static uint32_t lastZ = 0;
  unsigned long now = millis();

  if (lastRtc == 0 || now - lastRtc >= 10000UL) {
    lastRtc = now;
    rtcRefresh();
    if (sensingArmed) checkDailyReset("periodic");
  }

  if (now - lastRpm >= 1000UL) {
    noInterrupts(); uint32_t z = zTotal; interrupts();
    unsigned long dt = now - lastRpm;
    zRpm = dt ? (uint32_t)((uint64_t)(z - lastZ) * 60000ULL / dt) : 0;
    lastZ = z;
    lastRpm = now;
  }

  if (ctxDirty || now - lastCtxMs >= CTX_PERIOD_MS) sendCtx();

  if (now - lastHb >= HB_INTERVAL_MS) {
    lastHb = now;
    sendHeartbeat();
    if (framOk && ramCount > 0) obxMigrateRam();      // FRAM abar likhte parle RAM emergency record durable kora
  }

  buttonsGlitchReport();                              // BTN-ISR: noise diagnostic (5 s)

#if STM_RESET_DIAG
  static unsigned long lastDiag = 0;                  // RESET-FIX: SDIAG frame 10 s por por
  if (now - lastDiag >= STM_DIAG_FRAME_MS && txUsed() < LINK_TX_RING - 600) {
    lastDiag = now;
    sendDiag();
  }
#endif

  serviceEspWatchdog();

  unsigned long period = (framOk && rtcOk && !(faults & (FAULT_OUTBOX_FULL | FAULT_FRAM_WRITE))) ? 1000UL : 200UL;
  digitalWrite(PIN_STATUS_LED, ((now / (period / 2)) & 1) ? HIGH : LOW);
}

// =============================================================================
// 19) SETUP / LOOP
// =============================================================================
void setup() {
  // I2CD2 S0: kono pin configure korar AGE SDA/SCL (reset state = floating input)
  memset(pinSnap, 0xFF, sizeof(pinSnap));
  memset(ackMap, 0xFF, sizeof(ackMap));
  __HAL_RCC_GPIOB_CLK_ENABLE();
  // FRAM-PB3PB4: PB3(JTDO)/PB4(NJTRST) GPIO korar jonno JTAG off, SWD (PA13/PA14) ON thake.
  __HAL_RCC_AFIO_CLK_ENABLE();
  __HAL_AFIO_REMAP_SWJ_NOJTAG();
  pinMode(PIN_I2C_SCL, INPUT);
  pinMode(PIN_I2C_SDA, INPUT);
  pinSnapAt(0);
  delay(300);                                       // I2CD4: power settle (test sketch-e 500 ms chilo)
  ackStage(0);                                      // A0: test sketch-er obostha — kichu configure hoy ni

  // SAFE STATE first: all Andon OFF (100k pull-down hardware-o ache), ESP reset released
  pinMode(PIN_ANDON_RED, OUTPUT);    digitalWrite(PIN_ANDON_RED, ANDON_OFF_LEVEL);
  pinMode(PIN_ANDON_YELLOW, OUTPUT); digitalWrite(PIN_ANDON_YELLOW, ANDON_OFF_LEVEL);
  pinMode(PIN_ANDON_GREEN, OUTPUT);  digitalWrite(PIN_ANDON_GREEN, ANDON_OFF_LEVEL);
  pinMode(PIN_ANDON_BUZZER, OUTPUT); digitalWrite(PIN_ANDON_BUZZER, ANDON_OFF_LEVEL);
  pinSnapAt(1);                                     // S1: Andon PB12..PB15 OUTPUT LOW-er por
  ackStage(1);                                      // A1
  pinMode(PIN_ESP_RESET, INPUT);                    // I2CF1: PB5 Hi-Z (LOW drive korle I2C bus mara jay)
  pinSnapAt(2);                                     // S2: PB5 release-er por
  pinMode(PIN_STATUS_LED, OUTPUT);   digitalWrite(PIN_STATUS_LED, HIGH);
  ackStage(2);                                      // A2: PB5 Hi-Z + LED

  pinMode(PIN_BTN_RED, INPUT_PULLUP);
  pinMode(PIN_BTN_YELLOW, INPUT_PULLUP);
  pinMode(PIN_BTN_GREEN, INPUT_PULLUP);
  pinMode(PIN_BTN_BLUE, INPUT_PULLUP);
  pinMode(PIN_BTN_BLACK, INPUT_PULLUP);
  pinMode(PIN_ENC_A, INPUT);
  pinMode(PIN_ENC_B, INPUT);
  pinMode(PIN_ENC_Z, INPUT);
  pinMode(PIN_OPT1, INPUT);
  pinMode(PIN_OPT2, INPUT);
  pinMode(PIN_ISO1, INPUT);
  pinMode(PIN_ISO2, INPUT);
#if USE_CT_SENSOR
  pinMode(PIN_ADC_SPARE, INPUT_ANALOG);
  analogReadResolution(12);
#endif
  pinSnapAt(3);                                     // S3: LED + sob input/pull-up-er por
  ackStage(3);                                      // A3

  // Reset cause (RCC_CSR bit26..31: PIN, POR, SFT, IWDG, WWDG, LPWR) — clear er age
  resetFlags = (RCC->CSR >> 26) & 0x3F;
  __HAL_RCC_CLEAR_RESET_FLAGS();
  diagBkpBegin();                                   // RESET-FIX: ager run-er stage/HardFault BKP theke pora

  DBG_BEGIN();
  EspLink.setRx(PA10);
  EspLink.setTx(PA9);
  EspLink.begin(LINK_BAUD);

  stmUid = computeUidHash();
  stmBootMs = millis();
  lastEspHbMs = millis();

  pinSnapAt(4);                                     // S4: UART begin-er por
  ackStage(4);                                      // A4

#if PB5_BOOT_PULSE_TEST
  // A5: PB5 weak HIGH (internal 40k)
  pinMode(PIN_ESP_RESET, INPUT_PULLUP);
  delay(5);
  ackStage(5);
  // A6: PB5 strong HIGH 20 ms. Hypothesis test: PB5 net-i ki I2C pull-up/FRAM-RTC VCC?
  //     (design onujayi HIGH = ESP32 EN low -> ESP32 ekbar reboot hote pare; ete khoti nei)
  digitalWrite(PIN_ESP_RESET, HIGH);
  pinMode(PIN_ESP_RESET, OUTPUT);
  digitalWrite(PIN_ESP_RESET, HIGH);
  delay(20);
  ackStage(6);
  pinMode(PIN_ESP_RESET, INPUT);                    // abar Hi-Z
  delay(5);
#else
  // RESET-FIX: upore-r A6 test PB5 HIGH 20 ms = ESP32 EN LOW = ESP32 RESET. Protiti STM32
  // boot-e (IWDG / power / NRST) ESP32-o reboot hoye jeto. PB5 ekhon Hi-Z-i thake.
  // A5/A6 ACKMAP slot "na" (0xFF) dekhabe — eta expected.
#endif

  // S5: internal pull-up (~40k) diye. S4=0 kintu S5=1 -> bus-e external pull-up/power nai.
  //     S5-o 0 -> kichu ekta line-ke shokti diye LOW-e tene rakhche.
  pinMode(PIN_I2C_SCL, INPUT_PULLUP);
  pinMode(PIN_I2C_SDA, INPUT_PULLUP);
  delay(1);
  pinSnapAt(5);
  pinMode(PIN_I2C_SCL, INPUT);
  pinMode(PIN_I2C_SDA, INPUT);

  // S6: PB5 ekhono Hi-Z (I2CF1-e ar LOW kora hoy na)
  delay(2);
  pinSnapAt(6);

  i2cBegin();
  delay(500);                                       // known-working test sketch-er moto
  pinSnapAt(7);                                     // S7: Wire.begin + 500 ms
  bootBusy = i2cHwBusy() ? 1 : 0;
  bootRc50 = framSwAckCode(0x50);                   // FRAM-PB3PB4
  bootRc68 = rtcSoftAckCode();
  i2cTraceStage(0);

  // Boot retry (IWDG start-er age): bus atke thakle / kono device ACK na dile
  // recovery + 200 ms opekkha, max 5 bar (~1.2 s). Power/module der-e uthle-o dhora porbe.
  for (uint8_t t = 0; t < 5; t++) {
    if (!i2cLooksStuck() && (i2cAck(FRAM_I2C_ADDR) || rtcSoftAck())) break;
    bootRecLast = i2cBusRecover();
    bootRecTries++;
    delay(200);
  }
  pinSnapAt(8);                                     // S8: retry sesh-e

  // ISOLATION TEST: configured FRAM address (0x50) only. No 0x51..0x57
  // probing / Device-ID request; external RTC module EEPROM could ACK 0x57.
  // This leaves all FRAM event/storage allocation and RTC logic untouched.
  DBG_PRINTF("[I2C DIAG] fixed FRAM=0x%02X RTC=0x%02X; skip full-range scan",
             FRAM_I2C_ADDR, RTC_I2C_ADDR);
  uint16_t bootManuf = 0, bootProd = 0;
  bool cfgAck = i2cAck(FRAM_I2C_ADDR);
  bool cfgId = cfgAck && framReadDeviceId(FRAM_I2C_ADDR, bootManuf, bootProd);
  i2cTraceStage(1);   // after configured-address ID attempt
  DBG_PRINTF("[I2C DIAG] 0x%02X ACK=%u ID=%u manuf=%03X prod=%03X",
             FRAM_I2C_ADDR, (unsigned)cfgAck, (unsigned)cfgId,
             (unsigned)bootManuf, (unsigned)bootProd);
  i2cTraceStage(2);   // no scan of other addresses in this build
  rtcPresent = rtcSoftAck();
  uint8_t rtcStatus = 0;
  bool rtcStatusOk = rtcPresent && rtcReadRegs(0x0F, &rtcStatus, 1);
  i2cTraceStage(3);
  DBG_PRINTF("[I2C DIAG] RTC 0x68 ACK=%u statusRead=%u OSF=%u\n",
             (unsigned)rtcPresent, (unsigned)rtcStatusOk,
             (unsigned)(rtcStatusOk && (rtcStatus & 0x80) != 0));
  rtcRefresh();
  i2cTraceStage(4);

  framOk = framDetect();
  i2cTraceStage(5);
  DBG_PRINTF("[I2C DIAG] FRAM detected=%u state=%u selectedAddr=0x%02X\n",
             (unsigned)framOk, (unsigned)framState, (unsigned)framAddr);
  if (framOk && !smuValidateOrProvision()) {
    framOk=false;framState=3; // refuse to write unknown/colliding FRAM layout
  }
  i2cTraceStage(6); // after Phase D V1 storage-format verification
  int ls = loadState();
  if (ls == -2) {                                   // FRAM present kintu read fail: overwrite na kore RAM mode
    framOk = false;
    framState = 3;
    faults |= FAULT_FRAM_WRITE | FAULT_STATE_RECOVERY;
  }
  if (ls <= 0) {
    activeSmv = DEFAULT_SMV;
    if (ls == -1) faults |= FAULT_STATE_RECOVERY;   // duto state copy-i corrupt (fresh FRAM fault noy)
  }
  obxLoadHdr();
  IWatchdog.reload();
  smuCheckpointLoad();
  // A lost legacy A/B state must NEVER reset a previously reserved event seq.
  // This is a bounded Phase C recovery bridge, not 64-bit V1 seq reservation.
  if (smuCpGeneration) {
    if (smuCpLastSequence>eventSeq) {
      eventSeq=smuCpLastSequence;
      if (ls<=0) {totalProduction=smuCpTotalP;totalAlter=smuCpTotalA;
                   actualProduction=smuCpActualP;}
    }
    if (smuCpLifeP>lifeProduction) lifeProduction=smuCpLifeP;
    if (smuCpLifeA>lifeAlter) lifeAlter=smuCpLifeA;
    if (smuCpBootCount>bootCount) bootCount=smuCpBootCount;
  }
  if(nfMode) {
    if(!nfRecoverIntent()) {smuMetadataRecoveryFault=true;faults|=FAULT_STATE_RECOVERY;}
  } else if(!smuMetadataRecoveryFault) {
    smuRecoverCommittedOrphan();
    (void)nfActivateFromLegacy();
  }
  pendLoad();
  aggLoad();
  bool ctxOk = ctxLoad();                           // F3: session context (ager ESP32 NVS)
  sessLoadAll();
  sessRebuildRefs();                                // outbox -> session reference count
  bootCount++;
  seqEpoch = makeSeqEpoch();
  reconcileState();                                 // saveState() bootCount soho
  if (ls == 2) clearV1Area();
  if (!ctxOk) ctxSave();
  sessEnsureCurrent();                              // F2 upgrade / fresh: UNKNOWN session (operator abar punch)
  replayStart();

  attachInterrupt(digitalPinToInterrupt(PIN_ENC_Z), zISR, RISING);
  profileSetup();
  i2cTraceStage(7); // after frozen profile setup (read-only probe)

  stopAllRelays();
  applyOutputs();

  buttonsTimerBegin();                              // BTN-ISR: 1 ms button sampling start (IWDG-er age)

  IWatchdog.begin(IWDG_TIMEOUT_US);
  i2cTraceStage(8); // after unchanged STM32 IWDG enable
  DBG_PRINTF("\n===== SMU-100 STM32 %s | proto %d | profile %d (%s) =====\n", FW_REV, PROTO_VER, MACHINE_PROFILE, PROFILE_NAME);
  DBG_PRINTF("[BOOT] resetFlags=0x%02lX FRAM=%u@0x%02X(prod 0x%03X) state=%d RTC=%d/%d IWDG=%s seq=%lu outbox=%u faults=0x%04X\n",
             (unsigned long)resetFlags, framState, framAddr, framProductId, ls, rtcPresent, rtcOk,
             IWatchdog.isEnabled() ? "ENABLED(2s)" : "DISABLED", (unsigned long)eventSeq, (unsigned)outboxTotal(), faults);
  DBG_PRINTF("[RECLAIM POLICY] DB_COMMIT_ONLY enabled=%u SD_CUSTODY=0 NON_FIFO_SLOT=%u\n",
             (unsigned)ENABLE_DB_COMMIT_RECLAIM,(unsigned)nfMode);
  sendBoot();
  diagRamPaint();                                   // RESET-FIX: setup-er sob allocation-er pore
  sendDiag();                                       // RESET-FIX: reset karon (ESP ready thakle)
  dgLoopT0 = millis();
  diagStage(DG_IDLE);
}

void loop() {
  IWatchdog.reload();
#if STM_RESET_DIAG
  {                                                 // RESET-FIX: puro loop()-er max somoy
    uint32_t nowL = millis();
    uint32_t lt = nowL - dgLoopT0;
    if (lt > dgLoopMaxMs) dgLoopMaxMs = lt;
    dgLoopT0 = nowL;
  }
#endif

  diagStage(DG_LINK_POLL);   linkPoll();
  diagStage(DG_LINK_TX);     linkTxService();
  diagStage(DG_DBG_SVC);     stmDebugService();
  diagStage(DG_I2C_PROBE);   stmI2cDebugProbe();
  diagStage(DG_I2C_HEALTH);  i2cHealthService();
  diagStage(DG_HOUSEKEEP);   housekeeping();
  diagStage(DG_OUTBOX);      serviceOutbox();
  diagStage(DG_REPLAY);      serviceReplay();
  diagStage(DG_BUTTONS);     buttonsUpdate();
  diagStage(DG_BEEP);        beepService();
  diagStage(DG_SENSE);       // niche profileSense / handleOperatorInputs / outputs


  if (!sensingArmed) {                       // boot settle: production sensing bondho
    if (millis() - stmBootMs >= BOOT_SETTLE_MS) {
      sensingArmed = true;
#if MACHINE_PROFILE == PROFILE_OVERLOCK_IR
      bool keepSuppress = overlockSuppressUntilRelease;
      profileReset();
      overlockSuppressUntilRelease = keepSuppress;
#else
      profileReset();
#endif
      checkDailyReset("boot");               // rat 03:00-er por prothom chalu: daily reset
    } else {
      applyOutputs();
      return;
    }
  }

  // UNIVERSAL MAINTENANCE GATE (maintenance priority)
  if (isMaintenanceMode) {
    stopAllRelays();
    setIndicatorLight(RELAY_CH2_PIN);
    applyOutputs();
    return;
  }

  profileSense();             // MACHINE-SPECIFIC production logic
  diagStage(DG_OP_INPUTS);
  handleOperatorInputs();     // common: reasons, blink, alter
  diagStage(DG_PERF_LIGHT);
  checkAndApplyPerformanceLight();
  diagStage(DG_OUTPUTS);
  applyOutputs();
  linkTxService();
  diagStage(DG_IDLE);
}
