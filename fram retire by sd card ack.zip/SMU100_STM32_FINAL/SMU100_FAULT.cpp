// =============================================================================
//  SMU-100 STM32 — RESET-FIX (2026.11.02) HardFault capture
//  HardFault hole stack frame theke PC / LR + SCB->CFSR STM32 backup register-e
//  (BKP DR5..DR10) save kore sathe sathe reset. Age Default_Handler-e infinite loop
//  hoto -> 2 s por IWDG reset -> HardFault-o "IWDG" hisebe dekhato (bhul diagnosis).
//  Boot-e .ino diagBkpBegin() egulo pore SDIAG frame-e ESP32-te pathay:
//     ESP32 Serial: "[STM-DIAG] HARDFAULT xN: PC=0x0800xxxx LR=... CFSR=..."
//  PC theke source line:  arm-none-eabi-addr2line -e <sketch>.elf 0x0800xxxx
//  BKP map (.ino-r sathe same): DR1 magic | DR5 count | DR6/DR7 PC | DR8 LR lo | DR9/DR10 CFSR
// =============================================================================
#include <Arduino.h>
#include "SMU100_TYPES.h"

#if STM_HARDFAULT_CAPTURE
extern "C" __attribute__((used)) void smuFaultSave(uint32_t* sf) {
  RCC->APB1ENR |= RCC_APB1ENR_PWREN | RCC_APB1ENR_BKPEN;
  PWR->CR |= PWR_CR_DBP;
  BKP->DR1 = DG_MAGIC;
  BKP->DR5 = (uint16_t)((BKP->DR5 & 0xFFFFu) + 1u);
  uint32_t pc = sf[6], lr = sf[5], cfsr = SCB->CFSR;
  BKP->DR6 = pc & 0xFFFFu;
  BKP->DR7 = pc >> 16;
  BKP->DR8 = lr & 0xFFFFu;
  BKP->DR9 = cfsr & 0xFFFFu;
  BKP->DR10 = cfsr >> 16;
  NVIC_SystemReset();
}

// MSP/PSP je stack-ei fault hok, exception frame pointer r0-te diye smuFaultSave.
extern "C" __attribute__((naked)) void HardFault_Handler(void) {
  __asm volatile(
    " tst lr, #4      \n"
    " ite eq          \n"
    " mrseq r0, msp   \n"
    " mrsne r0, psp   \n"
    " b smuFaultSave  \n");
}
#endif
