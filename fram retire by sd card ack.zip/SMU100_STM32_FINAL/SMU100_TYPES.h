#pragma once
#include <stdint.h>

// RESET-FIX (2026.11.02): .ino ar SMU100_FAULT.cpp duto-i ei switch dekhe.
// HardFault-er PC/LR STM32 backup register-e save kore reset (ESP32 log-e "[STM-DIAG] HARDFAULT").
// Link error "multiple definition of HardFault_Handler" hole 0 korun.
#define STM_HARDFAULT_CAPTURE 1
#define DG_MAGIC 0x5D1Au      // BKP DR1 valid marker

// Struct declarations are kept in a header so Arduino auto-generated
// function prototypes see these types before referencing them.
struct BeepReq { uint16_t onMs; uint16_t offMs; uint8_t count; };

struct DebBtn { uint32_t pin; int stable; int lastRaw; unsigned long changeMs; };

// Critical state v2 (FRAM A/B double buffer, CRC16)
struct __attribute__((packed)) PersistState {
  uint32_t magic;
  uint16_t version;
  uint16_t size;
  uint32_t gen;
  uint32_t seq;               // last assigned event sequence (never reset)
  int32_t  totalProduction;   // SESSION counter (legacy rules-e reset hoy)
  int32_t  totalAlter;
  int32_t  actualProduction;
  uint32_t lifeProduction;    // LIFETIME counter (kokhono reset hoy na)
  uint32_t lifeAlter;
  uint32_t sessionId;         // ESP32 session (operator/location/style metadata id)
  uint32_t lastDeliveredSeq;
  uint32_t bootCount;         // seqEpoch derivation (unique per boot)
  uint32_t prodDay;           // current production day (local, 03:00 boundary)
  float    activeSmv;
  int16_t  activeDivisor;
  uint8_t  operatorReady;
  uint8_t  maintenance;
  uint8_t  profile;
  uint8_t  reserved[3];
  uint16_t crc;
};

// Outbox event record v2 (48 byte, CRC16)
struct __attribute__((packed)) EventRec {
  uint32_t seq;
  uint32_t ts;        // RTC epoch UTC (0 = unknown)
  uint32_t ms;        // STM32 millis at event
  uint32_t irDur;     // type 4: aggregated reason-event count
  uint32_t cyc;       // type 4: first aggregated seq; type 6/7: technician session id
  int32_t  tp;
  int32_t  ta;
  int32_t  ac;
  uint32_t sessionId;
  uint16_t prod;      // type 4: aggregated production count
  uint16_t alt;       // type 4: aggregated alter count
  uint8_t  reason;    // 0 none, 1..4 Reason_n
  uint8_t  type;      // 1 production, 2 alter, 3 reason, 4 overflow aggregate
  uint8_t  flags;     // bit0 duration-not-final, bit1 recovered-after-power-loss, bit2 created-unassigned
  uint8_t  profile;
  uint32_t epoch;     // seqEpoch of the boot that created this record
  uint32_t lifeP;     // lifetime counters at creation (power-loss reconcile)
  uint32_t lifeA;
  uint16_t crc;
};

struct __attribute__((packed)) ObxHdr {
  uint32_t magic;
  uint32_t gen;
  uint16_t head;
  uint16_t count;
  uint32_t corrupted;
  uint16_t crc;
};

// Overlock pending production (count hoyeche, IR release-e duration final hobe)
struct __attribute__((packed)) PendingSlot {
  uint32_t magic;
  uint32_t gen;
  uint8_t  active;
  uint8_t  pad[3];
  EventRec rec;       // rec.irDur = lower bound (start -> count)
  uint16_t crc;
};

// Outbox full hole: event overwrite NA kore aggregate counter-e jog
struct __attribute__((packed)) OverflowAgg {
  uint32_t magic;
  uint32_t gen;
  uint32_t prod;
  uint32_t alt;
  uint32_t reasonEv;
  uint32_t firstSeq;
  uint32_t lastSeq;
  uint32_t sessionId;
  int32_t  tp, ta, ac;
  uint32_t flushSeq;          // != 0: ei seq-er aggregate record outbox-e lekha cholche
  uint32_t flushP, flushA, flushR;
  uint16_t crc;
};

// Session table slot (F3): ESP32 NVS "ss0..ss15"-er bodole STM32 FRAM-e.
// kind 0 = operator session (event metadata), kind 1 = technician (maintenance event mech name).
// Slot body likhar por bodlay na; unassigned -> operator mapping CtxRec.alias[]-e (A/B atomic).
struct __attribute__((packed)) SessSlot {
  uint32_t magic;
  uint32_t id;
  uint32_t day;        // production day jokhon toiri
  float    smv;
  int16_t  div;
  uint8_t  assigned;   // 1 = operator jana (login), 0 = UNKNOWN (login chhara)
  uint8_t  kind;       // 0 operator session, 1 technician
  char     op[32];     // operator id/name (kind 1: technician name)
  char     loc[32];
  char     style[48];
  char     proc[42];
  uint16_t crc;
};

// Current context (F3): ESP32 NVS "opRfid/locRfid/tech/techRfid/sidMax/sday/recPunch" -er bodole
#define SESS_SLOTS 8
struct __attribute__((packed)) CtxRec {
  uint32_t magic;
  uint32_t gen;
  uint32_t nextSid;    // session id allocator
  uint32_t loginDay;   // je production day-te operator login korechilo
  uint32_t techSid;    // maintenance cholle technician slot id
  uint8_t  recPunch;   // card punch hoyeche, server state (RESTORE) baki
  uint8_t  pad[3];
  char     opRfid[12];
  char     locRfid[12];
  char     techRfid[12];
  uint32_t alias[SESS_SLOTS];   // unassigned slot i -> operator session id (0 = HELD, 0xFFFFFFFF = released UNKNOWN)
  char machineId[32];         // current provisioned machine identity (offline FRAM snapshot)
  uint16_t crc;
};

// Previous interim build (v1) state layout — migration only
struct __attribute__((packed)) PersistStateV1 {
  uint32_t magic; uint32_t gen; uint32_t seq;
  int32_t totalProduction; int32_t totalAlter; int32_t actualProduction;
  float activeSmv; int16_t activeDivisor; uint8_t operatorReady; uint8_t maintenance;
  uint8_t profile; uint8_t reserved; uint16_t crc;
};
struct __attribute__((packed)) ObxHdrV1 {
  uint32_t magic; uint32_t gen; uint16_t head; uint16_t count; uint32_t overflow; uint16_t crc;
};

